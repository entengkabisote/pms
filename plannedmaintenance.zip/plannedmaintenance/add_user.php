<?php
session_start();
include 'db_connect.php';

// Query to get the roles from the roles table
$query = "SELECT role_id, role_name FROM roles";
$result = mysqli_query($conn, $query);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/add_user_style.css">
    <style>
        #toast-container {
            top: 50% !important;
            right: 50% !important;
            transform: translateX(50%) translateY(-50%) !important;
            bottom: auto !important;
            left: auto !important;
        }

        .toast {
            background-color: red !important;
        }

        .invalid-input {
            border-color: red;
        }

        .helper-text {
            color: red;
            visibility: hidden;
        }

    </style>
</head>

<body>
<?php include 'header.php'; ?>
    <h5>Add User</h5>
    <main class="add-user-container">
        <form action="process_add_user.php" method="post">
            <div>
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required onblur="checkUsername(this.value)">
                <span id="username_error" class="helper-text"></span>
            </div>
            <div>
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required onblur="checkEmail(this.value)">
                <span id="email_error" class="helper-text"></span>
            </div>
            <div>
                <label for="role">Role:</label>
                <?php
                    echo '<select id="role" name="role">';
                    while($row = mysqli_fetch_assoc($result)) {
                        echo '<option value="' . $row['role_name'] . '">' . $row['role_name'] . '</option>';
                    }
                    echo '</select>';                    
                ?>
            </div>
            <button id="submit-btn" class="btn-small waves-effect waves-light" type="button" onclick="validateForm()">
                <i class="material-icons left">person_add</i> Add User
            </button>



        </form>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);

            var elems = document.querySelectorAll('select');
            var instances = M.FormSelect.init(elems);
        });

        function displayError(inputId, errorId, message) {
            document.getElementById(inputId).classList.add('invalid-input');
            document.getElementById(errorId).textContent = message;
            document.getElementById(errorId).style.visibility = 'visible';
            document.getElementById(inputId).focus();
        }

        function clearError(inputId, errorId) {
            document.getElementById(inputId).classList.remove('invalid-input');
            document.getElementById(errorId).textContent = '';
            document.getElementById(errorId).style.visibility = 'hidden';
        }

        let isUsernameTaken = false;
        let isEmailTaken = false;

        function checkUsername(username) {
            if (username.length === 0) {
                isUsernameTaken = false;
                document.getElementById("username").classList.remove('invalid');
                return;
            }
            const xhr = new XMLHttpRequest();
            xhr.onload = function() {
                if (this.readyState === 4 && this.status === 200) {
                    if (this.responseText.indexOf("taken") !== -1) {
                        isUsernameTaken = true;
                        displayError('username', 'username_error', 'Username is already taken');
                    } else {
                        isUsernameTaken = false;
                        clearError('username', 'username_error');
                    }
                }
            };
            xhr.open("GET", "check_username.php?username=" + encodeURIComponent(username), true);
            xhr.send();
        }

        function checkEmail(email) {
            if (email.length === 0) {
                isEmailTaken = false;
                document.getElementById("email").classList.remove('invalid');
                return;
            }
            const xhr = new XMLHttpRequest();
            xhr.onload = function() {
                if (this.readyState === 4 && this.status === 200) {
                    if (this.responseText.indexOf("registered") !== -1) {
                        isEmailTaken = true;
                        displayError('email', 'email_error', 'Email is already registered');
                    } else {
                        isEmailTaken = false;
                        clearError('email', 'email_error');
                    }
                }
            };
            xhr.open("GET", "check_email.php?email=" + encodeURIComponent(email), true);
            xhr.send();
        }

        // Disable submit button based on username and email status
        function updateSubmitButton() {
            const submitBtn = document.getElementById("submit-btn");
            submitBtn.disabled = isUsernameTaken || isEmailTaken;
            if (isUsernameTaken || isEmailTaken) {
                // Only update the text, not the entire HTML
                submitBtn.textContent = 'Cannot add user';
            } else {
                // Make sure to restore the original HTML if there is no error
                submitBtn.innerHTML = '<i class="material-icons left">person_add</i> Add User';
            }
        }


        function validateForm() {
            if (isUsernameTaken || isEmailTaken) {
                M.toast({html: 'Please provide unique username and email address before proceeding.', displayLength: 3000});
                if (isUsernameTaken) {
                    document.getElementById('username').focus();
                } else if (isEmailTaken) {
                    document.getElementById('email').focus();
                }
                return false; // Prevent form from submitting
            } else {
                // No duplicates, proceed to submit the form
                document.querySelector('form').submit();
            }
        }


    </script>
</body>

</html>
