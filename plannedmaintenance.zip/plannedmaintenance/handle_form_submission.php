<?php
include "db_connect.php";
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo '<pre>';
    print_r($_POST);
    echo '</pre>';
    // exit; // Uncomment this line to stop the script here for debugging
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['message'] = 'Invalid request method.';
    header('Location: view_vessel_rh_details.php?vessel_id=' . $vessel_id);
    exit();
}

$vessel_id = $_POST['vessel_id'];
$dateArray = $_POST['date'];
$running_hoursArray = $_POST['running_hours'];

// Validate vessel_id
if (!$vessel_id) {
    $_SESSION['message'] = 'Vessel ID is missing.';
    header('Location: view_vessel_rh_details.php');
    exit();
}

// Start transaction
$conn->begin_transaction();

// Get the related data for the vessel
$data = getVesselData($conn, $vessel_id);

$insertValues = [];
$hasDuplicate = false;
$errorOccurred = false;

foreach ($dateArray as $equipment_type => $date) {
    $hours = isset($running_hoursArray[$equipment_type]['hours']) && is_numeric($running_hoursArray[$equipment_type]['hours']) ? (int)$running_hoursArray[$equipment_type]['hours'] : 0;
    $minutes = isset($running_hoursArray[$equipment_type]['minutes']) && is_numeric($running_hoursArray[$equipment_type]['minutes']) ? (int)$running_hoursArray[$equipment_type]['minutes'] : 0;

    // Validate the minutes
    if ($minutes < 0 || $minutes >= 60) {
        $_SESSION['message'] = "Minutes for $equipment_type should be between 0 and 59.";
        $errorOccurred = true;
        break;
    }

    $decimalHours = $hours + ($minutes / 60);
    $running_hours = $decimalHours;

    // Process each equipment type
    processEquipmentType($conn, $data, $equipment_type, $date, $running_hours, $vessel_id, $insertValues, $hasDuplicate);
}

// foreach ($dateArray as $equipment_type => $date) {
//     $hours = isset($running_hoursArray[$equipment_type]['hours']) ? $running_hoursArray[$equipment_type]['hours'] : '';
//     $minutes = isset($running_hoursArray[$equipment_type]['minutes']) ? $running_hoursArray[$equipment_type]['minutes'] : '';

//     // Skip this iteration if both hours and minutes are empty
//     if ($hours === '' && $minutes === '') {
//         continue;
//     }

//     // Check if hours and minutes are numeric
//     if (is_numeric($hours) && is_numeric($minutes)) {
//         $hours = (int)$hours;
//         $minutes = (int)$minutes;

//         // Validate the minutes
//         if ($minutes < 0 || $minutes >= 60) {
//             $_SESSION['message'] = "Minutes for $equipment_type should be between 0 and 59.";
//             $errorOccurred = true;
//             break;
//         }

//         $decimalHours = $hours + ($minutes / 60);
//         $running_hours = $decimalHours;

//         // Process each equipment type
//         processEquipmentType($conn, $data, $equipment_type, $date, $running_hours, $vessel_id, $insertValues, $hasDuplicate);
//     } else {
//         $_SESSION['message'] = "Invalid or missing hours and minutes for equipment type $equipment_type.";
//         $errorOccurred = true;
//         break;
//     }
// }

if ($errorOccurred) {
    $conn->rollback();
    header("Location: view_vessel_rh_details.php?vessel_id=$vessel_id");
    exit();
}

// If no error occurred, handle the final actions
handleFinalActions($conn, $vessel_id, $insertValues, $hasDuplicate);

$conn->close();


// Helper Functions

function getVesselData($conn, $vessel_id) {
    $stmt = $conn->prepare("SELECT ve.equipment_id, ve.task_id, re.equipment_type, re.equipment_name, t.task_description, t.threshold_hour FROM vessel_rh_equipment ve JOIN rh_equipments re ON ve.equipment_id = re.equipment_id LEFT JOIN tasks t ON ve.task_id = t.task_id WHERE ve.vessel_id = ?");
    $stmt->bind_param("i", $vessel_id);
    $stmt->execute();
    $data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $data;
}

function processEquipmentType($conn, $data, $equipment_type, $date, $running_hours, $vessel_id, &$insertValues, &$hasDuplicate) {
    foreach ($data as $row) {
        if ($row['equipment_type'] != $equipment_type) continue;

        if (!isDuplicateEntry($conn, $row, $vessel_id, $date, $equipment_type)) {
            $insertValues[] = buildInsertValue($row, $vessel_id, $date, $running_hours, $equipment_type);
            updateRunningHours($conn, $row, $date, $running_hours, $vessel_id);
            updateStatus($conn, $row, $running_hours, $vessel_id);
        } else {
            $hasDuplicate = true;
        }
    }
}

function isDuplicateEntry($conn, $row, $vessel_id, $date, $equipment_type) {
    $stmt = $conn->prepare("SELECT * FROM running_hours_entries WHERE vessel_id = ? AND date = ? AND equipment_type = ? AND task_id = ? AND threshold_hours = ? AND equipment_name = ?");
    $stmt->bind_param("isssis", $vessel_id, $date, $equipment_type, $row['task_id'], $row['threshold_hour'], $row['equipment_name']);
    $stmt->execute();
    $result = $stmt->get_result()->num_rows > 0;
    $stmt->close();
    return $result;
}

function buildInsertValue($row, $vessel_id, $date, $running_hours, $equipment_type) {
    return "($vessel_id, {$row['equipment_id']}, '$date', $running_hours, '$equipment_type', {$row['task_id']}, {$row['threshold_hour']}, '{$row['equipment_name']}')";
}


function updateRunningHours($conn, $row, $date, $running_hours, $vessel_id) {
    // Kunin ang current total_running_hours, total_life_rh, at remarks
    $stmt = $conn->prepare("SELECT total_running_hours, total_life_rh, remarks FROM vessel_rh_equipment WHERE vessel_id = ? AND equipment_id = ? AND task_id = ?");
    $stmt->bind_param("iii", $vessel_id, $row['equipment_id'], $row['task_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();
    $current_running_hours = isset($data['total_running_hours']) ? $data['total_running_hours'] : 0;
    $current_life_hours = isset($data['total_life_rh']) ? $data['total_life_rh'] : 0; // Kunin ang current total_life_rh
    $current_remarks = isset($data['remarks']) ? $data['remarks'] : 'No remarks';
    $stmt->close();

    // I-calculate ang bagong total_running_hours, total_life_rh, at remaining_hours
    $new_total_running_hours = bcadd($current_running_hours, $running_hours, 3);
    $new_life_hours = bcadd($current_life_hours, $running_hours, 3); // I-update ang total_life_rh
    $remaining_hours = $row['threshold_hour'] - $new_total_running_hours;

    // Set ang remarks
    $remarks = ($current_running_hours == 0 && $new_total_running_hours > 0) ? 'Initial Link' : $current_remarks;

    // I-update ang database
    $stmt = $conn->prepare("UPDATE vessel_rh_equipment SET date_modified = ?, total_running_hours = ?, total_life_rh = ?, remaining_hours = ?, remarks = ? WHERE vessel_id = ? AND equipment_id = ? AND task_id = ?");
    $stmt->bind_param("sdddsiii", $date, $new_total_running_hours, $new_life_hours, $remaining_hours, $remarks, $vessel_id, $row['equipment_id'], $row['task_id']);
    if (!$stmt->execute()) {
        // Handle error here
        echo "Error updating running hours and total life running hours: " . $stmt->error;
    }
    $stmt->close();
}



// function updateRunningHours($conn, $row, $date, $running_hours, $vessel_id) {
//     // Kunin ang current total_running_hours at remarks
//     $stmt = $conn->prepare("SELECT total_running_hours, remarks FROM vessel_rh_equipment WHERE vessel_id = ? AND equipment_id = ? AND task_id = ?");
//     $stmt->bind_param("iii", $vessel_id, $row['equipment_id'], $row['task_id']);
//     $stmt->execute();
//     $result = $stmt->get_result();
//     $data = $result->fetch_assoc();
//     $current_running_hours = isset($data['total_running_hours']) ? $data['total_running_hours'] : 0;
//     // I-set ang default value ng remarks sa current value, kung wala man ito ay 'No remarks'.
//     $current_remarks = isset($data['remarks']) ? $data['remarks'] : 'No remarks';
//     $stmt->close();

//     // I-calculate ang bagong total_running_hours at remaining_hours
//     $new_total_running_hours = bcadd($current_running_hours, $running_hours, 3);  // 2 decimal places
//     $remaining_hours = $row['threshold_hour'] - $new_total_running_hours;

//     // Set ang remarks sa 'Initial Link' kung 0 ang current_running_hours at hindi 0 ang new_total_running_hours
//     $remarks = ($current_running_hours == 0 && $new_total_running_hours > 0) ? 'Initial Link' : $current_remarks;

//     // I-update ang database
//     $stmt = $conn->prepare("UPDATE vessel_rh_equipment SET date_modified = ?, total_running_hours = ?, remaining_hours = ?, remarks = ? WHERE vessel_id = ? AND equipment_id = ? AND task_id = ?");
//     $stmt->bind_param("sddsiii", $date, $new_total_running_hours, $remaining_hours, $remarks, $vessel_id, $row['equipment_id'], $row['task_id']);
//     if (!$stmt->execute()) {
//         // Handle error here
//         echo "Error updating running hours: " . $stmt->error;
//     }
//     $stmt->close();
// }

function updateStatus($conn, $row, $running_hours, $vessel_id) {
    // Calculate new status here based on running hours...
    $status = calculateStatus($conn, $row, $running_hours, $vessel_id);
    $stmt = $conn->prepare("UPDATE vessel_rh_equipment SET status = ? WHERE vessel_id = ? AND equipment_id = ? AND task_id = ?");
    $stmt->bind_param("siii", $status, $vessel_id, $row['equipment_id'], $row['task_id']);
    $stmt->execute();
    $stmt->close();
}

function calculateStatus($conn, $row, $running_hours, $vessel_id) {
    // Your logic to calculate status based on total running hours...
    
    $totalHoursStmt = $conn->prepare("SELECT total_running_hours FROM vessel_rh_equipment WHERE vessel_id = ? AND task_id = ?");
    $totalHoursStmt->bind_param("ii", $vessel_id, $row['task_id']);
    $totalHoursStmt->execute();
    $result = $totalHoursStmt->get_result();
    $existingTotalRunningHours = 0;

    if ($resultRow = $result->fetch_assoc()) {
        $existingTotalRunningHours = $resultRow['total_running_hours'];
    }
    $totalHoursStmt->close();

    $newTotalRunningHours = $existingTotalRunningHours + $running_hours;
    $threshold_hours = $row['threshold_hour'];

    if ($newTotalRunningHours < 0.7 * $threshold_hours) {
        return "On Track";
    } elseif ($newTotalRunningHours >= 0.7 * $threshold_hours && $newTotalRunningHours <= $threshold_hours) {
        return "Due Soon";
    } else {
        return "Over Due";
    }
}


function handleFinalActions($conn, $vessel_id, $insertValues, $hasDuplicate) {
    if (!$hasDuplicate) {
        if (!empty($insertValues)) {
            $insertQuery = "INSERT INTO running_hours_entries (vessel_id, equipment_id, date, running_hours, equipment_type, task_id, threshold_hours, equipment_name) VALUES " . implode(",", $insertValues);
            $conn->query($insertQuery);
        }
        $conn->commit();
        $_SESSION['message'] = 'Records successfully saved.';
    } else {
        $conn->rollback();
        $_SESSION['message'] = 'Some records already exist and were not saved.';
    }
    header('Location: view_vessel_rh_details.php?vessel_id=' . $vessel_id);
}

?>
