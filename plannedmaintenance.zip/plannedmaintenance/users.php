<?php
include 'db_connect.php';

// Get users from the users table
$query = "SELECT user_id, username FROM users";
$result = mysqli_query($conn, $query);
$users = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Get permissions from the permissions table
$query = "SELECT permission_id, permission_name FROM permissions";
$result = mysqli_query($conn, $query);
$permissions = mysqli_fetch_all($result, MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $selected_permissions = $_POST['permissions'];

    // First, clear out any existing permissions for this user
    $query = "DELETE FROM user_permissions WHERE user_id = $user_id";
    mysqli_query($conn, $query);

    // Then, insert the new permissions
    foreach ($selected_permissions as $permission_id) {
        $query = "INSERT INTO user_permissions (user_id, permission_id) VALUES ($user_id, $permission_id)";
        mysqli_query($conn, $query);
    }

    // Redirect or show a success message
    header("Location: users.php?success=1");
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/general.css">
</head>

<body>
<?php include 'header.php'; ?>
    <h5>User Management</h5>
    <main class="index-container">
        <form method="POST" action="add_permission.php">
            <div class="input-field">
                <select name="user_id">
                    <?php foreach ($users as $user): ?>
                        <option value="<?= $user['user_id'] ?>"><?= $user['username'] ?></option>
                    <?php endforeach; ?>
                </select>
                <label>Select User</label>
            </div>

            <p>Permissions:</p>
            <?php foreach ($permissions as $permission): ?>
                <label>
                    <input type="checkbox" name="permissions[]" value="<?= $permission['permission_id'] ?>" />
                    <span><?= $permission['permission_name'] ?></span>
                </label><br>
            <?php endforeach; ?>
            <label>
                <input type="checkbox" name="permissions[]" value="1" />
                <span>View Dashboard</span>
            </label><br>
            <label>
                <input type="checkbox" name="permissions[]" value="2" />
                <span>Edit Profile</span>
            </label><br>
            <!-- ... Other permissions -->

            <button class="btn waves-effect waves-light" type="submit" name="action">Set Permissions</button>
        </form>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);

            var elems = document.querySelectorAll('select');
            var instances = M.FormSelect.init(elems);
        });
        

        
        </script>
</body>

</html>
