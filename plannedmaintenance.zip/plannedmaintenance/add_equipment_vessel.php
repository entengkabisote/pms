<?php
session_start();

include 'db_connect.php' ;

// Check if vessel_id and user_id are set
$vessel_id = isset($_GET['vessel_id']) ? $_GET['vessel_id'] : null;
if ($vessel_id === null) {
    // Handle the case where vessel_id is not set
    // Redirect back or show an error message
    header("Location: some_error_page.php");
    exit;
}

if (!isset($_SESSION['user_id'])) {
    die("You need to login.");
}

$userId = $_SESSION['user_id'];

function userHasPermission($desiredPermission, $userId, $conn) {
    $query = "SELECT permission_name FROM user_permissions INNER JOIN permissions ON user_permissions.permission_id = permissions.permission_id WHERE user_permissions.user_id = ?";
    
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $userId);
    mysqli_stmt_execute($stmt);
    
    $result = mysqli_stmt_get_result($stmt);
    $permissions = []; 
    while ($row = mysqli_fetch_assoc($result)) {
        if (strcasecmp($row['permission_name'], $desiredPermission) == 0) {
            return true; // found the permission, return true
        }
    }
    
    error_log("User ID: $userId, Permissions: " . implode(', ', $permissions)); // Log permissions
    return false; // not found permission, return false
}

if (!userHasPermission("Add Equipment", $userId, $conn)) {
    // Check if the vessel_id is present and is not empty
    if (isset($_GET['vessel_id']) && !empty($_GET['vessel_id'])) {
        $vessel_id = $_GET['vessel_id'];
        echo "<script>alert('Sorry, you don\'t have permission for this.'); window.location.href='vessel_maintenance.php?id=$vessel_id';</script>";
    } else {
        // If there's no vessel_id, redirect to a page where the user can choose a vessel
        echo "<script>alert('Vessel ID is missing or you do not have permission.'); window.location.href='vessel_maintenance.php';</script>";
    }
    exit;
}

// Get existing equipment and associated inspection_types from the vessel
$existingInspectionTypesQuery = "SELECT equipment_id, inspection_meta_id FROM vessel_equipment WHERE vessel_id = ?";
$existingInspectionTypesStmt = mysqli_prepare($conn, $existingInspectionTypesQuery);
mysqli_stmt_bind_param($existingInspectionTypesStmt, "i", $vessel_id);
mysqli_stmt_execute($existingInspectionTypesStmt);
$existingInspectionTypesResult = mysqli_stmt_get_result($existingInspectionTypesStmt);

$existingInspectionTypes = [];
while ($row = mysqli_fetch_assoc($existingInspectionTypesResult)) {
    // Magkaroon ng array ng equipment_id na susi at array ng inspection_meta_id bilang value
    $existingInspectionTypes[$row['equipment_id']][] = $row['inspection_meta_id'];
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Equipment | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/add_equipment_vessel_style.css">
</head>

<body>
<?php include 'header.php'; ?>
    <div>
        <h5>Select Equipment to Add</h5>
    </div>
<!-- ************************************** -->
    <main class="add-equipment-container">
<!-- ************************************** -->
    
        
        <form action="confirm_selections.php" method="post">
            <ul class="collapsible">
                <?php
                // Get categories of equipment
                $sql = "SELECT DISTINCT category FROM equipment_table ORDER BY category";
                $categories = $conn->query($sql);

                foreach ($categories as $category) {
                    $hasUnlinkedEquipmentOrInspectionTypes = false; // Flag to determine if we have any equipment or inspection types to show
                
                    // Prepare and execute the query to get all equipment for this category
                    $equipmentsQuery = "SELECT * FROM equipment_table WHERE category = ?";
                    $equipmentsStmt = mysqli_prepare($conn, $equipmentsQuery);
                    mysqli_stmt_bind_param($equipmentsStmt, "s", $category['category']);
                    mysqli_stmt_execute($equipmentsStmt);
                    $equipmentsResult = mysqli_stmt_get_result($equipmentsStmt);
                    
                    // Buffer the equipment and inspection types to determine if we need to show the "Check All" checkbox
                    $equipmentBuffer = [];
                    while ($equipment = mysqli_fetch_assoc($equipmentsResult)) {
                        $equipmentId = $equipment['equipment_id'];
                        
                        // Prepare and execute the query to get all inspection types for this equipment
                        $inspectionTypesQuery = "SELECT * FROM inspection_meta_table WHERE equipment_id = ?";
                        $inspectionTypesStmt = mysqli_prepare($conn, $inspectionTypesQuery);
                        mysqli_stmt_bind_param($inspectionTypesStmt, "i", $equipmentId);
                        mysqli_stmt_execute($inspectionTypesStmt);
                        $inspectionTypesResult = mysqli_stmt_get_result($inspectionTypesStmt);
                        
                        while ($inspectionType = mysqli_fetch_assoc($inspectionTypesResult)) {
                            // Check if this inspection type is not already linked to the vessel
                            if (empty($existingInspectionTypes[$equipmentId]) || !in_array($inspectionType['meta_id'], $existingInspectionTypes[$equipmentId])) {
                                $equipmentBuffer[$equipmentId]['equipment_name'] = $equipment['equipment_name'];
                                $equipmentBuffer[$equipmentId]['inspection_types'][] = $inspectionType;
                                $hasUnlinkedEquipmentOrInspectionTypes = true;
                            }
                        }
                    }
                    
                    echo '<li>';
                    echo '<div class="collapsible-header">' . $category['category'] . '</div>';
                
                    // Only show the "Check All" checkbox if there are equipment or inspection types to show
                    if ($hasUnlinkedEquipmentOrInspectionTypes) {
                        echo '<div class="collapsible-body"><span>';
                        echo '<label><input type="checkbox" class="filled-in" id="check_all_' . htmlspecialchars($category['category'], ENT_QUOTES) . '"/><span>Check All</span></label>';
                
                        // Now display the buffered equipment and their inspection types
                        foreach ($equipmentBuffer as $equipmentId => $equipmentDetails) {
                            echo '<p>';
                            echo '<label>';
                            echo '<input type="checkbox" class="filled-in" name="equipment[]" value="' . $equipmentId . '" id="equipment_' . $equipmentId . '"/>';
                            echo '<span>' . $equipmentDetails['equipment_name'] . '</span>';
                            echo '</label>';
                            
                            // Display nested inspection types
                            echo '<ul class="inspection-types" id="inspection_types_for_equipment_' . $equipmentId . '" style="display:none; margin-left:20px;">';
                            foreach ($equipmentDetails['inspection_types'] as $inspectionType) {
                                echo '<li>';
                                echo '<label>';
                                echo '<input type="checkbox" name="inspection_types[' . $equipmentId . '][]" value="' . $inspectionType['meta_id'] . '">';
                                echo '<span>' . $inspectionType['inspection_type'] . '</span>';
                                echo '</label>';
                                echo '</li>';
                            }
                            echo '</ul>';
                            echo '</p>';
                        }
                        echo '</span></div>';
                    }
                    echo '</li>';
                }
                
                ?>
            </ul>
            <input type="hidden" name="vessel_id" value="<?php echo htmlspecialchars($vessel_id); ?>">
            <button type="submit" class="btn-small waves-effect waves-light"><i class="material-icons left">add</i>Add Equipment to Vessel</button>
            <a href="vessel_maintenance.php?id=<?php echo htmlspecialchars($vessel_id); ?>" class="btn-small waves-effect waves-light"><i class="material-icons left">arrow_back</i>Back to Vessel Details</a>
        </form>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
            
            var elemsCollapsible = document.querySelectorAll('.collapsible');
            var instancesCollapsible = M.Collapsible.init(elemsCollapsible);

            // Check all the checkboxes for the equipment
            var equipmentCheckboxes = document.querySelectorAll('input[name="equipment[]"]');
            equipmentCheckboxes.forEach(function(checkbox) {
                checkbox.addEventListener('change', function() {
                    // Toggle display of nested inspection types based on checkbox state
                    var inspectionListId = 'inspection_types_for_equipment_' + this.value;
                    var inspectionList = document.getElementById(inspectionListId);
                    if (inspectionList) {
                        if (this.checked) {
                            inspectionList.style.display = 'block';
                            // Automatically check all inspection type checkboxes when equipment is checked
                            let inspectionCheckboxes = inspectionList.querySelectorAll('input[type="checkbox"]');
                            inspectionCheckboxes.forEach(function(inspectionCheckbox) {
                                inspectionCheckbox.checked = true;
                            });
                        } else {
                            inspectionList.style.display = 'none';
                            // Optional: Uncheck all inspection type checkboxes if the equipment is not checked
                            let inspectionCheckboxes = inspectionList.querySelectorAll('input[type="checkbox"]');
                            inspectionCheckboxes.forEach(function(inspectionCheckbox) {
                                inspectionCheckbox.checked = false;
                            });
                        }
                    }
                });
            });

            // Event listeners para sa "Check All" checkboxes
            var checkAllCheckboxes = document.querySelectorAll('input[id^="check_all_"]');
            checkAllCheckboxes.forEach(function(checkAllCheckbox) {
                checkAllCheckbox.addEventListener('change', function() {
                    // Update to select only the equipment checkboxes under this category
                    var equipmentList = this.closest('.collapsible-body').querySelectorAll('input[type="checkbox"]:not([id^="check_all_"])');
                    equipmentList.forEach(function(checkbox) {
                        checkbox.checked = checkAllCheckbox.checked;
                        checkbox.dispatchEvent(new Event('change')); // Trigger the change event
                    });
                });
            });
        });


    </script>
</body>

</html>
