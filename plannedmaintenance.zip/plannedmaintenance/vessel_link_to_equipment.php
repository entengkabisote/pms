<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    // Redirect to login page or display the error message
    die("You need to login.");
}
// $userId = $_SESSION['user_id'];

function userHasPermission($desiredPermission, $userId, $conn) {
    // query the database for the permissions of user
    $query = "SELECT permission_name FROM user_permissions INNER JOIN permissions ON user_permissions.permission_id = permissions.permission_id WHERE user_permissions.user_id = ?";
    
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $userId);
    mysqli_stmt_execute($stmt);
    
    $result = mysqli_stmt_get_result($stmt);
    $permissions = []; 
    while ($row = mysqli_fetch_assoc($result)) {
        if (strcasecmp($row['permission_name'], $desiredPermission) == 0) {
            return true; // found the permission, return true
        }
    }
    return false; // not found permission, return false
}

// use the function
$userId = $_SESSION['user_id']; 
// if (userHasPermission("Link Machineries", $userId, $conn)) {
//     // display the form for the add of equipment
// } else {
//     echo "Sorry, you don't have permission for this.";
//     exit; 
// }

if (!userHasPermission("Link Machineries", $userId, $conn)) {
    // Check if the vessel_id is present and is not empty
    if (isset($_GET['vessel_id']) && !empty($_GET['vessel_id'])) {
        $vessel_id = $_GET['vessel_id'];
    } else {
        // Handle the case where vessel_id is not provided
        echo "<script>alert('Vessel ID is missing.'); window.location.href='vessel_maintenance.php';</script>";
        exit;
    }

    echo "<script>alert('Sorry, you don\'t have permission for this.'); window.location.href='vessel_maintenance.php?id=$vessel_id';</script>";
    exit;
}









if (isset($_SESSION['link_added']) && $_SESSION['link_added']) {
    $_SESSION['vessel_error'] = "Successfully linked vessel and equipment(s)!";
    unset($_SESSION['link_added']);
}

if (isset($_SESSION['edit_link']) && $_SESSION['edit_link']) {
    $_SESSION['vessel_error'] = "Successfully update the linked vessel and equipment(s)!";
    unset($_SESSION['edit_link']);
}

if (isset($_SESSION['vessel_exists']) && $_SESSION['vessel_exists']) {
    $_SESSION['vessel_error'] = "Vessel and equipment(s) already linked!";
    unset($_SESSION['vessel_exists']);
}

if (isset($_SESSION['incomplete_data']) && $_SESSION['incomplete_data']) {
    $_SESSION['vessel_error'] = "Incomplete Data!";
    unset($_SESSION['incomplete_data']);
}

include "db_connect.php";

if (!isset($_GET['vessel_id']) || empty($_GET['vessel_id'])) {
    die('Vessel ID is missing.');
}
$vessel_id = $_GET['vessel_id'];


$stmt = $conn->prepare("SELECT * FROM vessels WHERE id = ?");
$stmt->bind_param("i", $vessel_id);

if ($stmt->execute()) {
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $vessel = $result->fetch_assoc();
        // echo "Vessel Name: " . $vessel['vessel_name'] . "<br>";
    } else {
        echo "No vessel found with the ID: " . $vessel_id . "<br>";
    }
} else {
    echo "SQL error: " . $stmt->error;
}



$query = "SELECT DISTINCT rh_equipments.equipment_id, rh_equipments.equipment_type 
          FROM vessel_rh_equipment 
          JOIN rh_equipments 
          ON vessel_rh_equipment.equipment_id = rh_equipments.equipment_id 
          WHERE vessel_rh_equipment.vessel_id = $vessel_id";





$result = $conn->query($query);
if (!$result) {
    die('Database error on fetching vessel: ' . $conn->error);
}


$result = $conn->query($query);
$linkedEquipment = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $linkedEquipment[] = $row;
    }
} else {
    // echo 'No linked equipments for this vessel.';
}



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/vessel_link_to_equipment_style.css">
</head>

<body>
<?php include 'header.php'; ?>
    <main class="vessel-link-equipment-container">
        <div class="row">
            <form action="link_vessel_equipment.php" method="POST" class="col s6 offset-s3">
                <label for="vessel">Selected Vessel:</label>
                <select name="vessel_id" id="vessel" class="dropdown" disabled>
                    <option value="<?php echo $vessel['id']; ?>" selected><?php echo $vessel['vessel_name']; ?></option>
                </select>
                <input type="hidden" name="vessel_id" value="<?php echo $vessel['id']; ?>">


                <div class="card">
                    <div class="card-content">
                        <span class="card-title">Select Machineries Set:</span>
                        <div class="checkbox-group">
                            <label>
                                <input type='checkbox' name='equipment_sets[]' value='propulsion1' />
                                <span>Propulsion 1 Set (Engine 1, Gearbox 1, Z-peller 1)</span>
                            </label><br>
                            <label>
                                <input type='checkbox' name='equipment_sets[]' value='propulsion2' />
                                <span>Propulsion 2 Set (Engine 2, Gearbox 2, Z-peller 2)</span>
                            </label><br>
                            <label>
                                <input type='checkbox' name='equipment_sets[]' value='auxiliary1' />
                                <span>Auxiliary 1 Set (Generator 1)</span>
                            </label><br>
                            <label>
                                <input type='checkbox' name='equipment_sets[]' value='auxiliary2' />
                                <span>Auxiliary 2 Set (Generator 2)</span>
                            </label><br>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn-small waves-effect waves-light">
                    <i class="material-icons left">link</i> Link
                </button>
                <!-- <input type="submit" class="btn-small waves-effect waves-light" value="Link"> -->
            </form>
        </div>
        <div class="grid-x grid-padding-x">
            <div class="medium-6 cell medium-offset-3">
                <h5>List of Linked Machineries for <?php echo $vessel['vessel_name']; ?></h5>
                <table>
                    <thead>
                        <tr>
                            <th>Machineries Name</th>
                            <!-- <th>Actions</th> -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $displayedEquipmentTypes = [];  // Temporary array para itrack ang displayed na equipment types

                        foreach ($linkedEquipment as $equipment) {
                            if (!in_array($equipment['equipment_type'], $displayedEquipmentTypes)) {
                                echo "<tr>";
                                echo "<td>" . $equipment['equipment_type'] . "</td>";
                                echo "</tr>";
                                
                                // I-add sa array ang equipment_type para hindi na ulitin
                                $displayedEquipmentTypes[] = $equipment['equipment_type'];
                            }
                        }
                        ?>
                    </tbody>


                </table>

                <a href="edit_link.php?vessel_id=<?php echo $vessel_id; ?>" class="btn-small waves-effect waves-light blue-grey darken-2">
                                    <i class="material-icons left">edit</i> Edit
                                </a>
                                <a href="delete_link.php?vessel_id=<?php echo $vessel_id; ?>" class="btn-small waves-effect waves-light red" onclick="return confirm('Are you sure you want to unlink this equipment?');">
                                    <i class="material-icons left">delete</i> Unlink
                                </a>
                                <a href="vessel_maintenance.php?id=<?php echo $vessel_id; ?>" class="btn-small waves-effect waves-light"><i class="material-icons left">arrow_back</i>Back to Vessel Details</a>

            </div>
        </div>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);

            var elems = document.querySelectorAll('select');
            var instances = M.FormSelect.init(elems);

            // Toast initialization
            <?php if (isset($_SESSION['vessel_error'])) : ?>
                M.toast({html: '<?php echo $_SESSION['vessel_error']; ?>', classes: 'rounded red lighten-2', displayLength: 2000});
                <?php unset($_SESSION['vessel_error']); ?>
            <?php endif; ?>
        });

        $(document).ready(function() {
            $('.view-link').click(function(e) {
                e.preventDefault();
                let vessel_id = $(this).data('id');
                $.ajax({
                    url: "view_linked_equipment.php",  // Replace with your actual PHP file for viewing linked equipment
                    type: "POST",
                    data: { vessel_id: vessel_id },
                    success: function(response) {
                        // You can display the linked equipment in a modal or another div
                        alert("Linked Equipment: " + response);  // Replace this with better UI
                    }
                });
            });
        });
        </script>
</body>

</html>
