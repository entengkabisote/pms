<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit;
}

include 'db_connect.php'; // Connection to the database

// Check if a user ID is set in the session
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Check if the user is an admin or superuser
    if ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'superuser') {
        // Query to select all vessels since the user is admin or superuser
        $query = "SELECT * FROM vessels";
    } else {
        // Modify the query to select only the vessels assigned to the logged-in user
        $query = "SELECT vessels.* FROM vessels 
                  JOIN users_vessels ON vessels.id = users_vessels.vessel_id 
                  WHERE users_vessels.user_id = ?";
    }

    if ($stmt = mysqli_prepare($conn, $query)) {
        if ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'superuser') {
            mysqli_stmt_bind_param($stmt, 'i', $user_id);
        }
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
    } else {
        // Display an error message if the statement couldn't be prepared
        echo 'Error while preparing the statement: ' . htmlspecialchars(mysqli_error($conn));
        exit; // Terminate the script if there is an SQL error
    }
} else {
    // If there is no user ID in the session, set an error message
    $_SESSION['error_message'] = 'No user ID found.';
    header('Location: login.php');
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/general_index.css">
</head>
<body>
    <?php include 'header.php'; ?>

    <main class="index-container">
    <div class="row">
        <?php
        if (isset($result) && mysqli_num_rows($result) > 0) {
            while ($ship = mysqli_fetch_assoc($result)) {
                ?>
                <!-- <div class="col s12 m6 l4"> -->
                    <div class="card">
                        <div class="card-image">
                            <!-- <a href="vessel_details.php?vessel_id=<?php echo $ship['id']; ?>"> -->
                            <a href="#modal1" class="modal-trigger" data-image="<?php echo $ship['imahe']; ?>">
                                <img src="<?php echo $ship['imahe']; ?>" alt="<?php echo $ship['vessel_name']; ?>">
                                <span class="vessel-name"><?php echo $ship['vessel_name']; ?></span>
                            </a>
                        </div>
                        <div class="card-content">
                            <p><strong>Name:</strong> <?php echo $ship['vessel_name']; ?></p>
                            <p><strong>Type:</strong> <?php echo $ship['ship_type']; ?></p>
                            <p><strong>Home Port:</strong> <?php echo $ship['home_port']; ?></p>
                            <p><strong>Year Built:</strong> <?php echo $ship['year_built']; ?></p>
                            <p><strong>Country:</strong> <?php echo $ship['flag']; ?></p>
                            <p><strong>Owner:</strong> <?php echo $ship['owner']; ?></p>
                        </div>
                        <div class="card-action">
                        
                            <a href="vessel_maintenance.php?id=<?php echo $ship['id']; ?>">View More</a>
                        </div>
                    </div>
                <!-- </div> -->
                <?php
            }
        } else {
            echo '<p class="center-align">No ships assigned to you.</p>';
        }
        ?>
    </div>
</main>


    <div id="modal1" class="modal">
        <div class="modal-content">
            <img id="modal-image" src="" alt="">
            <div id="modal-vessel-details">
                <h5 id="modal-vessel-name"></h5>
            </div>
        </div>
    </div>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.modal');
            var instances = M.Modal.init(elems);

            // Listen to the click event for all 'modal-triggers'
            var modalTriggers = document.querySelectorAll('.modal-trigger');
            modalTriggers.forEach(function(trigger) {
                trigger.addEventListener('click', function(e) {
                    const imageSrc = e.currentTarget.getAttribute('data-image');
                    const vesselName = e.currentTarget.querySelector('.vessel-name').innerText;

                    document.getElementById('modal-image').src = imageSrc;
                    document.getElementById('modal-vessel-name').innerText = vesselName;
                });
            });
        });


        document.querySelector('.modal-trigger').addEventListener('click', function(e) {
            const imageSrc = e.currentTarget.getAttribute('data-image');
            const vesselName = e.currentTarget.querySelector('.vessel-name').innerText;

            document.getElementById('modal-image').src = imageSrc;
            document.getElementById('modal-vessel-name').innerText = vesselName;
        });



        </script>
</body>
</html>
