<?php
include 'db_connect.php';

if(isset($_POST['meta_id'])) {
    $meta_id = $_POST['meta_id'];
    $equipment_id = $_POST['equipment_id'];
    $inspection_type = $_POST['inspection_type'];
    $inspection_interval = $_POST['inspection_interval'];
    $person_in_charge = $_POST['person_in_charge'];
    $criticality = $_POST['criticality'];

    // Update existing record
    $sql = "UPDATE inspection_meta_table SET equipment_id=?, inspection_type=?, inspection_interval=?, person_in_charge=?, criticality=? WHERE meta_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issssi", $equipment_id, $inspection_type, $inspection_interval, $person_in_charge, $criticality, $meta_id);

    if($stmt->execute()) {
        echo json_encode(array("status" => "success", "message" => "Data updated successfully!"));
    } else {
        echo json_encode(array("status" => "error", "message" => "Failed to update data."));
    }
} else {
    echo json_encode(array("status" => "error", "message" => "Invalid data provided."));
}
?>
