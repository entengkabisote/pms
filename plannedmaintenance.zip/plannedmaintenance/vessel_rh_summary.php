<?php
session_start();
include "db_connect.php";

if (isset($_POST['vessel_id'])) {
    $vessel_id = $_POST['vessel_id'];
    // ... other code ...
} else {
    // handle the error, maybe redirect back or show an error message
}


    // Fetch vessel name using the vessel_id
    // $vessel_id = $row['vessel_id'];
    $vessel_query = "SELECT vessel_name FROM vessels WHERE id = $vessel_id";
    $vessel_result = mysqli_query($conn, $vessel_query);
    if (!$vessel_result) {
        die("Query failed: " . mysqli_error($conn));
    }
    $vessel_row = mysqli_fetch_assoc($vessel_result);


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selected_vessel = $_POST['vessel_id'];
    $selected_month = $_POST['month'];
    $selected_year = $_POST['year'];

    $stmt = $conn->prepare("SELECT r.*, t.task_description FROM running_hours_entries r 
                        JOIN tasks t ON r.task_id = t.task_id 
                        WHERE r.vessel_id = ? AND MONTH(r.date) = ? AND YEAR(r.date) = ?");
    $stmt->bind_param("iii", $selected_vessel, $selected_month, $selected_year);
    $stmt->execute();
    $result1 = $stmt->get_result();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/admiral.css">
    <style>

        /* Set individual column widths */
        th:nth-child(1) { width: 10%; }
        th:nth-child(2) { width: 12%; }
        th:nth-child(3) { width: 55%; }
        th:nth-child(4) { width: 8%; }
        th:nth-child(5) { width: 8%; }
        th:nth-child(6) { width: 7%; }
    </style>
</head>

<body>
<?php include 'header.php'; ?>
    <h5 class="text-center">Vessel Name: <?php echo $vessel_row['vessel_name']; ?></h5>
    <main class="table-container">
        <div class="grid-container">
            <a class="btn-small waves-effect waves-light" href="vessel_summary.php?id=<?php echo $vessel_id; ?>"> <i class="material-icons left">arrow_back</i>Back to Vessel List</a>
            <!-- <a href="vessel_summary.php" class="button">Back to Vessel List</a> -->
            <table>
                <thead>
                    <tr>
                        <th>Equipment Type</th>
                        <th>Equipment Name</th>
                        <th>Task</th>
                        <th>Threshold Hour</th>
                        <th>Date</th>
                        <th>Running Hours</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (isset($result1) && $result1->num_rows > 0) {
                        $prev_equipment_type = '';

                        while ($row = $result1->fetch_assoc()) {
                            if ($prev_equipment_type != $row['equipment_type']) {
                                echo "<tr><td colspan='6'><strong>" . $row['equipment_type'] . "</strong></td></tr>";
                                $prev_equipment_type = $row['equipment_type'];
                            }
                            
                            echo "<tr>";
                            echo "<td></td>"; // Blank cell for Equipment Type
                            echo "<td>" . $row['equipment_name'] . "</td>";
                            echo "<td>" . $row['task_description'] . "</td>";
                            echo "<td>" . $row['threshold_hours'] . "</td>";
                            echo "<td>" . $row['date'] . "</td>";
                            echo "<td>" . $row['running_hours'] . "</td>";
                            // echo "<td><input type='text' placeholder='dd/mm/yyyy'></td>";
                            // echo "<td><input type='text'></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6'>No data found!</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

        
        </script>
</body>

</html>
