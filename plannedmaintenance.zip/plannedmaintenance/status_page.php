<?php
include "db_connect.php";
$vessel_id = $_GET['id'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/general.css">
    <style>
        .custom-btn {
            float: right;
            margin-top: 20px;
            margin-right: 20px;
        }

    </style>
</head>

<body>
<?php include 'header.php'; ?>
    <div>
        <a class="btn-small waves-effect waves-light custom-btn" href="vessel_maintenance.php?id=<?php echo $vessel_id; ?>"> <i class="material-icons left">arrow_back</i>Back</a>
    </div>
    <main class="index-container">
        <div class="grid-container">
            <div class="grid-x grid-margin-x grid-padding-y">
                <div class="cell">
                    
                    <form method="GET" action="status_results.php">
                    <input type="hidden" id="vessel_id" name="vessel_id" value="<?php echo $vessel_id; ?>">
                        <!-- <select name="vessel_id" class="select">
                            <?php
                            $vessels = $conn->query("SELECT DISTINCT ve.vessel_id, v.vessel_name FROM vessel_rh_equipment ve JOIN vessels v ON ve.vessel_id = v.id");
                            while ($vessel = $vessels->fetch_assoc()) {
                                echo "<option value='{$vessel['vessel_id']}'>{$vessel['vessel_name']}</option>";
                            }
                            ?>
                        </select> -->
                        <h5>Select Status:</h5>
                        <div class="button-group">
                            <button type="submit" name="status" value="Completed" class="btn blue">Completed</button>
                            <button type="submit" name="status" value="On Track" class="btn green">On Track</button>
                            <button type="submit" name="status" value="Due Soon" class="btn orange">Due Soon</button>
                            <button type="submit" name="status" value="Over Due" class="btn red">Over Due</button>
                        </div>
                        
                    </form>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

        
        </script>
</body>

</html>
