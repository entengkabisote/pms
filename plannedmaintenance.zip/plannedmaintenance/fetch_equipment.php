<?php
include 'db_connect.php';

$vessel_id = $_GET['vessel_id'];
$category = $_GET['category'];

$sql = "SELECT * FROM vessel_equipment 
        INNER JOIN equipment_table ON vessel_equipment.equipment_id = equipment_table.equipment_id
        INNER JOIN inspection_meta_table ON vessel_equipment.inspection_meta_id = inspection_meta_table.meta_id
        WHERE vessel_id = ? AND category = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $vessel_id, $category);
$stmt->execute();
$result = $stmt->get_result();
?>

<!-- HTML for the table -->
<table border="1">
    <tr>
        <th rowspan="2" style="width:45%; text-align:center; background-color: lightgray"><?php echo $category; ?></th>
        <th rowspan="2" style="width:8%; text-align:center; background-color: lightgray">Interval of Checks / Testing</th>
        <th rowspan="2" style="width:8%; text-align:center; background-color: lightgray">Person in Charge</th>
        <th rowspan="2" style="width:7%; text-align:center; background-color: lightgray">Criticality</th>
        <th colspan="5" style="width:32%; text-align:center; background-color: lightgray">Inspection Date</th>
    </tr>
    <tr>
        <th style="width:5%; text-align:center; background-color: lightgray">1st</th>
        <th style="width:5%; text-align:center; background-color: lightgray">2nd</th>
        <th style="width:5%; text-align:center; background-color: lightgray">3rd</th>
        <th style="width:5%; text-align:center; background-color: lightgray">4th</th>
        <th style="width:12%; text-align:center; background-color: lightgray">Remarks</th>
    </tr>
    <?php 
        $lastEquipmentName = ""; // variable to hold the last displayed equipment name
        while ($row = $result->fetch_assoc()): 
            $currentEquipmentName = $row['equipment_name'];
    ?>
        <?php if ($currentEquipmentName != $lastEquipmentName): ?>
            <tr>
                <td style="font-weight: bold;"><?php echo $currentEquipmentName; ?></td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
    <?php endif; ?>
    <?php
    // Update the last displayed equipment name
    $lastEquipmentName = $currentEquipmentName;
    ?>
            <tr>
                <td><?php echo $row['inspection_type']; ?></td>
                <td style="text-align:center"><?php echo $row['inspection_interval']; ?></td>
                <td style="text-align:center"><?php echo $row['person_in_charge']; ?></td>
                <td style="text-align:center"><?php echo $row['criticality']; ?></td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
    <?php endwhile; ?>
</table>
