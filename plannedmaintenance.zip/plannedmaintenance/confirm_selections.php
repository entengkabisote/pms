<?php
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_POST['equipment']) || empty($_POST['equipment'])) {
        echo "<script>
            alert('No equipment selected.');
            window.history.go(-1); // This will send the user back to the previous page
        </script>";
        exit(); // Stop the script from processing further
    } else {
        $selectedEquipments = $_POST['equipment'];
    }

    if (isset($_POST['vessel_id'])) {
        $vessel_id = $_POST['vessel_id'];
    } else {
        // Handle error if 'vessel_id' isn't set, if needed
    }
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Confirm Selections</title>
    <!-- Materialize CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <style>
        .container {
            width: 80%;
            margin: 40px auto;
            padding-bottom: 50px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h5>Confirm Equipment to Add</h5>
        
        <ul>
            <?php
            foreach ($selectedEquipments as $equipment_id) {
                $sql = "SELECT equipment_name FROM equipment_table WHERE equipment_id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $equipment_id);
                $stmt->execute();
                $result = $stmt->get_result();
                $row = $result->fetch_assoc();
                echo '<li>' . $row['equipment_name'] . '</li>';
            }
            ?>
        </ul>

        <form action="save_equipment_to_vessel.php" method="post">
            <input type="hidden" name="vessel_id" value="<?php echo htmlspecialchars($vessel_id); ?>">

            <?php
            foreach ($selectedEquipments as $equipment_id) {
                // Isama ang hidden field para sa equipment
                echo '<input type="hidden" name="equipment[]" value="' . htmlspecialchars($equipment_id) . '">';

                // See if there are inspection types selected for this equipment
                if (isset($_POST['inspection_types'][$equipment_id])) {
                    foreach ($_POST['inspection_types'][$equipment_id] as $meta_id) {
                        // Include the hidden field for each selected inspection type
                        echo '<input type="hidden" name="inspection_types[' . htmlspecialchars($equipment_id) . '][]" value="' . htmlspecialchars($meta_id) . '">';
                    }
                }
            }
            ?>
            <button type="submit" class="btn waves-effect waves-light">Confirm and Save to Vessel</button>
        </form>
    </div>

    <!-- Materialize JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>
</html>
