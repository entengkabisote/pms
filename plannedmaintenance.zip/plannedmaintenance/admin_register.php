<?php
include 'db_connect.php';
require 'vendor/autoload.php';

if (isset($_POST['register'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = 'user';

    $stmt = $conn->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $username, $email, $password, $role);

    if ($stmt->execute()) {
        $last_id = $conn->insert_id;
        $verification_link = "http://yourwebsite.com/verify.php?id=" . $last_id;

        $mail = new PHPMailer\PHPMailer\PHPMailer();
        $mail->Mailer = 'smtp';
        $mail->Host = "smtp.gmail.com";
        $mail->SMTPAuth = true;
        $mail->Username = "your-email@gmail.com";
        $mail->Password = "your-password";
        $mail->SMTPSecure = "tls";
        $mail->Port = 587;
        $mail->SetFrom("your-email@gmail.com", "Your Name");
        $mail->AddAddress($email);
        $mail->Subject = "Email Verification";
        $mail->Body = "Click this link to verify your email: " . $verification_link;

        if ($mail->Send()) {
            echo "Registered successfully. Please verify your email.";
        } else {
            echo "Email not sent. " . $mail->ErrorInfo;
        }

    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
?>

<form method="POST" action="">
  <input type="text" name="username" placeholder="Username" required><br>
  <input type="email" name="email" placeholder="Email" required><br>
  <input type="password" name="password" placeholder="Password" required><br>
  <button type="submit" name="register">Register</button>
</form>
