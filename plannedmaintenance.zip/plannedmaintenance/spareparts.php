<?php
session_start();

include 'db_connect.php';

// Get the task_id and equipment_id from the URL
$task_id = isset($_GET['id']) ? $_GET['id'] : 0;
$equipment_id = isset($_GET['equipment_id']) ? $_GET['equipment_id'] : 0;

// Use $task_id and $equipment_id to get the data you need
// For example, query the database for spare parts of this equipment

// Initialize an empty array to store the spare parts
$spareParts = [];

// Check if the task_id and equipment_id are valid
if ($task_id > 0 && $equipment_id > 0) {
    // Query the database for spare parts for this specific equipment and task
    $query = "SELECT id, part_name, location, quantity FROM spare_parts WHERE task_id = ? AND equipment_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $task_id, $equipment_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Fetch all the spare parts
    while ($row = $result->fetch_assoc()) {
        $spareParts[] = $row;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spareparts | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/spareparts_style.css">
</head>
<body>
<?php include 'header.php'; ?>

    <main class="spareparts-container">
        <h5>Add Spare Parts for Equipment</h5>
        <form action="add_spareparts.php" method="post">
            <!-- Hidden fields to pass task_id and equipment_id -->
            <input type="hidden" name="task_id" value="<?php echo $task_id; ?>">
            <input type="hidden" name="equipment_id" value="<?php echo $equipment_id; ?>">
            
            <!-- Button to add spare parts -->
            <button type="button" id="addSparePart" class="btn-small waves-effect waves-light add-spareparts">Add Spare Part</button>

            <div id="sparePartsContainer">
                <!-- Dynamically added spare parts fields will be placed here -->
            </div>

            <button type="submit" class="btn-small waves-effect waves-light custom-submit">Submit Spare Parts</button>
            <button class="btn-small waves-effect waves-light" type="button" onclick="location.href='rh_tasks.php?equipment_id=<?php echo $equipment_id; ?>'"> <i class="material-icons left">arrow_back</i> Back </button>
        </form>

        <div class="spare-parts-list-section">
            <h5>Current Spare Parts</h5>
            <table class="highlight" style="width:80%; margin:auto; margin-top:20px;">
                <thead>
                    <tr>
                        <th style="width:50%;">Part Name</th>
                        <th style="width:25%;">Location</th>
                        <th style="width:10%; text-align:center;">Quantity</th>
                        <th style="width:15%; text-align:center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($spareParts as $part): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($part['part_name']); ?></td>
                            <td><?php echo htmlspecialchars($part['location']); ?></td>
                            <td style="text-align:center;"><?php echo htmlspecialchars($part['quantity']); ?></td>
                            <td style="text-align:center;">
                                <div style="display:flex; gap:5px; justify-content:center;">
                                    <!-- Edit button -->
                                    <a href="edit_sparepart.php?id=<?php echo $part['id']; ?>&task_id=<?php echo $task_id; ?>&equipment_id=<?php echo $equipment_id; ?>" class="btn-small waves-effect waves-light blue">
                                        <i class="material-icons">edit</i>
                                    </a>

                                    <!-- Delete form and button -->
                                    <button type="button" class="delete-btn btn-small waves-effect waves-light red" data-id="<?php echo $part['id']; ?>" data-task_id="<?php echo $task_id; ?>" data-equipment_id="<?php echo $equipment_id; ?>">
                                        <i class="material-icons">delete</i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($spareParts)): ?>
                        <tr>
                            <td colspan="4">No spare parts added yet.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

        // jQuery for dynamic spare parts fields
        $(document).ready(function(){
            $('#addSparePart').click(function(){
                $('#sparePartsContainer').append(
                    '<div class="input-field">' +
                        '<input type="text" name="spare_parts[]" placeholder="Spare Part Name" required>' +
                        '<input type="text" name="locations[]" placeholder="Location" required>' +
                        '<input type="text" name="quantities[]" placeholder="Quantity" required>' +
                        '<button type="button" class="removePart btn-small red"><i class="material-icons">remove</i></button>' +
                    '</div>'
                );
            });

            $('form').submit(function(e) {
                e.preventDefault(); // Prevent the normal form submission

                var formData = new FormData(this); // Create a FormData object, which supports file uploads

                $.ajax({
                    url: 'add_spareparts.php', // The file where you handle the form input.
                    type: 'POST',
                    data: formData,
                    contentType: false, // This is required for FormData
                    processData: false, // This is required for FormData
                    success: function(response) {
                        // Assuming 'response' is a success message or the ID of the new spare part
                        // You might want to return the new spare part data in JSON format from 'add_spareparts.php'
                        // For now, let's just reload the spare parts list section to show the new entry
                        location.reload(); // This will reload the page, you can replace this with code to update the table dynamically as mentioned previously
                    },
                    error: function(xhr, status, error) {
                        // Handle errors here
                        console.log(xhr.responseText); // For debugging
                        alert('Error: ' + status + ' - ' + error);
                    }
                });
            });

            // Event handler for delete button
            $('.delete-btn').click(function(){
                // Confirm delete action
                if(!confirm('Are you sure you want to delete this spare part?')) {
                    return false;
                }

                var btn = $(this); // The delete button
                var part_id = btn.data('id');
                var task_id = btn.data('task_id');
                var equipment_id = btn.data('equipment_id');

                $.ajax({
                    url: 'delete_sparepart.php', // Your PHP file to handle the deletion
                    type: 'POST',
                    data: {
                        id: part_id,
                        task_id: task_id,
                        equipment_id: equipment_id
                    },
                    success: function(response) {
                        // Assuming your delete_sparepart.php echoes "success" on successful deletion
                        if(response.trim() == 'success'){
                            btn.closest('tr').fadeOut(300, function(){ 
                                $(this).remove(); // Remove the row from the table
                            });
                        } else {
                            alert('Error deleting spare part.');
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred: ' + error);
                    }
                });
            });

            // Logic to remove a spare part field
            $('body').on('click', '.removePart', function(){
                $(this).parent('div').remove();
            });
        });
    </script>
</body>
</html>
