<?php
// include the configuration file
require_once 'config.php'; // Include the config file to use SMTP credentials

// Local Connection
// require_once 'C:\wamp64\www\plannedmaintenance\config.php';

// require_once '/home/smscorp/secure_config/config.php';

// Create connection using defined constants
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Set the charset for the connection
$conn->set_charset("utf8mb4");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
