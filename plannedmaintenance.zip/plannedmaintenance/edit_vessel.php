<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', '1');


include 'db_connect.php';

// Fetch vessel details if id is provided
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM vessels WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $vessel = $stmt->get_result()->fetch_assoc();
}

// $imahe = isset($vessel['imahe']) ? $vessel['imahe'] : '';


// If form is submitted, update the vessel details
if ($_SERVER['REQUEST_METHOD'] == "POST") {

    $vessel_name = $_POST['vessel_name'];
    $official_number = $_POST['official_number'];
    $owner = $_POST['owner'];
    $IMO_number = $_POST['imo_number'];
    $classification_number = $_POST['classification_number'];
    $ship_type = $_POST['ship_type'];
    $home_port = $_POST['home_port'];
    $gross_tonnage = $_POST['gross_tonnage'];
    $net_tonnage = $_POST['net_tonnage'];
    $bollard_pull = $_POST['bollard_pull'];
    $length_overall = $_POST['length_overall'];
    $breadth = $_POST['breadth'];
    $depth = $_POST['depth'];
    $year_built = $_POST['year_built'];
    $main_engine_make = $_POST['main_engine_make'];
    $main_engine_model = $_POST['main_engine_model'];
    $main_engine_number = $_POST['main_engine_number'];
    $engine_power = $_POST['engine_power'];
    $aux_engine_make = $_POST['aux_engine_make'];
    $aux_engine_model = $_POST['aux_engine_model'];
    $aux_engine_number = $_POST['aux_engine_number'];
    $aux_engine_power = $_POST['aux_engine_power'];
    $flag = $_POST['flag'];
    $builder = $_POST['builder'];
    $trading_area = $_POST['trading_area'];
    $hull_material = $_POST['hull_material'];
    $drive = $_POST['drive'];
    $max_speed = $_POST['max_speed'];
    $insurance = $_POST['insurance'];
    $isps_compliance = isset($_POST['ISPS_compliance']) ? 1 : 0;
    $iso_9001_2015 = isset($_POST['ISO_9001_2015']) ? 1 : 0;

    if (isset($_FILES['imahe']) && $_FILES['imahe']['error'] == 0) {
        $temp_name = $_FILES['imahe']['tmp_name'];
        $name = $_FILES['imahe']['name'];
        $size = $_FILES['imahe']['size'];
    
        if ($size <= 5000000) {
            $dir_upload = 'uploads/';
            $new_image_name = time() . '_' . pathinfo($name, PATHINFO_FILENAME) . '.' . pathinfo($name, PATHINFO_EXTENSION);
            $complete_image_path = $dir_upload . $new_image_name;  // this will be the value that will be saved in the database
            move_uploaded_file($temp_name, $complete_image_path);
    
            // Update the imahe name to the new uploaded imahe
            $imahe = $new_image_name;
        } else {
            echo "File is too large!";
        }
    }

    if (!isset($complete_image_path) && isset($vessel['imahe'])) {
        $complete_image_path = $vessel['imahe'];
    }
    
    
    $sql_img = "UPDATE vessels SET imahe=? WHERE id=?";
    $stmt_img = $conn->prepare($sql_img);
    $stmt_img->bind_param("si", $complete_image_path, $id);  // use $complete_image_path to include the folder name
    if ($stmt_img->execute()) {
        echo "Image updated successfully!";
    } else {
        echo "Error updating image: " . $conn->error;
    }

    

    // $sql = "UPDATE vessels SET vessel_name=?, official_number=?, owner=?, IMO_number=?, classification_number=?, ship_type=?, home_port=?, gross_tonnage=?, net_tonnage=?, length_overall=?, breadth=?, depth=?, year_built=?, main_engine_make=?, main_engine_model=?, main_engine_number=?, engine_power=?, drive=?, flag=?, builder=?, trading_area=?, hull_material=?, max_speed=?, insurance=?, ISPS_compliance=?, ISO_9001_2015=?, imahe=?  WHERE id=?";
    $sql = "UPDATE vessels SET vessel_name=?, official_number=?, owner=?, IMO_number=?, classification_number=?, ship_type=?, home_port=?, gross_tonnage=?, net_tonnage=?, length_overall=?, breadth=?, depth=?, year_built=?, main_engine_make=?, main_engine_model=?, main_engine_number=?, engine_power=?, drive=?, flag=?, builder=?, trading_area=?, hull_material=?, max_speed=?, insurance=?, ISPS_compliance=?, ISO_9001_2015=?, bollard_pull=?, aux_engine_make=?, aux_engine_model=?, aux_engine_number=?, aux_engine_power=?  WHERE id=?";
    $stmt = $conn->prepare($sql);
    // echo "Image before bind_param: " . $imahe;
    // echo "ID: " . $id . "<br>";

    // $stmt->bind_param("sssssssdddddssssdsssssdsiiis", $vessel_name, $official_number, $owner, $IMO_number, $classification_number, $ship_type, $home_port, $gross_tonnage, $net_tonnage, $length_overall, $breadth, $depth, $year_built, $main_engine_make, $main_engine_model, $main_engine_number, $engine_power, $drive, $flag, $builder, $trading_area, $hull_material,  $max_speed, $insurance, $isps_compliance, $iso_9001_2015, $imahe, $id);
    $stmt->bind_param("sssssssdddddssssssssssdsiisssssi", $vessel_name, $official_number, $owner, $IMO_number, $classification_number, $ship_type, $home_port, $gross_tonnage, $net_tonnage, $length_overall, $breadth, $depth, $year_built, $main_engine_make, $main_engine_model, $main_engine_number, $engine_power, $drive, $flag, $builder, $trading_area, $hull_material,  $max_speed, $insurance, $isps_compliance, $iso_9001_2015, $bollard_pull, $aux_engine_make, $aux_engine_model, $aux_engine_number, $aux_engine_power, $id);

    
    if ($stmt->execute()) {
        $_SESSION['feedback'] = "Vessel details updated successfully!";
    } else {
        $_SESSION['error'] = "Error updating vessel details: " . $conn->error;
    }

    header("Location: vessel_details.php?id=$id");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/edit_vessel_styles.css">
    <link rel="stylesheet" href="styles/buttons.css">
    <style>
        main.container {
        padding-bottom: 50px;
        margin-top: 40px;
        margin-bottom: 40px;
    }

    </style>
</head>

<body>
<?php include 'header.php'; ?>
    <div>
        <h5>Edit Vessel Details</h5>
    </div>

    <?php if (!empty($imahe)) { ?>
        <div class="input-field col s12">
            <img src="uploads/<?php echo $imahe; ?>" width="200px" alt="Current Image">
        </div>
    <?php } ?>

<!-- ************************* -->
    <main class="edit-vessel-details-container">
<!-- ************************* -->
    
        <form action="edit_vessel.php?id=<?php echo $id; ?>" method="post" enctype="multipart/form-data">


            <div class="row">

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="vessel_name">Vessel Name</label>
                        <input type="text" id="vessel_name" name="vessel_name" value="<?php echo isset($vessel['vessel_name']) ? $vessel['vessel_name'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="official_number">Official Number</label>
                        <input type="text" id="official_number" name="official_number" value="<?php echo isset($vessel['official_number']) ? $vessel['official_number'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="owner">Owner</label>
                        <input type="text" id="owner" name="owner" value="<?php echo isset($vessel['owner']) ? $vessel['owner'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="imo_number">IMO Number</label>
                        <input type="text" id="imo_number" name="imo_number" value="<?php echo isset($vessel['IMO_number']) ? $vessel['IMO_number'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="classification_number">Classification Number</label>
                        <input type="text" id="classification_number" name="classification_number" value="<?php echo isset($vessel['classification_number']) ? $vessel['classification_number'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="ship_type">Ship Type</label>
                        <input type="text" id="ship_type" name="ship_type" value="<?php echo isset($vessel['ship_type']) ? $vessel['ship_type'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="home_port">Home Port</label>
                        <input type="text" id="home_port" name="home_port" value="<?php echo isset($vessel['home_port']) ? $vessel['home_port'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="gross_tonnage">Gross Tonnage</label>
                        <input type="text" id="gross_tonnage" name="gross_tonnage" value="<?php echo isset($vessel['gross_tonnage']) ? $vessel['gross_tonnage'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="net_tonnage">Net Tonnage</label>
                        <input type="text" id="net_tonnage" name="net_tonnage" value="<?php echo isset($vessel['net_tonnage']) ? $vessel['net_tonnage'] : ''; ?>">
                    </div>
                </div>

                <!-- Bollard Pull -->
                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="bollard_pull">Bollard Pull</label>
                        <input type="text" id="bollard_pull" name="bollard_pull" value="<?php echo isset($vessel['bollard_pull']) ? $vessel['bollard_pull'] : ''; ?>">
                    </div>
                </div>
                
                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="length_overall">Length Overall</label>
                        <input type="text" id="length_overall" name="length_overall" value="<?php echo isset($vessel['length_overall']) ? $vessel['length_overall'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="breadth">Breadth</label>
                        <input type="text" id="breadth" name="breadth" value="<?php echo isset($vessel['breadth']) ? $vessel['breadth'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="depth">Depth</label>
                        <input type="text" id="depth" name="depth" value="<?php echo isset($vessel['depth']) ? $vessel['depth'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="year_built">Year Built</label>
                        <input type="text" id="year_built" name="year_built" value="<?php echo isset($vessel['year_built']) ? $vessel['year_built'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="main_engine_make">Main Engine Make</label>
                        <input type="text" id="main_engine_make" name="main_engine_make" value="<?php echo isset($vessel['main_engine_make']) ? $vessel['main_engine_make'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="main_engine_model">Main Engine Model</label>
                        <input type="text" id="main_engine_model" name="main_engine_model" value="<?php echo isset($vessel['main_engine_model']) ? $vessel['main_engine_model'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="main_engine_number">Main Engine Number</label>
                        <input type="text" id="main_engine_number" name="main_engine_number" value="<?php echo isset($vessel['main_engine_number']) ? $vessel['main_engine_number'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="engine_power">Engine Power</label>
                        <input type="text" id="engine_power" name="engine_power" value="<?php echo isset($vessel['engine_power']) ? $vessel['engine_power'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="aux_engine_make">Auxiliary Engine Make</label>
                        <input type="text" id="aux_engine_make" name="aux_engine_make" value="<?php echo isset($vessel['aux_engine_make']) ? $vessel['aux_engine_make'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="aux_engine_model">Auxiliary Engine Model</label>
                        <input type="text" id="aux_engine_model" name="aux_engine_model" value="<?php echo isset($vessel['aux_engine_model']) ? $vessel['aux_engine_model'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="aux_engine_number">Auxiliary Engine Number</label>
                        <input type="text" id="aux_engine_number" name="aux_engine_number" value="<?php echo isset($vessel['aux_engine_number']) ? $vessel['aux_engine_number'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="aux_engine_power">Auxiliary Engine Power</label>
                        <input type="text" id="aux_engine_power" name="aux_engine_power" value="<?php echo isset($vessel['aux_engine_power']) ? $vessel['aux_engine_power'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="drive">Drive</label>
                        <input type="text" id="drive" name="drive" value="<?php echo isset($vessel['drive']) ? $vessel['drive'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="flag">Flag</label>
                        <input type="text" id="flag" name="flag" value="<?php echo isset($vessel['flag']) ? $vessel['flag'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="builder">Builder</label>
                        <input type="text" id="builder" name="builder" value="<?php echo isset($vessel['builder']) ? $vessel['builder'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="trading_area">Trading Area</label>
                        <input type="text" id="trading_area" name="trading_area" value="<?php echo isset($vessel['trading_area']) ? $vessel['trading_area'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="hull_material">Hull Material</label>
                        <input type="text" id="hull_material" name="hull_material" value="<?php echo isset($vessel['hull_material']) ? $vessel['hull_material'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="max_speed">Maximum Speed</label>
                        <input type="text" id="max_speed" name="max_speed" value="<?php echo isset($vessel['max_speed']) ? $vessel['max_speed'] : ''; ?>">
                    </div>
                </div>

                <div class="input-field col s6">
                    <div class="input-group">
                        <label for="insurance">Insurance</label>
                        <input type="text" id="insurance" name="insurance" value="<?php echo isset($vessel['insurance']) ? $vessel['insurance'] : ''; ?>">
                    </div>
                </div>

                <div class="col s6">
                    <label>
                        <input type="checkbox" id="ISPS_compliance" name="ISPS_compliance" <?php echo isset($vessel['ISPS_compliance']) && $vessel['ISPS_compliance'] == 1 ? 'checked' : ''; ?>>
                        <span>ISPS Compliance</span>
                    </label>
                </div>

                <div class="col s6">
                    <label>
                        <input type="checkbox" id="ISO_9001_2015" name="ISO_9001_2015" <?php echo isset($vessel['ISO_9001_2015']) && $vessel['ISO_9001_2015'] == 1 ? 'checked' : ''; ?>>
                        <span>ISO 9001:2015</span>
                    </label>
                </div>

                <div class="input-field col s6">
                    <label for="imahe">Vessel Image (Optional, leave blank to keep current)</label>
                    <input type="file" id="imahe" name="imahe">
                </div>

                <div class="button-group col s12">
                    <button class="btn-small waves-effect waves-light" type="submit"> <i class="material-icons left">refresh</i> Update </button>
                    <button class="btn-small waves-effect waves-light" type="button" onclick="location.href='vessel_details.php?id=<?php echo $id; ?>'"> <i class="material-icons left">arrow_back</i> Back to Details </button>
                </div>
            </div>
            
        </form>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });
        </script>
</body>

</html>
