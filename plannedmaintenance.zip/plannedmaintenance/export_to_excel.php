<?php
require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

include 'db_connect.php';

$vessel_id = $_GET['vessel_id'];
$category = $_GET['category'];

// Run SQL query here and get data
$sql = "SELECT * FROM vessel_equipment 
        INNER JOIN equipment_table ON vessel_equipment.equipment_id = equipment_table.equipment_id
        INNER JOIN inspection_meta_table ON vessel_equipment.inspection_meta_id = inspection_meta_table.meta_id
        WHERE vessel_id = ? AND category = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $vessel_id, $category);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_all(MYSQLI_ASSOC);

// Now proceed to PhpSpreadsheet code
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();


$currentRow = 1;
$prevName = "";

foreach($data as $entry) {
    if ($entry['equipment_name'] != $prevName) {
        $sheet->setCellValue("A$currentRow", $entry['equipment_name']);
        $currentRow++;  // Move to the next row for the inspection details
        $prevName = $entry['equipment_name'];
    }
    
    $sheet->setCellValue("A$currentRow", $entry['inspection_type']);
    $sheet->setCellValue("B$currentRow", $entry['inspection_interval']);
    $currentRow++;  // Move to the next row for the next equipment or inspection
}



// Set Excel headers after you're done with everything else
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="equipment_inspection.xls"');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
?>
