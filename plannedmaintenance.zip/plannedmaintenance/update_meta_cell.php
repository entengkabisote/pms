<?php
file_put_contents('update_meta_trace.txt', "File was accessed.\n", FILE_APPEND);

include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid JSON payload']);
        exit;
    }

    // Access the data from the $data variable instead of $_POST
    $meta_id = $data['meta_id'];
    $column = $data['column'];
    $new_value = $data['new_value'];

    $allowed_columns = ['inspection_type', 'inspection_interval', 'person_in_charge', 'criticality'];

    if (!in_array($column, $allowed_columns)) {
        // Invalid column, send an error response
        echo json_encode(['status' => 'error', 'message' => 'Invalid column name']);
        exit;
    }

    if ($meta_id === null || $column === null || $new_value === null) {
        echo json_encode(['status' => 'error', 'message' => 'Missing parameters']);
        exit;
    }

    $stmt = $conn->prepare("UPDATE inspection_meta_table SET $column = ? WHERE meta_id = ?");
    if (!$stmt) {
        echo json_encode(['status' => 'error', 'message' => "Failed to prepare statement: " . $conn->error]);
        exit;
    }

    $stmt->bind_param("si", $new_value, $meta_id);
    
    if ($stmt->execute()) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => "Failed to execute statement: " . $stmt->error]);
    }
}
?>
