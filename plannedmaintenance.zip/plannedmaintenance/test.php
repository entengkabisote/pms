<?php
trigger_error("This is a test error!");
?>