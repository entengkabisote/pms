<?php
// Assuming session start is already called and user role is stored in session
$user_role = $_SESSION['role'] ?? 'user'; // Default to 'user' if not set

// Connect to database and fetch user profile based on session user_id
$user_id = $_SESSION['user_id'] ?? 0;
$stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$profile = $stmt->get_result()->fetch_assoc();

// Now you can use $profile to display user information

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/general.css">
</head>

<body>
<?php include 'header.php'; ?>

    <main class="index-container">
        <div class="container">
            <h2>User Profile</h2>
            <?php if ($user_role == 'admin' || $user_role == 'superuser'): ?>
                <p>Name: <?php echo htmlspecialchars($profile['name']); ?></p>
                <p>Email: <?php echo htmlspecialchars($profile['email']); ?></p>
                <?php if ($user_role == 'superuser'): ?>
                    <!-- Superuser can edit their profile -->
                    <a href="edit_profile.php" class="btn blue">Edit Profile</a>
                <?php elseif ($user_role == 'admin'): ?>
                    <!-- Admin can view all profiles but here you'd list them or link to the listing -->
                    <a href="view_all_users.php" class="btn grey">View All Users</a>
                <?php endif; ?>
            <?php else: ?>
                <p>You do not have access to view profiles.</p>
            <?php endif; ?>
        </div>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);

            var elems = document.querySelectorAll('select');
            var instances = M.FormSelect.init(elems);
        });

        
        </script>
</body>

</html>
