<?php
include 'db_connect.php';
session_start();

$message = '';
$redirectTo = 'add_interval.php';

if($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $csrf_token = $_POST['csrf_token'];

    // Verify CSRF token
    if (!isset($csrf_token) || $csrf_token !== $_SESSION['csrf_token']) {
        $message = "Invalid CSRF token!";
    } else {
        // Check if record exists
        $stmt = $conn->prepare("SELECT id FROM interval_table WHERE name = ?");
        $stmt->bind_param("s", $name);
        $stmt->execute();
        $stmt->store_result();

        if($stmt->num_rows > 0) {
            $message = "Record already exists!";
            $stmt->close();
        } else {
            $stmt->close();

            // Insert new record
            $stmt = $conn->prepare("INSERT INTO interval_table (name) VALUES (?)");
            $stmt->bind_param("s", $name);

            if ($stmt->execute()) {
                $message = "New record created successfully";
            } else {
                $message = "Error: " . $stmt->error;
            }
            $stmt->close();
        }
        $conn->close();
    }
}

$_SESSION['flash_message'] = $message;
header('Location: add_interval.php');
exit;

?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<script>
    // document.addEventListener('DOMContentLoaded', function() {
    //     M.toast({html: '<?php echo $message; ?>', classes: 'red darken-2', displayLength: 4000, completeCallback: function() { window.location.href = '<?php echo $redirectTo; ?>'; }});
    // });
</script>
