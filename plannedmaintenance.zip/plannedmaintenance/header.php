<div class="logo-header">
    <img src="images/smscorp.png" alt="Company Logo" class="logo">
    <h4 class="white-text">Strategic Maritime Solutions Corp.</h4>
</div>
    

    <nav class="blue-grey darken-2">
        <div class="nav-wrapper container">
            <ul class="center-align">
                <li><a href="index.php" class="white-text">Dashboard</a></li>
                <li><a href="equipment.php" class="white-text">Equipments</a></li>
                <li><a href="equipment_running_hours.php" class="white-text">Machineries</a></li>
                <li><a class="dropdown-trigger white-text" href="#!" data-target="settingsDropdown">Settings<i class="material-icons right">arrow_drop_down</i></a></li>
            </ul>
            <ul id="settingsDropdown" class="dropdown-content">
                <?php if ($_SESSION['role'] == 'admin') { ?>
                    <li><a href="add_interval.php">Interval Date</a></li>
                    <li><a href="vessel.php">Vessel Operations Panel</a></li>
                    <li><a href="user_management.php">User Management</a></li> <!-- Only for admin -->
                    <li class="divider"></li>
                <?php } elseif ($_SESSION['role'] == 'superuser') { ?>
                    <li><a href="add_interval.php">Interval Date</a></li>
                    <li><a href="vessel.php">Vessel Operations Panel</a></li>
                    <!-- Add other superuser specific links here if necessary -->
                    <li class="divider"></li>
                <?php } ?>
                <li><a href="logout.php">Logout</a></li>
            </ul>

        </div>
    </nav>

    <!-- User Welcome Message Below Navigation -->
<?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true): ?>
    <div class="welcome-message">
        <h2>Welcome, <?php echo isset($_SESSION['fullname']) ? htmlspecialchars($_SESSION['fullname']) : 'Guest'; ?>!</h2>
    </div>
<?php endif; ?>
