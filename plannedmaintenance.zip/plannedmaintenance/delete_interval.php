<?php
include 'db_connect.php';
session_start();

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}


$id = $_GET['id'];
$csrf_token = $_GET['csrf_token'];

// Verify CSRF token
if (!isset($csrf_token) || $csrf_token !== $_SESSION['csrf_token']) {
    die("Invalid CSRF token!");
}

$stmt = $conn->prepare("DELETE FROM interval_table WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    $_SESSION['flash_message'] = "Record deleted successfully";
} else {
    $_SESSION['flash_message'] = "Error deleting record: " . $stmt->error;
}
$stmt->close();
$conn->close();

header('Location: add_interval.php');
exit;
?>
