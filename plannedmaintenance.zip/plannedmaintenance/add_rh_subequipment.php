<?php
include 'db_connect.php';
$equipment_id = $_GET['equipment_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_GET['equipment_id'])) {
        $equipment_id = $_GET['equipment_id'];
    } else if (isset($_POST['equipment_id'])) {
        $equipment_id = $_POST['equipment_id'];
    } else {
        exit("No equipment_id provided");
    }

    $subequipment_name = $_POST['subequipment_name'];
    
    // Check for duplicates
    $sql_check = "SELECT subequipment_name FROM rh_subequipments WHERE main_equipment_id = ? AND subequipment_name = ?";
    $stmt_check = $conn->prepare($sql_check);
    $stmt_check->bind_param("is", $equipment_id, $subequipment_name);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();

    if ($result_check->num_rows > 0) {
        echo json_encode(['status' => 'Duplicate']);
        exit;
    }

    // If no duplicates, proceed to insert
    $stmt = $conn->prepare("INSERT INTO rh_subequipments (subequipment_name, main_equipment_id) VALUES (?, ?)");
    $stmt->bind_param("si", $subequipment_name, $equipment_id);

    if ($stmt->execute()) {
        $new_id = $conn->insert_id;
        echo json_encode(['status' => 'Success', 'id' => $new_id]);
    }
    
    $stmt->close();
    exit;
}


// $equipment_id = $_GET['equipment_id'];

// Fetch sub-equipment items related to the main_equipment_id
$sql = "SELECT * FROM rh_subequipments WHERE main_equipment_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $equipment_id);
$stmt->execute();
$result = $stmt->get_result();
$subequipments = $result->fetch_all(MYSQLI_ASSOC);

// Get equipment name
$eq_name_sql = "SELECT equipment_name FROM rh_equipments WHERE equipment_id = ?";
$eq_name_stmt = $conn->prepare($eq_name_sql);
$eq_name_stmt->bind_param("i", $equipment_id);
$eq_name_stmt->execute();
$eq_name_result = $eq_name_stmt->get_result();
if($eq_name_result->num_rows > 0) {
    $row = $eq_name_result->fetch_assoc();
    $equipment_name = $row['equipment_name'];
} else {
    $equipment_name = "Unknown";
}
$eq_name_stmt->close();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/add_rh_subequipment_style.css">
</head>

<body>
    <?php include 'header.php'; ?>

    <h5>Add Subequipment for <?php echo $equipment_name; ?></h5>
    <main class="add-rh-subequipment-container">
    
    

        <form method="POST">
            <div class="input-field">
                <input type="text" id="subequipment_name" name="subequipment_name" required>
                <label for="subequipment_name">Sub Equipment Name</label>
            </div>
            <button type="submit" class="btn waves-effect waves-light">Add Subequipment
                <i class="material-icons left">add</i>
            </button>
            <!-- Add the Back button below -->
            <a href="edit_equipment_rh.php?id=<?php echo $equipment_id; ?>" class="btn waves-effect waves-light">Back
                <i class="material-icons left">arrow_back</i>
            </a>
        </form>

        <!-- Display sub-equipment items -->
        <h5>Existing Subequipment:</h5>
        <table id="subEquipmentTable">
            <thead>
                <tr>
                    <th style="width:80%">Name</th>
                    <th style="width: 20%;">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($subequipments as $subequipment): ?>
                    <tr data-id="<?php echo $subequipment['subequipment_id']; ?>">
                        <td><?php echo $subequipment['subequipment_name']; ?></td>
                        <td>
                            <a href="edit_subequipment.php?subequipment_id=<?php echo $subequipment['subequipment_id']; ?>" class="btn-small waves-effect waves-light">
                                <i class="material-icons left">edit</i>
                            </a>
                            <button class="btn-small waves-effect waves-light red delete-button">
                                <i class="material-icons left">delete</i>
                            </button>
                        </td>

                    </tr>

                <?php endforeach; ?>
            </tbody>
        </table>

    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

        document.addEventListener('DOMContentLoaded', function() {
            var form = document.querySelector('form');
            applyListeners(); // Apply listeners to existing elements

            form.addEventListener('submit', function(e) {
                e.preventDefault();
                var formData = new FormData(form);
                formData.append('equipment_id', <?php echo json_encode($equipment_id); ?>);

                fetch('add_rh_subequipment.php?equipment_id=' + <?php echo json_encode($equipment_id); ?>, {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'Success') {
                        var new_id = data.id;
                        var table = document.getElementById('subEquipmentTable').getElementsByTagName('tbody')[0];
                        var newRow = table.insertRow(table.rows.length);
                        newRow.dataset.id = new_id;  
                        var cell1 = newRow.insertCell(0);
                        var cell2 = newRow.insertCell(1);
                        cell1.innerHTML = formData.get('subequipment_name');
                        cell2.innerHTML = `<a href="edit_subequipment.php?subequipment_id=${new_id}" class="btn-small waves-effect waves-light">
                                            <i class="material-icons left">edit</i>
                                        </a> 
                                        <button class="btn-small waves-effect waves-light red delete-button">
                                            <i class="material-icons left">delete</i>
                                        </button>`
                                        ;
                        
                        applyListeners(); // Reapply listeners
                        
                        form.reset();
                    } else if (data.status === 'Duplicate') {
                        alert("Duplicate subequipment name. Try a different name.");
                    }else {
                        alert("Error: " + data.status);
                    }
                });
            });
        });

        function applyListeners() {
            var deleteButtons = document.querySelectorAll('.delete-button');
            deleteButtons.forEach(function(button) {
                button.removeEventListener('click', handleDelete); 
                button.addEventListener('click', handleDelete); 
            });
        }

        function handleDelete(e) {
            var subequipmentId = e.target.closest('tr').dataset.id;
            if (confirm('Are you sure you want to delete this?')) {
                fetch('delete_subequipment.php?subequipment_id=' + subequipmentId, {
                    method: 'GET'
                })
                .then(response => response.text())
                .then(data => {
                    if (data === 'Success') {
                        e.target.closest('tr').remove();
                    } else {
                        alert("Error: " + data);
                    }
                });
            }
        }




    </script>
</body>

</html>
