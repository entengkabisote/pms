<?php
session_start();

include 'db_connect.php';  // Database connection
$vessel_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$vessel_id) {
    die('Invalid vessel ID.');
}

// Get vessel name
$vessel_query = "SELECT vessel_name FROM vessels WHERE id = $vessel_id";
$vessel_result = $conn->query($vessel_query);
if(!$vessel_result) {
    die("Query failed: " . $conn->error);
}
$vessel = $vessel_result->fetch_assoc();

$query = "
    SELECT 
        e.category,
        e.equipment_name,
        e.equipment_id,
        im.inspection_type,
        im.inspection_interval,
        im.person_in_charge,
        im.criticality,
        im.meta_id as inspection_meta_id
    FROM vessel_equipment ve
    JOIN equipment_table e ON ve.equipment_id = e.equipment_id
    JOIN inspection_meta_table im ON ve.inspection_meta_id = im.meta_id
    WHERE ve.vessel_id = ?
    ORDER BY e.category, e.equipment_name, im.inspection_type
";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $vessel_id);
$stmt->execute();
$result = $stmt->get_result();
if (!$stmt->execute()) {
    echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
}

$result = $stmt->get_result();
if ($result === false) {
    echo "Get result failed: (" . $stmt->errno . ") " . $stmt->error;
}

$current_year = date("Y");
$start_year = $current_year - 5;
$end_year = $current_year + 0;
$vessel_id = $_GET['id']; // Get the vessel_id from the URL parameter


$type_query = "SELECT type FROM equipment_type";
$type_result = $conn->query($type_query);
if(!$type_result) {
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/vessel_maint_details_style.css">
    <style>
        main.container {
            margin-bottom: 60px;
        }
        .bold-category {
            font-weight: bolder;
            color: blue;
            font-size: 20px;
            text-transform: uppercase;
        }

        .bold-equipment {
            font-weight: 600;
            color: green;
            font-size: 18px;
            padding-left: 20px;
        }

        .btn-back {
            position: sticky;
            right: 10px; /* Adjust this value based on your preference */
            top: 150px;  /* Adjust this value too, if needed */
            left: auto;
        }

        .type-container {
            width: 80%;
            margin-bottom: 40px;
        }

        .select-wrapper select {
            text-indent: 0 !important;
            text-align: left !important;
        }

    </style>
    
</head>

<body>
    <?php include 'header.php'; ?>
    
        <div class="btn-back">
            <a href="vessel_maintenance.php?id=<?php echo $vessel_id; ?>" class="btn waves-effect waves-light custom-btn" >
                <i class="material-icons left">arrow_back</i>Back
            </a>
        </div>
        <main class="vessel-maint-details-container">
            
        <h5><?php echo htmlspecialchars($vessel['vessel_name']); ?></h5>
        
            <!-- New month and year filter section -->
            <div class="row">
            
            
                <form action="vessel_inspection_dates.php" method="get">
                    <div class="col s4">
                        <!-- Month Selector -->
                        <select name="month" class="buwan" required>
                            <option value="" disabled selected>Choose your month</option>
                            <option value="1">January</option>
                            <option value="2">February</option>
                            <option value="3">March</option>
                            <option value="4">April</option>
                            <option value="5">May</option>
                            <option value="6">June</option>
                            <option value="7">July</option>
                            <option value="8">August</option>
                            <option value="9">September</option>
                            <option value="10">October</option>
                            <option value="11">November</option>
                            <option value="12">December</option>
                        </select>
                    </div>
                    <div class="col s4">
                        <!-- Year Selector -->
                        <select name="year" required>
                            <option value="" disabled selected>Choose your year</option>
                            <?php for ($year = $start_year; $year <= $end_year; $year++): ?>
                                <option value="<?php echo $year; ?>"><?php echo $year; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    
                    <div class="col s4">
                        <!-- Search Button -->
                        <input type="hidden" name="id" value="<?php echo $vessel_id; ?>">
                        <button type="submit" class="btn waves-effect waves-light blue">
                            <i class="material-icons left">search</i>Search
                        </button>
                    </div>
                </form>
            </div>
            <table class="striped">
                <thead>
                    <tr>
                        <th></th>
                        <th>Inspection Interval</th>
                        <th>Person in Charge</th>
                        <th>Criticality</th>
                        <th>Action</th>
                        <th>Date</th>
                        <th>Remarks</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $prevCategory = "";
                        $prevEquipment = "";
                        while ($row = $result->fetch_assoc()) {

                            if ($prevCategory != $row['category']) {
                                echo "<tr><td class='category bold-category'>" . htmlspecialchars($row['category']) . "</td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";
                                                                                                        // "</td><td></td><td></td><td></td></tr>";

                                $prevCategory = $row['category'];
                                $prevEquipment = ""; // Reset equipment
                            }
                            if ($prevEquipment != $row['equipment_name']) {
                                echo "<tr><td class='equipment-name bold-equipment'>" . htmlspecialchars($row['equipment_name']) . "</td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";
                                                                                                                    // "</td><td></td><td></td><td></td></tr>";
                                $prevEquipment = $row['equipment_name'];
                            }
                            echo "<tr>";
                            echo "<td class='inspection-type'>" . htmlspecialchars($row['inspection_type']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['inspection_interval']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['person_in_charge']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['criticality']) . "</td>";
                            echo "<td><button data-equipment-id=\"" . $row['equipment_id'] . "\" data-inspection-meta-id=\"" . $row['inspection_meta_id'] . "\" onclick=\"addInspectionFields(this)\">Enter Inspection Date</button></td>";

                            // echo "<td><button onclick=\"addInspectionFields(this)\">Enter Inspection Date</button></td>";
                            echo "<td></td>";
                            echo "<td></td>";
                            echo "</tr>";
                        }
                    ?>
                </tbody>
            </table>
        </main>
    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('select');
            var instances = M.FormSelect.init(elems);
        });
   

        function addInspectionFields(buttonElement) {
            console.log(buttonElement);
            const equipmentId = buttonElement.getAttribute('data-equipment-id');
            const inspectionMetaId = buttonElement.getAttribute('data-inspection-meta-id');

            // 1. Remove 'Enter Inspection Date' button
            buttonElement.style.display = "none";

            // 2. Create Date and Remarks fields
            const dateField = document.createElement('input');
            dateField.type = 'date';
            const remarksField = document.createElement('input');
            remarksField.type = 'text';
            
            const row = buttonElement.closest('tr');
            row.cells[row.cells.length - 2].appendChild(dateField); // Date field
            row.cells[row.cells.length - 1].appendChild(remarksField); // Remarks field
            
            // 3. Create 'Save' button
            const saveButton = document.createElement('button');
            saveButton.innerText = 'Save';

            // Set the attributes of the save button using the values you got earlier
            saveButton.setAttribute('data-equipment-id', equipmentId);
            saveButton.setAttribute('data-inspection-meta-id', inspectionMetaId);

            saveButton.onclick = function() {
                saveInspectionDetails(saveButton, dateField, remarksField, buttonElement);
            };
            row.cells[row.cells.length - 3].appendChild(saveButton); // Append Save button

            console.log("Equipment ID from function:", equipmentId);
            console.log("Inspection Meta ID from function:", inspectionMetaId);
        }

        function saveInspectionDetails(saveButton, dateField, remarksField, enterButton) {
            const vesselId = <?php echo $vessel_id; ?>;
            const equipmentId = saveButton.getAttribute('data-equipment-id');
            const inspectionMetaId = saveButton.getAttribute('data-inspection-meta-id');
            const inspectionDate = dateField.value;
            const remarks = remarksField.value;

            console.log("Equipment ID:", equipmentId);
            console.log("Inspection Meta ID:", inspectionMetaId);

            // AJAX call
            fetch('save_inspection_date.php', {
                method: 'POST',
                body: JSON.stringify({
                    vessel_id: vesselId,
                    equipment_id: equipmentId,
                    inspection_meta_id: inspectionMetaId,
                    date: inspectionDate,
                    remarks: remarks
                }),
                headers: {
                    'Content-Type': 'application/json'
                }
            }).then(response => response.json())
            .then(data => {
                console.log(data);
                // Check if the status is 'success' from the server response
                if (data.status === "success") {
                    // Handle success
                    // For example, display a success message
                    alert('Successfully saved!');
                    // You can also delete or update the fields depending on what you want
                } else {
                    // Handle errors
                    alert(data.message);
                }
            }).catch(error => {
                // Handle if there is an error on the fetch itself
                console.error('Error:', error);
                alert('There was a problem saving data.');
            });

            // 4. Remove 'Save' button and input fields after saving
            saveButton.remove();
            dateField.remove();
            remarksField.remove();

            // Show 'Enter Inspection Date' button again
            enterButton.style.display = "block";
        }
    </script>
</body>

</html>
