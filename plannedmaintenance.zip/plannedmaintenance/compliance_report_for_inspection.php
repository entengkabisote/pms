<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'db_connect.php';

$vessel_id = $_GET['id'];  // I-assume natin na may id na pinasa from the URL

$sql = "SELECT v.vessel_id, v.equipment_id, e.equipment_name, v.date_added, m.inspection_type, m.inspection_interval, MAX(d.inspection_date) AS last_inspection
        FROM vessel_equipment v
        JOIN equipment_table e ON v.equipment_id = e.equipment_id
        JOIN inspection_meta_table m ON v.inspection_meta_id = m.meta_id
        LEFT JOIN inspection_date d ON v.equipment_id = d.equipment_id AND v.inspection_meta_id = d.inspection_meta_id
        WHERE v.vessel_id = $vessel_id
        GROUP BY v.vessel_id, v.equipment_id, e.equipment_name, m.inspection_type, m.inspection_interval";

$result = $conn->query($sql);

if($result === FALSE) {
  die("SQL Error: " . $conn->error);
}

$compliance_data = [];

function getDaysThreshold($intervalType) {
    switch ($intervalType) {
        case 'daily' : return 1;
        case 'weekly': return 7;
        case 'monthly': return 30;
        case 'bi-monthly': return 60;
        case '3-months': return 90;
        case '6-months': return 180;
        case '5-years': return 1825;
        case 'yearly': return 365;
        case 'As required': return 2000;
        case 'Every 250 hours': return 10.5;
        default: return 0;
    }
}

if($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        if (is_null($row['last_inspection'])) {
            $date_added = new DateTime($row['date_added']);
            $now = new DateTime();
            $days_since_added = $now->diff($date_added)->days;
    
            switch (strtolower($row['inspection_interval'])) {
                case 'daily':
                    $status = ($days_since_added > 1) ? "Non-Compliant" : "Compliant";
                    break;
                case 'weekly':
                    $status = ($days_since_added > 7) ? "Non-Compliant" : "Compliant";
                    break;
                case 'monthly':
                    $status = ($days_since_added > 30) ? "Non-Compliant" : "Compliant";
                    break;
                case 'bi-monthly':
                    $status = ($days_since_added > 60) ? "Non-Compliant" : "Compliant";
                    break;
                case '3-months':
                    $status = ($days_since_added > 90) ? "Non-Compliant" : "Compliant";
                    break;
                case '6-months':
                    $status = ($days_since_added > 180) ? "Non-Compliant" : "Compliant";
                    break;
                case '5-years':
                    $status = ($days_since_added > 1825) ? "Non-Compliant" : "Compliant";
                    break;
                case 'yearly':
                    $status = ($days_since_added > 365) ? "Non-Compliant" : "Compliant";
                    break;
                case 'As required':
                    $status = ($days_since_added > 2000) ? "Non-Compliant" : "Compliant";
                    break;
                case 'Every 250 hours':
                    $status = ($days_since_added > 10.5) ? "Non-Compliant" : "Compliant";
                    break;
                default:
                    $status = "Compliant";
            }
        } else {
            // Existing logic for having last_inspections
            $last_inspection_date = new DateTime($row['last_inspection']);
            $now = new DateTime();
            $interval = $last_inspection_date->diff($now)->days;
    
            // For example, if the inspection_interval is weekly, the threshold is 7 days.
            $status = ($interval > getDaysThreshold($row['inspection_interval'])) ? "Non-Compliant" : "Compliant";
        }
    
        $compliance_data[] = [
            'equipment_id' => $row['equipment_id'],
            'equipment_name' => $row['equipment_name'],
            'inspection_type' => $row['inspection_type'],
            'inspection_interval' => $row['inspection_interval'],
            'date_added' => $row['date_added'],
            'last_inspection' => $row['last_inspection'],
            'status' => $status
        ];
    }
}

$conn->close();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/compliance_report_style.css">
</head>

<body>
<?php include 'header.php'; ?>
<h5>Compliance Report</h5>
    <div class="btn-back">
        <a href="vessel_maintenance.php?id=<?php echo $vessel_id; ?>" class="btn waves-effect waves-light custom-btn" >
            <i class="material-icons left">arrow_back</i>Back
        </a>
    </div>

    
    <main class="compliance-report-container">
        <select id="complianceFilter">
            <option value="all">All</option>
            <option value="Compliant">Compliant</option>
            <option value="Non-Compliant">Non-Compliant</option>
        </select>
        
        <table class="striped">
            <thead>
                <tr>
                    <th class="eq-name">Equipment Name</th>
                    <th class="ins-typ">Inspection Type</th>
                    <th class="ins-in">Inspection Interval</th>
                    <th class="d8-add">Date Added</th>
                    <th class="lst-ins">Last Inspection</th>
                    <th class="stat">Status</th>
                </tr>
            </thead>
        <tbody>
            <?php foreach($compliance_data as $data): ?>
                <tr data-equipment-id="<?= $data['equipment_id'] ?>">
                <td><?= $data['equipment_name'] ?></td>
                <td><?= $data['inspection_type'] ?></td>
                <td><?= $data['inspection_interval'] ?></td>
                <td><?= $data['date_added'] ?></td>
                <td><?= $data['last_inspection'] ?></td>
                <td><?= $data['status'] ?></td> <!-- Compliant or Non-Compliant -->
            </tr>
            <?php endforeach; ?>
        </tbody>
        </table>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);

            var selectElems = document.querySelectorAll('select');
            var selectInstances = M.FormSelect.init(selectElems);

            // Add this new code for the dropdown filter
            const filter = document.getElementById('complianceFilter');
            filter.addEventListener('change', function() {
                const value = this.value;
                const rows = document.querySelectorAll('tbody tr');

                rows.forEach(row => {
                    // console.log('Row:', row); // This will be added so that we can see the contents of the row
                    const statusCell = row.querySelector('td:last-child');
                    // console.log('Status Cell:', statusCell); // To see what statusCell contents before use

                    if (statusCell && (value === 'all' || statusCell.textContent === value)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });
        });
            
    </script>
</body>

</html>
