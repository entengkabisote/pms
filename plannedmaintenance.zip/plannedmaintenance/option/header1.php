<div class="logo-header">
        <img src="images/smscorp.png" alt="Company Logo" class="logo">
        <h4 class="white-text">Strategic Maritime Solutions Corp.</h4>
    </div>

    <nav class="blue-grey darken-2">
        <div class="nav-wrapper container">
            <ul class="center-align">
                <li><a href="index.php" class="white-text">Dashboard</a></li>
                <!-- <li><a href="vessel.php" class="white-text">Vessels</a></li> -->
                <!-- <li><a href="equipment.php" class="white-text">Equipments</a></li> -->
                <li><a class="dropdown-trigger white-text" href="#!" data-target="equipmentDropdown">Equipments<i class="material-icons right">arrow_drop_down</i></a></li>
                <!-- <li><a href="spareparts.html" class="white-text">Spare Parts</a></li> -->
                
                <!-- Dropdown Trigger -->
                <!-- <li><a class="dropdown-trigger white-text" href="#!" data-target="maintenanceDropdown">Maintenance Tasks<i class="material-icons right">arrow_drop_down</i></a></li> -->
                <!-- <li><a href="#" class="white-text">Reports</a></li> -->
                <li><a class="dropdown-trigger white-text" href="#!" data-target="settingsDropdown">Settings<i class="material-icons right">arrow_drop_down</i></a></li>
                
                <!-- <li><a href="#" class="white-text">Settings</a></li> -->
            </ul>
    
            <!-- Dropdown Structure -->
            <ul id="equipmentDropdown" class="dropdown-content">
                <li><a href="equipment.php">Equipment for Inspection</a></li>
                <li><a href="equipment_running_hours.php">Equipment for Machineries</a></li>
            </ul>

            <ul id="maintenanceDropdown" class="dropdown-content">
                <!-- <li><a href="vessel_maint.php">Ship / Vessel Inspection Date</a></li> -->
                <li><a href="vessel_link_to_equipment.php">Running Hours of Equipment</a></li>
            </ul>

            <ul id="settingsDropdown" class="dropdown-content">
                <li><a href="add_interval.php">Interval Date</a></li>
                <!-- <li><a href="vessel_link_to_equipment.php">Running Hours of Equipment</a></li> -->
            </ul>

        </div>
    </nav>