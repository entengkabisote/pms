<?php
session_start();

include 'db_connect.php';  // connection in database
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/vessel_style.css">
    <link rel="stylesheet" href="styles/buttons.css">
    
</head>

<body>
<?php include 'header.php'; ?>

    <main class="vessel-container">
    <!-- Notification Message -->
    <?php if (isset($_SESSION['vessel_error'])): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            M.toast({html: '<?php echo $_SESSION['vessel_error']; ?>', classes: 'rounded red lighten-2', displayLength: 2000});
        });
        <?php unset($_SESSION['vessel_error']); ?>
    </script>
    <?php endif; ?>

    <!-- New Vessel Entry -->
    <div class="row">
        <div class="col s12 m6">
            <h5>Enter New Vessel</h5>
            <form action="check_vessel.php" method="post">
                <div class="input-field">
                    <input type="text" id="vessel_name" name="vessel_name" required style="text-transform: uppercase;">
                    <label for="vessel_name">Vessel Name:</label>
                </div>
                <div class="input-field">
                    <input type="text" id="official_number" name="official_number" required>
                    <label for="official_number">Official Number:</label>
                </div>
                <!-- <button class="btn-small waves-effect waves-light" type="submit">Check</button> -->
                <button class="btn-small waves-effect waves-light" type="submit"> <i class="material-icons left">check</i> Check </button>
            </form>
        </div>

        <!-- Existing Vessels -->
        <div class="col s12 m6">
            <h5>Existing Vessels</h5>
            <div class="vessels-list">
                <?php include 'existing_vessels.php'; ?>
            </div>
        </div>
    </div>
</main>


    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });
        </script>
</body>

</html>
