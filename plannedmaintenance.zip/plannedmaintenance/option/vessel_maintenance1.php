<?php
session_start();

include 'db_connect.php';  // connection in database

    $id = $_GET['id'];

    $sql = "SELECT * FROM vessels WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    $current_year = date("Y");
    $start_year = $current_year - 7;
    $end_year = $current_year + 7;

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PMS | Vessel Details</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/styles.css">
    <link rel="stylesheet" href="styles/vessel_maintenance_styles.css">   
    <link rel="stylesheet" href="styles/buttons.css">
</head>

<body>
<?php include 'header.php'; ?>

    <div>
    <h2 class="header custom-3d-effect"><?php echo $row['vessel_name']; ?></h2>
    </div>
<!-- ************************* -->
    <main class="vessel-maintenance-container">
<!-- ************************* -->
        <!-- <h2 class="header custom-3d-effect"><?php echo $row['vessel_name']; ?></h2> -->

        <div class="vessel-image">
            <img src="<?php echo $row['imahe']; ?>" alt="Vessel Image" width="100%">
            
            <div class="button-group">
                <button class="btn-small waves-effect waves-light" type="submit" onclick="location.href='vessel.php'"> <i class="material-icons left">arrow_back</i>Back</button>
                <button class="btn-small waves-effect waves-light blue-grey darken-2" onclick="window.location.href='edit_vessel.php?id=<?php echo $row['id']; ?>'"><i class="material-icons left">edit</i>Edit</button>
                <button class="btn-small waves-effect waves-light red" onclick="if(confirm('Are you sure you want to delete this vessel?')) { window.location.href='delete_vessel.php?id=<?php echo $row['id']; ?>'; }"><i class="material-icons left">delete</i>Delete</button>
                <!-- <button class="btn-small waves-effect waves-light" onclick="window.location.href='add_equipment_vessel.php?id=<?php echo $row['id']; ?>'"><i class="material-icons left">add</i>Equipment</button> -->
            </div>
            <div>
                <fieldset class="custom-border">
                    <legend>Equipment</legend>
                    <button class="btn-small waves-effect waves-light equipment-btn green" onclick="window.location.href='add_equipment_vessel.php?id=<?php echo $row['id']; ?>'"><i class="material-icons left">add</i>Add Equipment</button>
                    <button class="btn-small waves-effect waves-light inspection-btn blue" onclick="window.location.href='vessel_maint_details.php?id=<?php echo $row['id']; ?>'"><i class="material-icons left">date_range</i>Vessel Inspection Date</button>
                    <fieldset class="custom-border2">
                        <legend>Reports</legend>
                        <button class="btn-small waves-effect waves-light compliance-btn orange" onclick="window.location.href='compliance_report_for_inspection.php?id=<?php echo $row['id']; ?>'"><i class="material-icons left">report</i>Compliance Report</button>
                        <button class="btn-small waves-effect waves-light person-incharge-btn orange" onclick="window.location.href='person_in_charge_report.php?id=<?php echo $row['id']; ?>'"><i class="material-icons left">report</i>Person-In-Charge Report</button>

                        <!-- <button class="btn-small waves-effect waves-light link-btn" onclick="window.location.href='status_page.php?id=<?php echo $row['id']; ?>'"><i class="material-icons left">insert_chart</i>Running Hours Status</button> -->
                    </fieldset>
                </fieldset>
            </div>
            <div>
                <fieldset class="custom-border">
                    <legend>Machineries</legend>
                    <button class="btn-small waves-effect waves-light link-btn green" onclick="window.location.href='vessel_link_to_equipment.php?vessel_id=<?php echo $row['id']; ?>'"><i class="material-icons left">link</i>Link Equipment</button>
                    <button class="btn-small waves-effect waves-light inspection-btn blue" onclick="window.location.href='view_vessel_rh_details.php?vessel_id=<?php echo $row['id']; ?>'"><i class="material-icons left">date_range</i>Running Hours Entry</button>
                    <button class="btn-small waves-effect waves-light inspection-btn grey" onclick="window.location.href='vessel_summary.php?id=<?php echo $row['id']; ?>'"><i class="material-icons left">list_alt</i>Vessel Summary</button>
                    <fieldset class="custom-border2">
                        <legend>Reports</legend>
                        <button class="btn-small waves-effect waves-light link-btn" onclick="window.location.href='vessel_list_rh_details.php?id=<?php echo $row['id']; ?>'"><i class="material-icons left">insert_chart</i>Running Hours List</button>
                        <button class="btn-small waves-effect waves-light link-btn" onclick="window.location.href='status_page.php?id=<?php echo $row['id']; ?>'"><i class="material-icons left">insert_chart</i>Running Hours Status</button>
                    </fieldset>
                </fieldset>
            </div>
        </div>
        
        <div class="vessel-details">

            <table class="highlight">
                <tbody>

                    <tr>
                        <td><strong>Vessel Name</strong></td>
                        <td><?php echo $row['vessel_name']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Official Number</strong></td>
                        <td><?php echo $row['official_number']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Owner</strong></td>
                        <td><?php echo $row['owner']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>IMO Number</strong></td>
                        <td><?php echo $row['IMO_number']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Classification Number</strong></td>
                        <td><?php echo $row['classification_number']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Ship Type</strong></td>
                        <td><?php echo $row['ship_type']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Home Port</strong></td>
                        <td><?php echo $row['home_port']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Gross Tonnage</strong></td>
                        <td><?php echo $row['gross_tonnage']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Net Tonnage</strong></td>
                        <td><?php echo $row['net_tonnage']; ?></td>
                    </tr>

                    <tr>
                        <td><strong>Bollard Pull</strong></td>
                        <td><?php echo $row['bollard_pull']; ?></td>
                    </tr>

                    <tr>
                        <td><strong>Length Overall</strong></td>
                        <td><?php echo $row['length_overall']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Breadth</strong></td>
                        <td><?php echo $row['breadth']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Depth</strong></td>
                        <td><?php echo $row['depth']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Year Built</strong></td>
                        <td><?php echo $row['year_built']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Main Engine Make</strong></td>
                        <td><?php echo $row['main_engine_make']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Main Engine Model</strong></td>
                        <td><?php echo $row['main_engine_model']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Main Engine Number</strong></td>
                        <td><?php echo $row['main_engine_number']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Engine Power</strong></td>
                        <td><?php echo $row['engine_power']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Auxiliary Engine Make</strong></td>
                        <td><?php echo $row['aux_engine_make']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Auxiliary Engine Model</strong></td>
                        <td><?php echo $row['aux_engine_model']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Auxiliary Engine Number</strong></td>
                        <td><?php echo $row['aux_engine_number']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Auxiliary Engine Power</strong></td>
                        <td><?php echo $row['aux_engine_power']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Drive</strong></td>
                        <td><?php echo $row['drive']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Flag</strong></td>
                        <td><?php echo $row['flag']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Builder</strong></td>
                        <td><?php echo $row['builder']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Trading Area</strong></td>
                        <td><?php echo $row['trading_area']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Hull Material</strong></td>
                        <td><?php echo $row['hull_material']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Max Speed</strong></td>
                        <td><?php echo $row['max_speed']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Insurance</strong></td>
                        <td><?php echo $row['insurance']; ?></td>
                    </tr>


                    <tr>
                        <td style="font-family: apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif; font-size: 11.6px; font-weight: 500;">
                            ISPS Compliance
                        </td>
                        <td>
                            <label>
                                <input type="checkbox" class="filled-in" id="ISPS_compliance" <?php if ($row['ISPS_compliance'] == 1) echo 'checked'; ?> disabled />
                                <span></span>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <td style="font-family: apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif; font-size: 11.6px; font-weight: 500;">
                            ISO 9001:2015
                        </td>
                        <td>
                            <label>
                                <input type="checkbox" class="filled-in" id="ISO_9001_2015" <?php if ($row['ISO_9001_2015'] == 1) echo 'checked'; ?> disabled />
                                <span></span>
                            </label>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

               
    </main>


    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });




        </script>
</body>

</html>
