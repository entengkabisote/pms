<?php
include "db_connect.php";
session_start();

if (isset($_POST['confirm']) && $_POST['confirm'] === 'yes') {
    // Ito na yung part na isesave mo yung data sa database
    // Gamitin mo yung data na nasa $_SESSION['input_summary']

    // ... Iyong code para sa pag-save ...

    // Pagkatapos ma-save, pwede mo nang i-clear yung session
    unset($_SESSION['input_summary']);
    $_SESSION['message'] = 'Data has been successfully saved.';
    header('Location: success_page.php'); // Redirect sa success page
    exit();
}
