<?php
include 'db_connect.php';

if (isset($_GET['sub_task_id'])) {
    $sub_task_id = $_GET['sub_task_id'];
    
    // Get subequipment_id associated with this sub_task_id
    $stmt = $conn->prepare("SELECT subequipment_id FROM sub_tasks WHERE sub_task_id = ?");
    $stmt->bind_param("i", $sub_task_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $subequipment_id = $row['subequipment_id'];
        
        // Now proceed to delete
        $stmt = $conn->prepare("DELETE FROM sub_tasks WHERE sub_task_id = ?");
        $stmt->bind_param("i", $sub_task_id);

        if ($stmt->execute()) {
            header("Location: edit_subequipment.php?subequipment_id=" . $subequipment_id);
            exit;
        } else {
            echo "Error: " . $stmt->error;
        }
    } else {
        echo "Sub task not found.";
    }
}

?>
