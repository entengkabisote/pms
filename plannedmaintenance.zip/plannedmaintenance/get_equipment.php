<?php
include 'db_connect.php';

$sql = "SELECT * FROM equipment_table";
$result = $conn->query($sql);

$data = [];

while($row = $result->fetch_assoc()) {
  $data[] = $row;
}

echo json_encode($data);
?>
