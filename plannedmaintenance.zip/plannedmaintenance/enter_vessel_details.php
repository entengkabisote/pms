<?php
session_start();

include 'db_connect.php';  // connection in database

$vessel_name = isset($_SESSION['vessel_name']) ? $_SESSION['vessel_name'] : '';
$official_number = isset($_SESSION['official_number']) ? $_SESSION['official_number'] : '';

$imahe = ""; // Default value




if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $vessel_name = $_POST['vessel_name'];
    $official_number = $_POST['official_number'];
    $owner = $_POST['owner'];
    $imo_number = $_POST['IMO_number'];
    $classification_number = $_POST['classification_number'];
    $ship_type = $_POST['ship_type'];
    $home_port = $_POST['home_port'];
    $gross_tonnage = $_POST['gross_tonnage'];
    $net_tonnage = $_POST['net_tonnage'];
    $bollard_pull = $_POST['bollard_pull'];
    $length_overall = $_POST['length_overall'];
    $breadth = $_POST['breadth'];
    $depth = $_POST['depth'];
    $year_built = $_POST['year_built'];
    $main_engine_make = $_POST['main_engine_make'];
    $main_engine_model = $_POST['main_engine_model'];
    $main_engine_number = $_POST['main_engine_number'];
    $engine_power = $_POST['engine_power'];
    $aux_engine_make = $_POST['aux_engine_make'];
    $aux_engine_model = $_POST['aux_engine_model'];
    $aux_engine_number = $_POST['aux_engine_number'];
    $aux_engine_power = $_POST['aux_engine_power'];
    $flag = $_POST['flag'];
    $builder = $_POST['builder'];
    $trading_area = $_POST['trading_area'];
    $hull_material = $_POST['hull_material'];
    $drive = $_POST['drive'];
    $max_speed = $_POST['max_speed'];
    $insurance = $_POST['insurance'];
    $isps_compliance = isset($_POST['isps_compliance']) ? 1 : 0;
    $iso_9001_2015 = isset($_POST['iso_9001_2015']) ? 1 : 0;

    $complete_image_path = "";

    if(isset($_FILES['imahe']) && $_FILES['imahe']['error'] == 0) {
        $temp_name = $_FILES['imahe']['tmp_name'];
        $name = $_FILES['imahe']['name'];
        $size = $_FILES['imahe']['size'];
    
        if($size <= 5000000) {
            $dir_upload = 'uploads/';
            $new_image_name = time() . '_pacific.' . pathinfo($name, PATHINFO_EXTENSION);
            $complete_image_path = $dir_upload . $new_image_name;  // eto ang magiging value na isasave sa database
            move_uploaded_file($temp_name, $complete_image_path);
    
            // Update the imahe name to the new uploaded imahe
            $imahe = $new_image_name;
        } else {
            echo "File is too large!";
        }
    }
    
    if (!isset($complete_image_path) && isset($vessel['imahe'])) {
        $complete_image_path = $vessel['imahe'];
    }

    
    // $sql = "INSERT INTO vessels (vessel_name, official_number, owner, IMO_number, ship_type, classification_number, home_port, gross_tonnage, net_tonnage, length_overall, breadth, depth, year_built, main_engine_make, main_engine_model, main_engine_number, engine_power, drive, flag, builder, trading_area, hull_material, max_speed, insurance, ISPS_compliance, ISO_9001_2015) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $sql = "INSERT INTO vessels (vessel_name, official_number, owner, IMO_number, ship_type, classification_number, home_port, gross_tonnage, net_tonnage, length_overall, breadth, depth, year_built, main_engine_make, main_engine_model, main_engine_number, engine_power, drive, flag, builder, trading_area, hull_material, max_speed, insurance, ISPS_compliance, ISO_9001_2015, imahe, bollard_pull, aux_engine_make, aux_engine_model, aux_engine_number, aux_engine_power) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?)";

    $stmt = $conn->prepare($sql);
    // $stmt->bind_param("sssssssdddddssssdsssssdsii", $vessel_name, $official_number, $owner, $imo_number, $ship_type, $classification_number, $home_port, $gross_tonnage, $net_tonnage, $length_overall, $breadth, $depth, $year_built, $main_engine_make, $main_engine_model, $main_engine_number, $engine_power, $drive, $flag, $builder, $trading_area, $hull_material,  $max_speed, $insurance, $isps_compliance, $iso_9001_2015);
    $stmt->bind_param("sssssssdddddssssssssssdsiissssss", $vessel_name, $official_number, $owner, $imo_number, $ship_type, $classification_number, $home_port, $gross_tonnage, $net_tonnage, $length_overall, $breadth, $depth, $year_built, $main_engine_make, $main_engine_model, $main_engine_number, $engine_power, $drive, $flag, $builder, $trading_area, $hull_material,  $max_speed, $insurance, $isps_compliance, $iso_9001_2015, $complete_image_path, $bollard_pull, $aux_engine_make, $aux_engine_model, $aux_engine_number, $aux_engine_power);


// sssssssddddsssssssssssii
    if ($stmt->execute()) {
        header("Location: vessel.php?success=true");
    } else {
        echo "Error: " . $stmt->error;
    }
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PMS | Vessel Details</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/styles.css">
    <link rel="stylesheet" href="styles/enter_vessel_details_styles.css">   
    <link rel="stylesheet" href="styles/buttons.css">
</head>

<body>
<?php include 'header.php'; ?>

    <div>
        <h5>Add Vessel Details</h5>
    </div>
<!-- ************************* -->
    <main class="enter-vessel-details-container">
<!-- ************************* -->

<form action="enter_vessel_details.php" method="post" enctype="multipart/form-data">

        <!-- <div class="grid-x grid-margin-x"> -->
        <div class="row">
            <!-- Vessel Name -->
            <div class="input-field col s6">
                <label for="vessel_name">Vessel Name</label>
                <input type="text" id="vessel_name" name="vessel_name" value="<?php echo htmlspecialchars(strtoupper($vessel_name)); ?>" required>
                
            </div>

            <!-- Official Number -->
            <div class="input-field col s6">
                <label for="official_number">Official Number</label>
                <input type="text" id="official_number" name="official_number" value="<?php echo htmlspecialchars($official_number); ?>" required>
            </div>
    
            <!-- Owner -->
            <div class="input-field col s6">
                <label for="owner">Owner</label>
                <input type="text" id="owner" name="owner">
            </div>
    
            <!-- IMO Number -->
            <div class="input-field col s6">
                <label for="IMO_number">IMO Number</label>
                <input type="text" id="IMO_number" name="IMO_number">
            </div>

            <!-- Ship Type -->
            <div class="input-field col s6">
                <label for="ship_type">Ship Type</label>
                <input type="text" id="ship_type" name="ship_type">
            </div>

            <!-- Classification Number -->
            <div class="input-field col s6">
                <label for="classification_number">Classification Number</label>
                <input type="text" id="classification_number" name="classification_number">
            </div>

            <!-- Home Port -->
            <div class="input-field col s6">
                <label for="home_port">Home Port</label>
                <input type="text" id="home_port" name="home_port">
            </div>

            <!-- Gross Tonnage -->
            <div class="input-field col s6">
                <label for="gross_tonnage">Gross Tonnage</label>
                <input type="text" id="gross_tonnage" name="gross_tonnage">
            </div>

            <!-- Net Tonnage -->
            <div class="input-field col s6">
                <label for="net_tonnage">Net Tonnage</label>
                <input type="text" id="net_tonnage" name="net_tonnage">
            </div>

            <!-- Bollard Pull -->
            <div class="input-field col s6">
                <label for="bollard_pull">Bollard Pull</label>
                <input type="text" id="bollard_pull" name="bollard_pull">
            </div>

            <!-- Length Overall -->
            <div class="input-field col s6">
                <label for="length_overall">Length Overall</label>
                <input type="text" id="length_overall" name="length_overall">
            </div>

            <!-- Breadth -->
            <div class="input-field col s6">
                <label for="breadth">Breadth</label>
                <input type="text" id="breadth" name="breadth">
            </div>

            <!-- Depth -->
            <div class="input-field col s6">
                <label for="depth">Depth</label>
                <input type="text" id="depth" name="depth">
            </div>

            <!-- Year Built -->
            <div class="input-field col s6">
                <label for="year_built">Year Built</label>
                <input type="text" id="year_built" name="year_built">
            </div>

            <!-- Main Engine Make -->
            <div class="input-field col s6">
                <label for="main_engine_make">Main Engine Make</label>
                <input type="text" id="main_engine_make" name="main_engine_make">
            </div>

            <!-- Main Engine Model -->
            <div class="input-field col s6">
                <label for="main_engine_model">Main Engine Model</label>
                <input type="text" id="main_engine_model" name="main_engine_model">
            </div>

            <!-- Main Engine Number -->
            <div class="input-field col s6">
                <label for="main_engine_number">Main Engine Number</label>
                <input type="text" id="main_engine_number" name="main_engine_number">
            </div>

            <!-- Engine Power -->
            <div class="input-field col s6">
                <label for="engine_power">Engine Power</label>
                <input type="text" id="engine_power" name="engine_power">
            </div>

            <!-- Aux Engine Make -->
            <div class="input-field col s6">
                <label for="aux_engine_make">Auxiliary Engine Make</label>
                <input type="text" id="aux_engine_make" name="aux_engine_make">
            </div>

            <!-- Main Engine Model -->
            <div class="input-field col s6">
                <label for="aux_engine_model">Auxiliary Engine Model</label>
                <input type="text" id="aux_engine_model" name="aux_engine_model">
            </div>

            <!-- Main Engine Number -->
            <div class="input-field col s6">
                <label for="aux_engine_number">Auxiliary Engine Number</label>
                <input type="text" id="aux_engine_number" name="aux_engine_number">
            </div>

            <!-- Engine Power -->
            <div class="input-field col s6">
                <label for="aux_engine_power">Auxiliary Engine Power</label>
                <input type="text" id="aux_engine_power" name="aux_engine_power">
            </div>

            <!-- Drive -->
            <div class="input-field col s6">
                <label for="drive">Drive</label>
                <input type="text" id="drive" name="drive">
            </div>

            <!-- Flag -->
            <div class="input-field col s6">
                <label for="flag">Flag</label>
                <input type="text" id="flag" name="flag">
            </div>

            <!-- Builder -->
            <div class="input-field col s6">
                <label for="builder">Builder</label>
                <input type="text" id="builder" name="builder">
            </div>

            <!-- Trading Area -->
            <div class="input-field col s6">
                <label for="trading_area">Trading Area</label>
                <input type="text" id="trading_area" name="trading_area">
            </div>

            <!-- Hull Material -->
            <div class="input-field col s6">
                <label for="hull_material">Hull Material</label>
                <input type="text" id="hull_material" name="hull_material">
            </div>

            <!-- Maximum Speed -->
            <div class="input-field col s6">
                <label for="max_speed">Maximum Speed</label>
                <input type="text" id="max_speed" name="max_speed">
            </div>

            <!-- Insurance -->
            <div class="input-field col s6">
                <label for="insurance">Insurance</label>
                <input type="text" id="insurance" name="insurance">
            </div>
    
            <!-- ISP Compliance Checkbox -->
            <div class="col s6">
                <p>
                    <label>
                        <input type="checkbox" id="isps_compliance" name="isps_compliance" />
                        <span>ISP Compliance</span>
                    </label>
                </p>
            </div>

            <!-- ISO 9001:2015 Checkbox -->
            <div class="col s6">
                <p>
                    <label>
                        <input type="checkbox" id="iso_9001_2015" name="iso_9001_2015" />
                        <span>ISO 9001:2015</span>
                    </label>
                </p>
            </div>

            <div class="input-field col s6">
                <label for="imahe">Vessel Image</label>
                <input type="file" id="imahe" name="imahe">
            </div>

            <!-- Button -->
            <div class="button-group col s12">
                <button class="btn-small waves-effect waves-light" type="submit"> <i class="material-icons left">send</i> Add Vessel</button>
            </div>
        </div>
    </form>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });
        </script>
</body>

</html>
