<?php
include "db_connect.php";

$vessel_id = $_GET['vessel_id'];  // Gets the vessel_id from URL

// Fetch vessel name
$stmt = $conn->prepare("SELECT vessel_name FROM vessels WHERE id = ?");
$stmt->bind_param("i", $vessel_id);
$stmt->execute();
$vesselResult = $stmt->get_result();
$vesselName = $vesselResult->fetch_assoc()['vessel_name'];
$stmt->close();


// Fetch linked equipment and tasks
$query = "SELECT ve.equipment_id, ve.task_id, re.equipment_type, re.equipment_name, t.task_description, t.threshold_hour
          FROM vessel_rh_equipment ve
          JOIN rh_equipments re ON ve.equipment_id = re.equipment_id
          LEFT JOIN tasks t ON ve.task_id = t.task_id
          WHERE ve.vessel_id = $vessel_id
          ORDER BY re.equipment_type, re.equipment_name, t.threshold_hour";

$result = $conn->query($query);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/view_linked_equipment_style.css">
</head>

<body>
<?php include 'header.php'; ?>

    <main class="view-linked-equipment-container">
        <div class="row">
            <div class="col s12">
                <h5 class="text-center">Vessel Name: <?php echo $vesselName; ?></h5>
                <a href="vessel_link_to_equipment.php" class="button">Back to Vessel List</a>
                <?php
                    $allData = [];

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $allData[$row['equipment_name']][] = $row;
                        }
                    }
                    
                    if(empty($allData)) {
                      echo "<p>No linked equipment or tasks found.</p>";
                    } else {
                        function sortEquipment($a, $b) {
                            $order = ['engine', 'gearbox', 'z-peller', 'auxiliary'];
                            $nameA = preg_replace('/\d/', '', strtolower($a));
                            $nameB = preg_replace('/\d/', '', strtolower($b));
                        
                            $posA = array_search($nameA, $order);
                            $posB = array_search($nameB, $order);
                        
                            if ($posA === $posB) {
                                return preg_replace('/\D/', '', $a) <=> preg_replace('/\D/', '', $b);
                            }
                        
                            return $posA <=> $posB;
                        }
                    }
                    // Sort the keys bases in custom function
                    uksort($allData, 'sortEquipment');
                ?>
                <table class="highlight ">
                    <thead>
                        <tr>
                            <th>Equipment Type</th>
                            <th>Equipment Name</th>
                            <th>Task</th>
                            <th>Threshold Hour</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            // Custom sorting function
                            function sortEquipmentType($allData) {
                                $order = ['Primary', 'Secondary', 'Generator 1', 'Generator 2', 'Others'];
                                $sortedData = [];

                                foreach ($order as $type) {
                                    foreach ($allData as $equipment_name => $data) {
                                        $equipment_type = determineEquipmentType($equipment_name);
                                        if ($equipment_type === $type) {
                                            $sortedData[$equipment_name] = $data;
                                        }
                                    }
                                }
                                return $sortedData;
                            }

                            // Function to determine equipment_type
                            function determineEquipmentType($equipment_name) {
                                if (preg_match('/(engine 1|gearbox 1|z-peller 1)/i', $equipment_name)) {
                                    return "Primary";
                                } elseif (preg_match('/(engine 2|gearbox 2|z-peller 2)/i', $equipment_name)) {
                                    return "Secondary";
                                } elseif (preg_match('/auxiliary A/i', $equipment_name)) {
                                    return "Generator 1";
                                } elseif (preg_match('/auxiliary B/i', $equipment_name)) {
                                    return "Generator 2";
                                } else {
                                    return "Others";
                                }
                            }

                            $allData = sortEquipmentType($allData);
                            $addedTypes = [];

                            foreach ($allData as $equipment_name => $equipmentData) {
                                $equipment_type = determineEquipmentType($equipment_name);

                                // Group by equipment_type, only if not already added
                                if (!in_array($equipment_type, $addedTypes)) {
                                    echo "<tr class='primary'><td colspan='4'><strong>$equipment_type</strong></td>";
                                    // echo "<td><input type='date'></td><td><input type='number'></td></tr>";
                                    $addedTypes[] = $equipment_type;
                                }

                                echo "<tr><td>&nbsp;</td><td colspan='2'><strong>$equipment_name</strong></td><td>&nbsp;</td></tr>";

                                foreach ($equipmentData as $data) {
                                    $task = $data['task_description'] ? $data['task_description'] : 'No tasks';
                                    $threshold_hour = $data['threshold_hour'] ? $data['threshold_hour'] : 'N/A';
                                    echo "<tr><td>&nbsp;</td><td>&nbsp;</td><td>$task</td><td>$threshold_hour</td></tr>";
                                }
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>    
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);

            var elems = document.querySelectorAll('select');
            var instances = M.FormSelect.init(elems);
        });

        
        </script>
</body>

</html>
