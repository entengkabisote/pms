<?php
session_start();
include 'db_connect.php';
$equipment_id = $_GET['id'];

// Fetch equipment data
$sql_equipment = "SELECT * FROM equipment_table WHERE equipment_id = $equipment_id";
$result_equipment = $conn->query($sql_equipment);
$row_equipment = $result_equipment->fetch_assoc();

// Fetch inspection_meta_table data
$sql_meta = "SELECT * FROM inspection_meta_table WHERE equipment_id = $equipment_id";
$result_meta = $conn->query($sql_meta);

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Equipment | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/edit_equipment_style.css">
    <style>
        #toast-container {
            top: 50% !important;
            right: 50% !important;
            transform: translateX(50%) translateY(-50%);
            bottom: auto !important;
            left: auto !important;
        }
        .toast {
            background-color: red !important;
        }
    </style>

</head>

<body>
<?php include 'header.php'; ?>
    <h5 class="center-align">Insert Inspection for Equipment</h5> 
<!-- ************************************** -->
    <main class="edit-equipment-container">
<!-- ************************************** -->

        <form id="editEquipmentForm">
            <div class="row"> <!-- New row for input fields -->
                <div class="input-field col s12 m6"> <!-- Half the width for medium-sized screens -->
                    <input type="hidden" id="equipmentId" name="equipmentId" value="<?php echo $equipment_id; ?>">
                    <input type="text" id="equipmentName" value="<?php echo isset($row_equipment['equipment_name']) ? $row_equipment['equipment_name'] : ''; ?>" required>
                </div>
                <div class="input-field col s12 m6">
                    <input type="text" id="category" name="category" value="<?php echo isset($row_equipment['category']) ? $row_equipment['category'] : ''; ?>" required>
                    <label for="category">Category</label>
                </div>

            </div>
            <div class="row"> <!-- New row for buttons -->
                <div class="button-group col s12">
                    <button class="btn waves-effect waves-light btn-space" id="saveEquipment" type="submit">Save</button>
                    <a href="equipment.php" class="btn waves-effect waves-light btn-space">Back</a>
                </div>
            </div>

            <div id="inspectionMetaContainer">
                <div class="inspectionRow">
                    <input type="text" name="inspection_type[]" placeholder="Type of Inspection">
                    <!-- Replace this line -->
                    <select id="inspection_interval" name="inspection_interval[]">
                        <option value="" disabled selected>Select Interval...</option>
                        <?php
                            $sql = "SELECT * FROM interval_table";
                            $result = $conn->query($sql);
                            while ($row = $result->fetch_assoc()) {
                                echo "<option value='" . $row['name'] . "'>" . $row['name'] . "</option>";
                            }
                        ?>
                    </select>
                    <!-- <input type="text" name="inspection_interval[]" placeholder="Interval"> -->
                    <input type="text" name="person_in_charge[]" placeholder="Person in Charge">
                    <input type="text" name="criticality[]" placeholder="Criticality">
                    <button type="button" class="btn waves-effect waves-light red removeRow btn-space" style="display:none;">Remove</button>
                    <!-- <button type="button" class="btn waves-effect waves-light red removeRow btn-space">Remove</button> -->
                </div>
            </div>
            <div>
                <button class="btn waves-effect waves-light btn-space" type="button" id="addRow">Add Another Row</button>
                <button class="btn waves-effect waves-light btn-space" id="saveInspection" type="button">Save Inspect</button>
            </div>
            <div id="inspectionMetaContainer2">
                <table>
                    <thead>
                    <tr>
                        <th style="width: 60%;">Inspection Type</th>
                        <th style="width: 10%;">Inspection Interval</th>
                        <th style="width: 7%;">Person In Charge</th>
                        <th style="width: 7%;">Criticality</th>
                        <th style="width: 16%;">Action</th>
                    </tr>

                    </thead>
                    <tbody>
                        <?php while($row_meta = $result_meta->fetch_assoc()): ?>
                            <tr data-meta-id="<?php echo $row_meta['meta_id']; ?>" class="inspectionMeta">
                                <td><?php echo $row_meta['inspection_type']; ?></td>
                                <td style="text-align:center;"><?php echo $row_meta['inspection_interval']; ?></td>
                                <td style="text-align:center;"><?php echo $row_meta['person_in_charge']; ?></td>
                                <td style="text-align:center;"><?php echo $row_meta['criticality']; ?></td>
                                <td>
                                    <!-- Edit and Delete buttons -->
                                    <!-- <a href="edit_inspection_type.php?meta_id=<?php echo $row_meta['meta_id']; ?>" class="btn waves-effect waves-light blue">Edit</a> -->
                                    <a href="edit_inspection_type.php?meta_id=<?php echo $row_meta['meta_id']; ?>&equipment_id=<?php echo $equipment_id; ?>" class="btn waves-effect waves-light blue">Edit</a>

                                    <!-- <button type="button" class="btn waves-effect waves-light blue btn-edit" data-meta-id="<?php echo $row_meta['meta_id']; ?>">Edit</button> -->
                                    <button type="button" class="btn waves-effect waves-light red btn-delete">Delete</button>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>

                </table>
            </div>
        </form>
    </main>

    <!-- Edit Modal Structure -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <h4>Edit Inspection</h4>
            <form id="editInspectionForm">
                <!-- Meta ID (hidden) -->
                <input type="hidden" id="modalMetaId">

                <!-- Inspection Type -->
                <div class="input-field">
                    <input type="text" id="modalInspectionType" required>
                    <label for="modalInspectionType">Inspection Type</label>
                </div>

                <!-- Inspection Interval -->
                <select id="modalInspectionInterval" name="modalInspectionInterval">
                    <option value="" disabled selected>Select Interval...</option>
                    <?php
                        $sql_interval = "SELECT * FROM interval_table";
                        $result_interval = $conn->query($sql_interval);
                        while ($row_interval = $result_interval->fetch_assoc()) {
                            echo "<option value='" . $row_interval['name'] . "'>" . $row_interval['name'] . "</option>";
                        }
                    ?>
                </select>
                <label for="modalInspectionInterval">Inspection Interval</label>


                <!-- Person In Charge -->
                <div class="input-field">
                    <input type="text" id="modalPersonInCharge" required>
                    <label for="modalPersonInCharge">Person In Charge</label>
                </div>

                <!-- Criticality -->
                <div class="input-field">
                    <input type="text" id="modalCriticality" required>
                    <label for="modalCriticality">Criticality</label>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <a href="#!" class="modal-close waves-effect waves-green btn-flat">Cancel</a>
            <a href="#!" id="saveEditInspection" class="waves-effect waves-green btn-flat">Save</a>
        </div>
    </div>



    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script src="script/edit_equipment_script.js"></script>
    
    <script>
        var globalEquipmentId = $('#equipmentId').val();
        const equipmentId = $('#equipmentId').val();

        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);

            var elems = document.querySelectorAll('.modal');
            var instances = M.Modal.init(elems);

            // Code para sa M.toast() messages
            <?php if (isset($_SESSION['success'])): ?>
            M.toast({
                html: '<?php echo $_SESSION['success']; ?>',
                displayLength: 3000, // Magtatagal ng 3 seconds
                classes: 'toast' // Ito ang custom class na may red background
            });
            <?php unset($_SESSION['success']); ?>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
            M.toast({
                html: '<?php echo $_SESSION['error']; ?>',
                displayLength: 3000,
                classes: 'toast red' // Dagdag 'red' para sa error messages
            });
            <?php unset($_SESSION['error']); ?>
            <?php endif; ?>
        });

        $(document).on('click', '.btn-edit', function() {
            // Kuha ng current row
            var row = $(this).closest('tr');
            
            // Kuha ng data mula sa current row
            var metaId = row.data('meta-id');
            var inspectionType = row.find('.inspectionType').val();
            // var inspectionInterval = row.find('.inspectionInterval').val();
            var selectedInterval = row.find('.inspectionInterval').val();
            var personInCharge = row.find('.personInCharge').val();
            var criticality = row.find('.criticality').val();

            // Ilagay ang data sa modal form fields
            $('#modalMetaId').val(metaId);
            $('#modalInspectionType').val(inspectionType);
            // $('#modalInspectionInterval').val(inspectionInterval);
            $("#modalInspectionInterval option").each(function() {
                if($(this).val() == selectedInterval) {
                    $(this).prop("selected", true);
                }
            });
            $('select').formSelect();  // Reinitialize Materialize select
            $('#modalPersonInCharge').val(personInCharge);
            $('#modalCriticality').val(criticality);
            
            // Update labels sa modal para sa materialize css
            if(inspectionType) $('#modalInspectionType').siblings('label').addClass('active');
            // if(inspectionInterval) $('#modalInspectionInterval').siblings('label').addClass('active');
            if(selectedInterval) $('#modalInspectionInterval').siblings('label').addClass('active');

            if(personInCharge) $('#modalPersonInCharge').siblings('label').addClass('active');
            if(criticality) $('#modalCriticality').siblings('label').addClass('active');
            
            // Bukas ng modal
            var modalInstance = M.Modal.getInstance($('#editModal'));
            modalInstance.open();

        });


        $(document).on('click', '#saveEditInspection', function() {
            // Kuha ng data mula sa modal form fields
            var metaId = $('#modalMetaId').val();
            var inspectionType = $('#modalInspectionType').val();
            var inspectionInterval = $('#modalInspectionInterval').val();
            var personInCharge = $('#modalPersonInCharge').val();
            var criticality = $('#modalCriticality').val();

            // Object ng data na isu-submit
            var data = {
                meta_id: metaId, 
                equipment_id: globalEquipmentId,
                inspection_type: inspectionType,
                inspection_interval: inspectionInterval,
                person_in_charge: personInCharge,
                criticality: criticality
            };

            // AJAX request
            $.ajax({
                url: "save_equipment_from_edit.php",
                type: "POST",
                data: data,
                dataType: "json",
                success: function(response) {
                    if(response.status === "success") {
                        alert(response.message);
                        
                        // Update UI
                        var rowToUpdate = $('tr[data-meta-id="' + metaId + '"]');
                        rowToUpdate.find('.inspectionType').val(inspectionType);
                        rowToUpdate.find('.inspectionInterval').val(inspectionInterval);
                        rowToUpdate.find('.personInCharge').val(personInCharge);
                        rowToUpdate.find('.criticality').val(criticality);

                        // Close modal
                        var modalInstance = M.Modal.getInstance($('#editModal'));
                        modalInstance.close();
                    } else {
                        alert("Error: " + response.message);
                    }
                },
                error: function() {
                    alert("Something went wrong with the request.");
                }
            });
        });

        $(document).on('click', '.btn-delete', function() {
            console.log("Delete button clicked");
            var row = $(this).closest('tr');
            var metaId = row.data('meta-id');
            console.log('Meta ID:', metaId);  // Add this line

            // Confirm deletion
            if (confirm("Are you sure you want to delete this record?")) {
                // Your AJAX call for deletion here
                $.ajax({
                    url: "delete_meta.php", // Palitan mo ito sa actual na delete URL mo
                    type: "POST",
                    data: { meta_id: metaId },
                    dataType: "json",
                    success: function(response) {
                        if(response.status === "success") {
                            alert(response.message);
                            row.remove(); // Remove row from UI
                        } else {
                            alert("Error: " + response.message);
                        }
                    },
                    error: function() {
                        alert("Something went wrong with the request.");
                    }
                });
            }
            
        });


    </script>

</body>

</html>
