<?php

session_start();

include "db_connect.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $equipment_name = $_POST['equipment_name'];
    $equipment_type = $_POST['equipment_type'];

    $checkQuery = "SELECT equipment_name FROM rh_equipments WHERE equipment_name = ?";
    $checkStmt = $conn->prepare($checkQuery);
    $checkStmt->bind_param("s", $equipment_name);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    if ($checkResult->num_rows > 0) {
        $_SESSION['equipment_exists'] = true;
        header("Location: equipment_running_hours.php");
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO rh_equipments (equipment_name, equipment_type) VALUES (?, ?)");
    $stmt->bind_param("ss", $equipment_name, $equipment_type);
    $stmt->execute();

    $stmt->close();

    // Set a session variable for success
    $_SESSION['equipment_added'] = true;

    // Redirect back to the form page
    header("Location: equipment_running_hours.php");
    exit;

}

?>
