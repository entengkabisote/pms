<?php
session_start();

include 'db_connect.php';

// Check if there is a success message stored in the session
if (isset($_SESSION['successMessage'])) {
    $successMessage = $_SESSION['successMessage'];
    unset($_SESSION['successMessage']); // Clear the message after receiving it
} else {
    $successMessage = '';
}

// Fetch users
$query = "SELECT user_id, username, role FROM users";
$user_result = mysqli_query($conn, $query);
$users = mysqli_fetch_all($user_result, MYSQLI_ASSOC);

// Fetch permissions
$query = "SELECT permission_id, permission_name FROM permissions";
$permission_result = mysqli_query($conn, $query);
$permissions = mysqli_fetch_all($permission_result, MYSQLI_ASSOC);

// Handle POST request for assigning permissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];

    // First, remove all existing permissions for this user
    $query = "DELETE FROM user_permissions WHERE user_id = $user_id";
    mysqli_query($conn, $query);

    if(isset($_POST['permissions'])) {
        $selected_permissions = $_POST['permissions'];

        // Insert the new permissions
        foreach ($selected_permissions as $permission_id) {
            $query = "INSERT INTO user_permissions (user_id, permission_id) VALUES ($user_id, $permission_id)";
            mysqli_query($conn, $query);
        }
    }

    // Code for vessel assignment
    if(isset($_POST['vessel_id'])) {
        $vessel_id = $_POST['vessel_id'];
        // Assuming you have a user_id from the form as well
        $user_id = $_POST['user_id'];

        // Check if the user already has a vessel assigned and update or insert accordingly
        $check_query = "SELECT * FROM users_vessels WHERE user_id = $user_id";
        $check_result = mysqli_query($conn, $check_query);

        if(mysqli_num_rows($check_result) > 0) {
            // User already has a vessel, so we update
            $update_query = "UPDATE users_vessels SET vessel_id = $vessel_id WHERE user_id = $user_id";
            mysqli_query($conn, $update_query);
        } else {
            // No vessel assigned, so we insert
            $insert_query = "INSERT INTO users_vessels (user_id, vessel_id) VALUES ($user_id, $vessel_id)";
            mysqli_query($conn, $insert_query);
        }
    }

    // Store the success message in session
    $_SESSION['successMessage'] = "Permissions updated successfully!";

    // Redirect to the same page to prevent form resubmission
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit; // Important: prevent the script from continuing to run after a redirect
}

// Fetch vessels
$vessel_query = "SELECT id, vessel_name FROM vessels";
$vessel_result = mysqli_query($conn, $vessel_query);
$vessels = mysqli_fetch_all($vessel_result, MYSQLI_ASSOC);


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/user_style.css">
    <style>
        hr {
            margin-top: 20px;
        }

        .add-user, .permission {
            margin-top: 20px;
        }
        
        #toast-container {
            top: 50% !important;
            right: 50% !important;
            transform: translateX(50%) translateY(-50%) !important;
            bottom: auto !important;
            left: auto !important;
        }

        .toast {
            background-color: red !important;
        }
    </style>
</head>

<body>
<?php include 'header.php'; ?>
<h5>User Management</h5>

    <main class="user-container">
        <h4>List of Users</h4>
        <table>
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Role</th>
                    <!-- <th>Action</th> -->
                </tr>
            </thead>
            <tbody>
                <?php
                $query = "SELECT * FROM users"; // Assuming your database table name is 'users'
                $result = mysqli_query($conn, $query);
                
                while ($user = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>{$user['username']}</td>";
                    echo "<td>{$user['role']}</td>";
                    // echo "<td><a href='edit_user.php?id={$user['user_id']}'>Edit</a> | <a href='delete_user.php?id={$user['user_id']}'>Delete</a></td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>

        <!-- Add User Button -->
        <div class="add-user">
            <a href="add_user.php">Add New User</a>
        </div>
        

        <hr> <!-- Separator -->
        <div class="permission">
            <h4>Assign Permissions</h4>
        </div>
        
        <form method="POST" action="">
            <label for="user-select">Select User:</label>
            <select id="user-select" name="user_id">
                <?php foreach ($users as $user): ?>
                    <option value="<?= $user['user_id'] ?>"><?= $user['username'] ?></option>
                <?php endforeach; ?>
            </select>

            <h6>Permissions:</h6>
            <?php foreach ($permissions as $permission): ?>
                <p>
                    <label>
                        <input type="checkbox" name="permissions[]" value="<?= $permission['permission_id'] ?>" />
                        <span><?= $permission['permission_name'] ?></span>
                    </label>
                </p>
            <?php endforeach; ?>

            <h6>Vessels:</h6>
            <select id="vessel-select" name="vessel_id">
                <?php foreach ($vessels as $vessel): ?>
                    <option value="<?= $vessel['id'] ?>"><?= $vessel['vessel_name'] ?></option>
                <?php endforeach; ?>
            </select>
            
            <button class="btn waves-effect waves-light" type="submit">Assign Permissions</button>
        </form>
        <?php if($successMessage): ?>
    <p class="success-message"><?= $successMessage ?></p>
<?php endif; ?>

    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            <?php if(isset($_SESSION['success_message'])): ?>
            var message = <?php echo json_encode($_SESSION['success_message']); ?>;
            M.toast({html: message});
            <?php unset($_SESSION['success_message']); ?>
            <?php endif; ?>

            // Your existing initialization code
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);

            var elems = document.querySelectorAll('select');
            var instances = M.FormSelect.init(elems);
        });

        

        </script>
</body>

</html>
