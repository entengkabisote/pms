<?php
session_start();

if(isset($_SESSION['equipment_added']) && $_SESSION['equipment_added']) {
    echo "<div class='callout success' style='width: 400px; margin: 20px auto;'>Equipment added successfully!</div>";
    
    // Unset the session variable immediately after displaying the message
    unset($_SESSION['equipment_added']);
}

if (isset($_SESSION['equipment_exists']) && $_SESSION['equipment_exists']) {
    echo "<div class='callout warning' style='width: 400px; margin: 20px auto;'>Equipment name already exists!</div>";
    unset($_SESSION['equipment_exists']);
}
include "db_connect.php";

$equipments_list = [];
$query = "SELECT * FROM rh_equipments";
$result = $conn->query($query);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $equipments_list[] = $row;
    }
}

// Fetch equipment types from the machinery table
$equipment_types = [];
$type_query = "SELECT category FROM machinery"; // Replace 'type_name' with the actual column name for equipment type in your machinery table
$type_result = $conn->query($type_query);
if ($type_result->num_rows > 0) {
    while($type_row = $type_result->fetch_assoc()) {
        $equipment_types[] = $type_row['category']; // Replace 'type_name' with your actual column name
    }
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PMS | Vessel Details</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/styles.css">
    <link rel="stylesheet" href="styles/equipment_rh_styles.css">   
    <link rel="stylesheet" href="styles/buttons.css">
</head>

<body>
<?php include 'header.php'; ?>
    <div>
        <h5 class="center-align">Machineries Management Dashboard</h5> <!-- Add center-align class -->
    </div>
    <div class="col equipment-rh-container">
        <div class="row">
            <div class="col s12">
                <form action="add_equipment_rh.php" method="POST">
                    <div class="input-field">
                        <input type="text" id="equipment_name" name="equipment_name" required>
                        <label for="equipment_name">Equipment Name:</label>
                    </div>
                    
                    <div class="input-field">
                        <select id="equipment_type" name="equipment_type" required>
                            <option value="" disabled selected>Select Category...</option>
                            <?php foreach ($equipment_types as $type): ?>
                                <option value="<?php echo htmlspecialchars($type); ?>"><?php echo htmlspecialchars($type); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <label for="equipment_type">Equipment Type:</label>
                    </div>

                    <button class="btn-small waves-effect waves-light blue" type="submit" name="action">Add Equipment
                        <i class="material-icons left">send</i>
                    </button>

                    <div style="float: right;">
                        <a href="index.php" class="btn-small waves-effect waves-light"><i class="material-icons left">home</i>Home</a>
                    </div>
                </form>

            </div>
        </div>
        <div class="row">
            <div class="col s12">
                <h5 class="center-align">Existing Machineries</h5> <!-- Add center-align class -->
                <table class="highlight">

                    <thead>
                        <tr>
                            <th class="col-equip-id">ID</th>
                            <th class="col-equip-name">Equipment Name</th>
                            <th class="col-equip-type">Equipment Type</th>
                            <th class="col-actions">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($equipments_list as $equipment): ?>
                        <tr>
                            <td><?php echo $equipment['equipment_id']; ?></td>
                            <td><?php echo $equipment['equipment_name']; ?></td>
                            <td ><?php echo $equipment['equipment_type']; ?></td>
                            <td class="action-buttons">
                                <a href="edit_equipment_rh.php?id=<?php echo $equipment['equipment_id']; ?>" class="btn-small waves-effect waves-light blue-grey darken-2">
                                    <i class="material-icons left">edit</i>
                                </a>

                                <a href="delete_equipment_rh.php?id=<?php echo $equipment['equipment_id']; ?>" class="btn-small waves-effect waves-light red" onclick="return confirm('Are you sure you want to delete this?');">
                                    <i class="material-icons left">delete</i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>


    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);

            var elems = document.querySelectorAll('select');
            var instances = M.FormSelect.init(elems);
        });
        </script>
</body>

</html>
