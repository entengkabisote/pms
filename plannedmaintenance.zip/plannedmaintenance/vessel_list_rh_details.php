<?php
include "db_connect.php";
$vessel_id = $_GET['id'];

// Fetch vessel name using the vessel_id
    // $vessel_id = $row['vessel_id'];
    $vessel_query = "SELECT vessel_name FROM vessels WHERE id = $vessel_id";
    $vessel_result = mysqli_query($conn, $vessel_query);
    $vessel_row = mysqli_fetch_assoc($vessel_result);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/vessel_list_rh_details_style.css">
</head>

<body>
<?php include 'header.php'; ?>
    <h5>Details for Vessel ID: <?php echo $vessel_row['vessel_name']; ?></h5>
    <main class="vessel-list-rh-details-container">
        <div class="grid-container">
            
        <a class="btn-small waves-effect waves-light" href="vessel_maintenance.php?id=<?php echo $vessel_id; ?>"> <i class="material-icons left">arrow_back</i>Back</a>
            <table class="hover">
                <thead>
                    <tr>
                        <th style="width: 8%;">Equipment Type</th>
                        <th style="width: 10%;">Equipment Name</th>
                        <th style="width: 53%;">Task Description</th>
                        <th style="width: 5%;">Threshold Hour</th>
                        <th style="width: 7%;">Date Modified</th>
                        <th style="width: 6%;">Total Running Hours</th>
                        <th style="width: 6%;">Remaining Hours</th>
                        <th style="width: auto;">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "
                    SELECT 
                        e.equipment_type, 
                        e.equipment_name, 
                        t.task_description, 
                        t.threshold_hour, 
                        v.date_modified, 
                        v.total_running_hours, 
                        v.remaining_hours,
                        v.status 
                    FROM vessel_rh_equipment v
                    JOIN tasks t ON v.task_id = t.task_id
                    JOIN rh_equipments e ON v.equipment_id = e.equipment_id
                    WHERE v.vessel_id = ? 
                    GROUP BY e.equipment_type, e.equipment_name, t.task_description, v.date_modified, v.total_running_hours, v.remaining_hours, v.status";
                    
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $vessel_id);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['equipment_type'] . "</td>";
                        echo "<td>" . $row['equipment_name'] . "</td>";
                        echo "<td>" . $row['task_description'] . "</td>";
                        echo "<td>" . $row['threshold_hour'] . "</td>";
                        echo "<td>" . $row['date_modified'] . "</td>";
                        echo "<td>" . $row['total_running_hours'] . "</td>";
                        echo "<td>" . $row['remaining_hours'] . "</td>";
                        echo "<td>" . $row['status'] . "</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

        
        </script>
</body>

</html>
