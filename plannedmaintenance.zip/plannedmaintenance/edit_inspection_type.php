<?php
session_start();
include 'db_connect.php';

// Check if the meta_id and equipment_id are set in the URL
if (!isset($_GET['meta_id']) || !isset($_GET['equipment_id'])) {
    // Handle the error appropriately
    die('Required parameters are not specified.');
}

$meta_id = $_GET['meta_id'];
$equipment_id = $_GET['equipment_id'];  // Get equipment_id from URL

// Fetch inspection_meta_table data for the given meta_id
$sql_meta = "SELECT * FROM inspection_meta_table WHERE meta_id = ?";
$stmt = $conn->prepare($sql_meta);
$stmt->bind_param("i", $meta_id);
$stmt->execute();
$result_meta = $stmt->get_result();
$row_meta = $result_meta->fetch_assoc();

// If no record is found, handle it as needed
if (!$row_meta) {
    // Redirect back or handle the error
    die('No record found for the provided ID.');
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/edit_inspection_type.css">
</head>

<body>
    <?php include 'header.php'; ?>
    <h5 class="center-align">Edit Inspection for Equipment</h5>

    <main class="edit-inspection-type-container">
        <form action="update_inspection_type.php" method="post">
            <input type="hidden" name="metaId" value="<?php echo $meta_id; ?>">
            <input type="hidden" name="equipmentId" value="<?php echo $equipment_id; ?>">

            <label for="inspectionType">Inspection Type</label>
            <input type="text" name="inspectionType" id="inspectionType" value="<?php echo htmlspecialchars($row_meta['inspection_type']); ?>" required>

            <label for="inspectionInterval">Inspection Interval</label>
            <input type="text" name="inspectionInterval" id="inspectionInterval" value="<?php echo htmlspecialchars($row_meta['inspection_interval']); ?>" required>

            <label for="personInCharge">Person In Charge</label>
            <input type="text" name="personInCharge" id="personInCharge" value="<?php echo htmlspecialchars($row_meta['person_in_charge']); ?>" required>

            <label for="criticality">Criticality</label>
            <input type="text" name="criticality" id="criticality" value="<?php echo htmlspecialchars($row_meta['criticality']); ?>" required>

            <button class="btn waves-effect waves-light" type="submit" name="updateInspectionType">Update Inspection Type</button>
            <a href="edit_equipment.php?id=<?php echo $equipment_id; ?>" class="btn waves-effect waves-light grey">Cancel</a>
        </form>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

        
        </script>
</body>

</html>
