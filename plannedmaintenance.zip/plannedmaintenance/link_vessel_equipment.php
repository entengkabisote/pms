<?php
session_start();

include "db_connect.php";

$equipment_sets = [
    'propulsion1' => [1, 2, 3],
    'propulsion2' => [5, 6, 7],
    'auxiliary1' => [4],
    'auxiliary2' => [8]
];

function getEquipmentType($conn, $equipment_id) {
    $query = "SELECT equipment_type FROM rh_equipments WHERE equipment_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $equipment_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['equipment_type'];
    }
    return null;
}


function getTaskInfoFromEquipment($conn, $equipment_id) {
    $data = ['task_id' => null, 'threshold_hour' => null];

    $query = "SELECT task_id, threshold_hour FROM tasks WHERE equipment_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $equipment_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $data['task_id'] = $row['task_id'];
        $data['threshold_hour'] = $row['threshold_hour'];
    }
    
    return $data;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $vessel_id = $_POST['vessel_id'];

    $selectedEquipmentSets = $_POST['equipment_sets'] ?? [];

    $equipment_ids = [];
    foreach ($selectedEquipmentSets as $set) {
        if (isset($equipment_sets[$set])) {
            $equipment_ids = array_merge($equipment_ids, $equipment_sets[$set]);
        }
    }

    $selectedTypes = [];
    foreach ($selectedEquipmentSets as $set) {
        if (isset($equipment_sets[$set])) {
            foreach($equipment_sets[$set] as $equipID) {
                $type = getEquipmentType($conn, $equipID);
                $selectedTypes[] = $type;
            }
        }
    }

    $checkQuery = "SELECT rh_equipments.equipment_type 
               FROM vessel_rh_equipment 
               JOIN rh_equipments 
               ON vessel_rh_equipment.equipment_id = rh_equipments.equipment_id 
               WHERE vessel_rh_equipment.vessel_id = ?";
    $checkStmt = $conn->prepare($checkQuery);
    $checkStmt->bind_param("i", $vessel_id);
    $checkStmt->execute();

    $existingEquipmentTypes = [];
    $checkResult = $checkStmt->get_result();
    while($row = $checkResult->fetch_assoc()) {
        $existingEquipmentTypes[] = $row['equipment_type'];
    }

    foreach ($selectedTypes as $type) {
        if (in_array($type, $existingEquipmentTypes)) {
            $_SESSION['vessel_exists'] = true;
            header("Location: vessel_link_to_equipment.php?vessel_id=" . $vessel_id);
            exit;
        }
    }


    if (empty($vessel_id) || empty($equipment_ids)) {
        $_SESSION['incomplete_data'] = true;
        header("Location: vessel_link_to_equipment.php?vessel_id=" . $vessel_id);
        exit;
    }

    

    $stmt = $conn->prepare("INSERT INTO vessel_rh_equipment (vessel_id, equipment_id, task_id, date_added, total_running_hours, date_modified, status, remarks, threshold_hour) VALUES (?, ?, ?, CURDATE(), ?, ?, ?, ?, ?)");

    foreach ($equipment_ids as $equipment_id) {
        // Get all tasks associated with this equipment
        $taskQuery = "SELECT task_id, threshold_hour FROM tasks WHERE equipment_id = ?";
        $taskStmt = $conn->prepare($taskQuery);
        $taskStmt->bind_param("i", $equipment_id);
        $taskStmt->execute();
        $taskResult = $taskStmt->get_result();
            
        $total_running_hours = 0;
        $date_modified = date("Y-m-d H:i:s");  // Current date and time
        $status = "pending";
        $remarks = "Initial Link";
    
        while ($taskRow = $taskResult->fetch_assoc()) {
            $task_id = $taskRow['task_id'];
            $threshold_hour = $taskRow['threshold_hour'];
            $stmt->bind_param("iiiiissi", $vessel_id, $equipment_id, $task_id, $total_running_hours, $date_modified, $status, $remarks, $threshold_hour);
            
            if (!$stmt->execute()) {
                echo "Error linking task ID $task_id: " . $conn->error . "<br>";
            }
        }
    }
    

    $_SESSION['link_added'] = true;
    header("Location: vessel_link_to_equipment.php?vessel_id=" . $vessel_id);

    exit;
}
?>
