<?php
include 'db_connect.php';

// Set the username and the new password
$username = 'user1'; // The username of the admin user
$newPassword = 'user1'; // The new password you want to set

// Hash the new password
$hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

// Prepare the SQL statement
$stmt = $conn->prepare("UPDATE users SET password = ? WHERE username = ?");
$stmt->bind_param("ss", $hashedPassword, $username);

// Execute the statement and check for success
if ($stmt->execute()) {
    echo "Password updated successfully for user {$username}";
} else {
    echo "Error updating password: " . $conn->error;
}

$stmt->close();
$conn->close();
?>
