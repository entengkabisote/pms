<?php
include 'db_connect.php';

session_start();

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}


if($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];

    // Check if record exists
    $stmt = $conn->prepare("SELECT id FROM interval_table WHERE name = ?");
    $stmt->bind_param("s", $name);
    $stmt->execute();
    $stmt->store_result();

    if($stmt->num_rows > 0) {
        echo "Record already exists!";
        $stmt->close();
    } else {
        $stmt->close();

        // Insert new record
        $stmt = $conn->prepare("INSERT INTO interval_table (name) VALUES (?)");
        $stmt->bind_param("s", $name);
        
        if ($stmt->execute()) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    }
}

if (isset($_SESSION['flash_message'])) {
    $flashMessage = $_SESSION['flash_message'];
    unset($_SESSION['flash_message']);
} else {
    $flashMessage = '';
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/add_interval_style.css">
    <link rel="stylesheet" href="styles/buttons.css">
    <style>
        #toast-container {
            top: 50% !important;
            right: 50% !important;
            transform: translateX(50%) translateY(-50%);
        }
    </style>
</head>

<body>
<?php include 'header.php'; ?>

<main class="add-interval-container">
    <h5 class="center-align">Insert interval</h5>
    <form action="secured_insert.php" method="post">
        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
        <div class="input-field">
            <input type="text" id="name" name="name">
            <label for="name">Name</label>
        </div>
        <button class="btn waves-effect waves-light" type="submit">Submit</button>
        <div style="float: right;">
            <a href="index.php" class="btn-small waves-effect waves-light"><i class="material-icons left">home</i>Home</a>
        </div>
    </form>
    
    <div class="existing-intervals-container">
    <h5 class="center-align">Existing Intervals</h5>
    <table class="highlight centered">
        <thead>
            <tr>
                <th>Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT id, name FROM interval_table";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $row["name"] . '</td>';
                    echo '<td><a href="edit_interval.php?id='.$row["id"].'" class="btn-small waves-effect waves-light blue">Edit</a> ';
                    // echo '<a href="delete.php?id='.$row["id"].'" class="btn-small waves-effect waves-light red">Delete</a></td>';
                    echo '<a href="delete_interval.php?id=' . $row["id"] . '&csrf_token=' . $_SESSION['csrf_token'] . '" class="btn-small waves-effect waves-light red">Delete</a>';

                    
                    echo '</tr>';
                }
            } else {
                echo '<tr><td colspan="2">No intervals found.</td></tr>';
            }
            ?>
        </tbody>
    </table>
</div>


</main>


<footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

        document.addEventListener('DOMContentLoaded', function() {
            var message = '<?php echo $flashMessage; ?>';
            if (message !== '') {
                var toastHTML = '<span>' + message + '</span>';
                M.toast({html: toastHTML, classes: 'red darken-2 center-align'});
            }
        });
        </script>
</body>

</html>