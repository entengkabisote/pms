<?php

include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $vessel_id = $_POST['vessel_id'];
    $selectedEquipments = $_POST['equipment'] ?? []; // Default to empty array if not set

    // echo "<pre>";
    // var_dump($_POST);
    // echo "</pre>";
    // exit; // This is only temporary so the script won't continue.

    $insert_query = "INSERT INTO vessel_equipment (vessel_id, equipment_id, inspection_meta_id, date_added) VALUES (?, ?, ?, CURDATE())";
    $insert_stmt = $conn->prepare($insert_query);
    if (!$insert_stmt) {
        die("Insert Prepare failed: " . $conn->error);
    }

    $success = true;
    $itemsInserted = false;
    $error_messages = [];

    foreach ($selectedEquipments as $equipment_id) {
        // If there are specific inspection_types selected for this equipment, use those
        if (isset($_POST['inspection_types'][$equipment_id])) {
            $selectedInspectionTypes = $_POST['inspection_types'][$equipment_id];
            foreach ($selectedInspectionTypes as $meta_id) {
                $insert_stmt->bind_param("iii", $vessel_id, $equipment_id, $meta_id);
                if ($insert_stmt->execute()) {
                    if ($conn->affected_rows > 0) {
                        $itemsInserted = true;
                    }
                } else {
                    $success = false;
                    $error_messages[] = "Error during insert: " . $insert_stmt->error;
                }
            }
        }
    }

    $insert_stmt->close();

    if ($success && $itemsInserted) {
        echo "<script>alert('Data successfully saved!');window.location.href = 'vessel_maintenance.php?id=$vessel_id';</script>";
    } elseif ($success && !$itemsInserted) {
        echo "<script>alert('No new data to save.');window.location.href = 'vessel_maintenance.php?id=$vessel_id';</script>";
    } else {
        $error_message = implode("\\n", $error_messages);
        echo "<script>alert('Data not saved due to errors.\\n$error_message');window.location.href = 'vessel_maintenance.php?id=$vessel_id';</script>";
    }
} else {
    echo "Invalid request method.";
}
?>
