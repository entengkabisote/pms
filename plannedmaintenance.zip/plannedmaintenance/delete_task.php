<?php
include "db_connect.php";

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "DELETE FROM tasks WHERE task_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: rh_tasks.php?delete_success=1");
    } else {
        echo "Error: " . $conn->error;
    }

    $stmt->close();
}
?>
