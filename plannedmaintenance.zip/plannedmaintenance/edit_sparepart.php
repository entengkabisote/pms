<?php
session_start();
include 'db_connect.php';

// Initialize variables
$part_id = $_GET['id'] ?? 0; // Using filter_var() is a good practice for more security
$task_id = $_GET['task_id'] ?? 0;
$equipment_id = $_GET['equipment_id'] ?? 0;
$sparePart = null;

// Check if the ID is valid
if ($part_id > 0) {
    // Query the database for the spare part
    $stmt = $conn->prepare("SELECT id, part_name, location, quantity FROM spare_parts WHERE id = ?");
    $stmt->bind_param("i", $part_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $sparePart = $result->fetch_assoc();
    }
    $stmt->close();
}

$message = ''; // To hold success or error message

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Assign POST data to variables and validate/sanitize
    $part_name = $_POST['part_name'] ?? '';
    $location = $_POST['location'] ?? '';
    $quantity = $_POST['quantity'] ?? 0;

    // Update the spare part
    $stmt = $conn->prepare("UPDATE spare_parts SET part_name = ?, location = ?, quantity = ? WHERE id = ?");
    $stmt->bind_param("ssii", $part_name, $location, $quantity, $part_id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        $message = 'Spare part updated successfully!';
    } else {
        $message = 'No changes made or update failed.';
    }

    $stmt->close();
    // Consider redirecting to the list page or you can display the message on this page.
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Spare Part | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/edit_sparepart_style.css">
</head>

<body>
<?php include 'header.php'; ?>

    <main class="edit-spare-container">
        <h5>Edit Spare Part</h5>
        <?php if($message): ?>
            <p><?php echo $message; ?></p>
        <?php endif; ?>
        <form action="edit_spareparts.php?id=<?php echo $part_id; ?>&task_id=<?php echo $task_id; ?>&equipment_id=<?php echo $equipment_id; ?>" method="post">
            <div class="input-field">
                <input type="text" name="part_name" id="part_name" value="<?php echo htmlspecialchars($sparePart['part_name'] ?? '', ENT_QUOTES); ?>" required>
                <label for="part_name">Part Name</label>
            </div>
            <div class="input-field">
                <input type="text" name="location" id="location" value="<?php echo htmlspecialchars($sparePart['location'] ?? '', ENT_QUOTES); ?>" required>
                <label for="location">Location</label>
            </div>
            <div class="input-field">
                <input type="number" name="quantity" id="quantity" value="<?php echo htmlspecialchars($sparePart['quantity'] ?? 0, ENT_QUOTES); ?>" required>
                <label for="quantity">Quantity</label>
            </div>
            <button type="submit" class="btn waves-effect waves-light">Update Spare Part</button>
            <a href="spareparts.php?task_id=<?php echo $task_id; ?>&equipment_id=<?php echo $equipment_id; ?>&id=<?php echo $part_id; ?>" class="btn grey">Cancel</a>


        </form>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

        
        </script>
</body>

</html>
