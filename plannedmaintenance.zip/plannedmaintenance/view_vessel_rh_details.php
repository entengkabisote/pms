<?php
include "db_connect.php";
session_start();

// Custom order configuration
$customOrder = [
    'Propulsion 1' => 1,
    'Propulsion 2' => 2,
    'Auxiliary 1' => 3,
    'Auxiliary 2' => 4,
    // Other equipment types as needed
];

// Function to determine the type of equipment
function determineEquipmentType($equipment_name) {
    if (preg_match('/(main engine 1|gearbox 1|z-peller 1)/i', $equipment_name)) {
        return "Propulsion 1";
    } elseif (preg_match('/(main engine 2|gearbox 2|z-peller 2)/i', $equipment_name)) {
        return "Propulsion 2";
    } elseif (preg_match('/generator 1/i', $equipment_name)) {
        return "Auxiliary 1";
    } elseif (preg_match('/generator 2/i', $equipment_name)) {
        return "Auxiliary 2";
    } else {
        return "Others";
    }
}

// Function to sort equipment based on custom order
function sortEquipmentType($equipmentDataArray, $customOrder) {
    uasort($equipmentDataArray, function($a, $b) use ($customOrder) {
        $typeA = determineEquipmentType(array_keys($a)[0]);
        $typeB = determineEquipmentType(array_keys($b)[0]);
        return $customOrder[$typeA] <=> $customOrder[$typeB];
    });
    return $equipmentDataArray;
}




$vessel_id = $_GET['vessel_id'];  // Gets the vessel_id from URL

// Fetch vessel name
$sql = "SELECT vessel_name FROM vessels WHERE id = $vessel_id";
$vesselResult = $conn->query($sql);
$vesselName = $vesselResult->fetch_assoc()['vessel_name'];


$query = "SELECT ve.equipment_id, ve.task_id, re.equipment_type, re.equipment_name, t.task_description, t.threshold_hour
          FROM vessel_rh_equipment ve
          JOIN rh_equipments re ON ve.equipment_id = re.equipment_id
          LEFT JOIN tasks t ON ve.task_id = t.task_id
          WHERE ve.vessel_id = $vessel_id
          ORDER BY re.equipment_type, re.equipment_name, t.threshold_hour, ve.task_id";


$result = $conn->query($query);

// Logic for fetching and sorting equipment data
$equipmentDataArray = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $equipment_type = determineEquipmentType($row['equipment_name']);
        $equipmentDataArray[$equipment_type][$row['equipment_name']][] = $row;
    }
}

if (empty($equipmentDataArray)) {
    echo "<p class='centered-message'>No linked equipment or tasks found. <a href='vessel_link_to_equipment.php?vessel_id=" . $vessel_id . "'>Please link equipment first</a>.</p>";
} else {
    // Apply custom sorting
    $equipmentDataArray = sortEquipmentType($equipmentDataArray, $customOrder);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/view_vessel_rh_details_stylel.css">
</head>

<body>
<?php include 'header.php'; ?>

    <main class="view-vessel-rh-details-container">
        <div class="grid-x grid-padding-x">
            <div class="medium-12 cell">
                <h5 class="text-center">Vessel Name: <?php echo $vesselName; ?></h5>
                <div style="float: left;">
                    <a href="vessel_maintenance.php?id=<?php echo $vessel_id; ?>" class="btn-small waves-effect waves-light"><i class="material-icons left">arrow_back</i>Back to Vessel Details</a>
                </div>
                <div style="float: right;">
                    <button id="saveInputs" class="btn-small waves-effect waves-light inspection-btn blue" form="myForm">Save Inputs</button>
                </div>
                
                <?php

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $equipment_type = determineEquipmentType($row['equipment_name']); // Gamitin ang function para malaman ang type
                            $equipmentDataArray[$equipment_type][$row['equipment_name']][] = $row; // Ilagay ang data sa tamang type
                        }

                        // Apply custom sorting
                        $equipmentDataArray = sortEquipmentType($equipmentDataArray, $customOrder); // Ito na ang tamang lugar para sa custom sorting function
                    } else {
                        echo "<p class='centered-message'>No linked equipment or tasks found. <a href='vessel_link_to_equipment.php?vessel_id=" . $vessel_id . "'>Please link equipment first</a>.</p>";
                    }
                ?>
                <form id="myForm" action="handle_form_submission.php" method="post">
                <input type="hidden" name="vessel_id" value="<?php echo $vessel_id; ?>">
                    <table class="hover">
                        <thead>
                            <tr>
                                <th>Equipment Type</th>
                                <th>Equipment Name</th>
                                <th>Task</th>
                                <th>Threshold Hour</th>
                                <th>Date</th>
                                <th>Running Hours</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                // Custom sorting function
                                
                                // $equipmentDataArray = sortEquipmentType($equipmentDataArray);
                                // $addedTypes = [];

                                foreach ($equipmentDataArray as $equipment_type => $equipment_names) {
                                    echo "<tr class='propulsion1'><td colspan='4'><strong>$equipment_type</strong></td>";
                                    echo "<td><input type='date' class='center-input' name='date[" . $equipment_type . "]'></td>";

                                    echo "<td style='display: flex; justify-content: center;'>";
                                    echo "<input class='center-align' type='text' name='running_hours[" . $equipment_type . "][hours]' placeholder='HH' pattern='[0-9]{1,2}' style='width:50px; margin-right: 5px; text-align: center;'>h ";
                                    echo "<input class='center-align' type='text' name='running_hours[" . $equipment_type . "][minutes]' placeholder='MM' pattern='[0-5]?[0-9]' style='width:50px; text-align: center;'>m";
                                    echo "</td></tr>";
                                    foreach ($equipment_names as $equipment_name => $tasks) {
                                        echo "<tr><td>&nbsp;</td><td colspan='2'><strong>$equipment_name</strong></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>";
                                        foreach ($tasks as $task) {
                                            $task_desc = isset($task['task_description']) ? $task['task_description'] : 'N/A';
                                            $threshold_hour = isset($task['threshold_hour']) ? $task['threshold_hour'] : 'N/A';
                                            echo "<tr><td>&nbsp;</td><td>&nbsp;</td><td>$task_desc</td><td>$threshold_hour</td><td>&nbsp;</td><td>&nbsp;</td></tr>";
                                        }
                                    }
                                }
                            ?>
                        </tbody>
                    </table>     
                </form>
            </div>
        </div>
    </main>
    <button onclick="topFunction()" id="myBtn" title="Go to top">Top</button>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>
    

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

            <?php if (isset($_SESSION['message'])): ?>
        alert("<?php echo $_SESSION['message']; ?>");

        <?php unset($_SESSION['message']); ?>
        <?php endif; ?>
        
        // When the user scrolls down 20px from the top of the document, show the button
        window.onscroll = function() {scrollFunction()};

        function scrollFunction() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            document.getElementById("myBtn").style.display = "block";
        } else {
            document.getElementById("myBtn").style.display = "none";
        }
        }

        // When the user clicks on the button, scroll to the top of the document
        function topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
        }

        </script>
        
</body>

</html>
