<?php
session_start();

include 'db_connect.php';

// Initialize otp_attempts if not set
if (!isset($_SESSION['otp_attempts'])) {
    $_SESSION['otp_attempts'] = 0;
}

// Max attempts allowed
$max_attempts = 3;

// Database connection setup - Palitan ng iyong actual credentials

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if OTP is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_otp = $_POST['otp'];

    // Check if the OTP is correct and not expired (e.g., 5 minutes)
    if (isset($_SESSION['otp'], $_SESSION['otp_time']) &&
        time() - $_SESSION['otp_time'] < 5*60) {
        if ($user_otp == $_SESSION['otp']) {
            // Unset OTP and attempts data from session after successful verification
            unset($_SESSION['otp']);
            unset($_SESSION['otp_time']);
            unset($_SESSION['otp_attempts']);
            
            // Set user as logged in
            $_SESSION['loggedin'] = true;

            // Retrieve user_id from session or other persistent storage
            $user_id = $_SESSION['user_id']; // Ensure this is already set during login

            // Retrieve fullname from the database
            $query = "SELECT fullname FROM users WHERE user_id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($row = $result->fetch_assoc()) {
                $fullname = $row['fullname'];
            } else {
                // Handle error, user not found or similar
                $_SESSION['error_message'] = 'Unable to retrieve your full name.';
                header('Location: login.php');
                exit;
            }

            // After successful login
            $_SESSION['user_id'] = $user_id; // Storing user ID in session
            $_SESSION['fullname'] = $fullname; // Set fullname here
            
            // Redirect to dashboard
            header('Location: index.php');
            exit;
        } else {
            // Increment the OTP attempts if the OTP is not correct
            $_SESSION['otp_attempts']++;

            // Check if attempts have exceeded max attempts
            if ($_SESSION['otp_attempts'] >= $max_attempts) {
                // Reset the counter after max attempts have been reached
                $_SESSION['otp_attempts'] = 0; // Reset the counter or handle according to your security policy

                // Redirect to login page with error message
                $_SESSION['error_message'] = 'You have exceeded the maximum number of attempts. Please try again.';
                header('Location: login.php');
                exit;
            }
        }
    } else {
        // Set error message for wrong or expired OTP
        $_SESSION['error_message'] = 'Invalid or expired OTP.';
        // Redirect to login page with error message
        header('Location: login.php');
        exit;
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/verify_otp_style.css">
    <style>
        .time-container {
            text-align: center;
            font-size: 24px; 
            color: red;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <?php include 'head.php'; ?>
    <main class="verify-otp-container">
        <?php if (isset($_SESSION['message'])): ?>
            <p class="green-text center-align"><?php echo $_SESSION['message']; ?></p>
        <?php 
            // Clear the message after displaying it
            unset($_SESSION['message']); 
        endif; 
        ?>

        <form action="verify_otp.php" method="post">
            <label for="otp">Enter OTP:</label>
            <input type="text" id="otp" name="otp" required>
            <input type="submit" value="Verify OTP">
        </form>
        <?php if (!empty($error)) echo "<p>$error</p>"; ?>
        <div>
            <p id="timer" class="time-container"></p>
        </div>
    </main>
    

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);

            var elems = document.querySelectorAll('select');
            var instances = M.FormSelect.init(elems);
        });

        // Set the time we're counting down to
        var countDownDate = new Date().getTime() + 2*60*1000;

        // Update the count down every 1 second
        var x = setInterval(function() {

            // Get today's date and time
            var now = new Date().getTime();
            
            // Find the distance between now and the count down date
            var distance = countDownDate - now;
            
            // Time calculations for minutes and seconds
            var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);
            
            // Output the result in an element with id="timer"
            document.getElementById("timer").innerHTML = minutes + "m " + seconds + "s ";
            
            // If the count down is over, write some text 
            if (distance < 0) {
                clearInterval(x);
                document.getElementById("timer").innerHTML = "EXPIRED";
                // Redirect to login.php after OTP expires
                window.location.href = 'login.php';
            }
        }, 1000);
        
        </script>
</body>

</html>
