<?php
session_start();
include 'db_connect.php';

// *********************************************************************************************************************************************************
// Check Permission
// *********************************************************************************************************************************************************


// Check if vessel_id and user_id are set
$vessel_id = isset($_GET['vessel_id']) ? $_GET['vessel_id'] : null;
if ($vessel_id === null) {
    // Handle the case where vessel_id is not set
    // Redirect back or show an error message
    header("Location: some_error_page.php");
    exit;
}

if (!isset($_SESSION['user_id'])) {
    die("You need to login.");
}

$userId = $_SESSION['user_id'];

function userHasPermission($desiredPermission, $userId, $conn) {
    $query = "SELECT permission_name FROM user_permissions INNER JOIN permissions ON user_permissions.permission_id = permissions.permission_id WHERE user_permissions.user_id = ?";
    
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $userId);
    mysqli_stmt_execute($stmt);
    
    $result = mysqli_stmt_get_result($stmt);
    $permissions = []; 
    while ($row = mysqli_fetch_assoc($result)) {
        if (strcasecmp($row['permission_name'], $desiredPermission) == 0) {
            return true; // found the permission, return true
        }
    }
    
    error_log("User ID: $userId, Permissions: " . implode(', ', $permissions)); // Log permissions
    return false; // not found permission, return false
}

if (!userHasPermission("Edit Equipment", $userId, $conn)) {
    // Check if the vessel_id is present and is not empty
    if (isset($_GET['vessel_id']) && !empty($_GET['vessel_id'])) {
        $vessel_id = $_GET['vessel_id'];
        echo "<script>alert('Sorry, you don\'t have permission for this.'); window.location.href='vessel_maintenance.php?id=$vessel_id';</script>";
    } else {
        // If there's no vessel_id, redirect to a page where the user can choose a vessel
        echo "<script>alert('Vessel ID is missing or you do not have permission.'); window.location.href='vessel_maintenance.php';</script>";
    }
    exit;
}

// *********************************************************************************************************************************************************


$vessel_id = isset($_GET['vessel_id']) ? $_GET['vessel_id'] : null;
if ($vessel_id === null) {
    die("Vessel ID is required.");
}

// Fetch categories, equipment, and linked inspection types for the vessel
$query = "SELECT et.category, ve.equipment_id, et.equipment_name, ve.inspection_meta_id, im.inspection_type
          FROM vessel_equipment ve
          INNER JOIN equipment_table et ON ve.equipment_id = et.equipment_id
          INNER JOIN inspection_meta_table im ON ve.inspection_meta_id = im.meta_id
          WHERE ve.vessel_id = ?
          ORDER BY et.category, et.equipment_name";


$stmt = $conn->prepare($query);
$stmt->bind_param("i", $vessel_id);
$stmt->execute();
$result = $stmt->get_result();

// Arrange the equipment by category
// Arrange the equipment by category
$equipmentByCategory = [];
while($row = $result->fetch_assoc()) {
    // Check if there is a valid inspection_meta_id, meaning it is linked to the vessel
    if ($row['inspection_meta_id'] !== null) {
        $equipmentId = $row['equipment_id'];
        $equipmentByCategory[$row['category']][$equipmentId]['equipment_name'] = $row['equipment_name'];
        $equipmentByCategory[$row['category']][$equipmentId]['inspection_types'][$row['inspection_meta_id']] = $row['inspection_type'];
    }
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/edit_equipment_vessel_style.css">
</head>

<body>
    <?php include 'header.php'; ?>
    <h5>Edit Equipment and Inspection Types for Vessel ID: <?php echo htmlspecialchars($vessel_id); ?></h5>
    <main class="edit-equipment-vessel-container">
        <form action="update_equipment_vessel.php" method="post">
            <input type="hidden" name="vessel_id" value="<?php echo htmlspecialchars($vessel_id); ?>">
            <ul class="collapsible">
            <?php foreach ($equipmentByCategory as $category => $equipments): ?>
    <li>
        <div class="collapsible-header"><?php echo htmlspecialchars($category); ?></div>
        <div class="collapsible-body">
            <span>
                <?php foreach ($equipments as $equipmentId => $equipment): ?>
                    <?php if (!empty($equipment['inspection_types'])): ?>
                        <label>
                            <span><?php echo htmlspecialchars($equipment['equipment_name']); ?></span>
                        </label>
                        <ul class="inspection-types">
                            <?php foreach ($equipment['inspection_types'] as $inspectionMetaId => $inspectionType): ?>
                                <!-- Ensure that inspection_meta_id is not null or empty -->
                                <?php if (!empty($inspectionMetaId)): ?>
                                    <li>
                                        <label>
                                            <input type="checkbox" name="inspection_to_delete[]" 
                                                value="<?php echo $equipmentId.','.$inspectionMetaId; ?>"
                                                checked />
                                            <span><?php echo htmlspecialchars($inspectionType); ?></span>
                                        </label>
                                    </li>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                <?php endforeach; ?>
            </span>
        </div>
    </li>
<?php endforeach; ?>




            </ul>
            <!-- <button type="submit">Update Vessel Equipment</button> -->
            <input type="hidden" name="vessel_id" value="<?php echo htmlspecialchars($vessel_id); ?>">
            <button type="submit" class="btn-small waves-effect waves-light"><i class="material-icons left">update</i>Update Vessel Equipment</button>
            <a href="vessel_maintenance.php?id=<?php echo htmlspecialchars($vessel_id); ?>" class="btn-small waves-effect waves-light"><i class="material-icons left">arrow_back</i>Back to Vessel Details</a>
        </form>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);

            var elems = document.querySelectorAll('.collapsible');
            var instances = M.Collapsible.init(elems);
        });

        
        </script>
</body>

</html>
