<?php
include "db_connect.php";

if(isset($_POST['update_task'])) {
    $vessel_id = filter_input(INPUT_POST, 'vessel_id', FILTER_SANITIZE_NUMBER_INT);
    $equipment_id = filter_input(INPUT_POST, 'equipment_id', FILTER_SANITIZE_NUMBER_INT);
    $task_id = filter_input(INPUT_POST, 'task_id', FILTER_SANITIZE_NUMBER_INT);
    $remarks = filter_input(INPUT_POST, 'remarks', FILTER_SANITIZE_STRING);

    // Check if all inputs are provided
    if ($vessel_id && $equipment_id && $task_id && $remarks !== false) {
        // First get the threshold_hour for the task
        $thresholdQuery = $conn->prepare("SELECT threshold_hour FROM tasks WHERE task_id = ?");
        $thresholdQuery->bind_param("i", $task_id);
        $thresholdQuery->execute();
        $thresholdResult = $thresholdQuery->get_result();
        $thresholdRow = $thresholdResult->fetch_assoc();
        $thresholdQuery->close();

        if($thresholdRow) {
            $threshold_hour = $thresholdRow['threshold_hour'];

            // Prepare the update statement to reset running hours and set the remaining_hours to threshold_hour
            $updateStmt = $conn->prepare("UPDATE vessel_rh_equipment SET total_running_hours = 0, remaining_hours = ?, remarks = ?, status = 'Completed' WHERE vessel_id = ? AND equipment_id = ? AND task_id = ?");
            $updateStmt->bind_param("isiii", $threshold_hour, $remarks, $vessel_id, $equipment_id, $task_id);

            if($updateStmt->execute()) {
                // Redirect back to the status page with a success message
                header("Location: status_page.php?id=$vessel_id&success=Task completed successfully");
            } else {
                // Handle error properly
                $error = $conn->error;
                header("Location: status_page.php?id=$vessel_id&error=Unable to complete task - $error");
            }
            $updateStmt->close();
        } else {
            header("Location: status_page.php?id=$vessel_id&error=Unable to find threshold hours for task");
        }
    } else {
        // Handle the error when input is not valid
        header("Location: status_page.php?id=$vessel_id&error=Invalid input");
    }
    exit;
}
?>
