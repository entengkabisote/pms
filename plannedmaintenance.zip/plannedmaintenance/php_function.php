<?php
function isSuperuser($user_id) {
    global $conn; // Dito ginagamit natin ang $conn na nasa global scope

    // Prepare the query using $conn
    $stmt = $conn->prepare("SELECT role_name FROM roles INNER JOIN user_roles ON roles.role_id = user_roles.role_id WHERE user_roles.user_id = ?");
    $stmt->bind_param("i", $user_id); // "i" means we're binding an integer
    $stmt->execute();
    $result = $stmt->get_result();
    $role = $result->fetch_assoc();

    return $role && $role['role_name'] == 'superuser';
}

function isAdminOrSuperuser($user_id, $conn) {
    $query = "SELECT role FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    return in_array($user['role'], ['admin', 'superuser']);
}


?>