<?php

session_start();

include "db_connect.php";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $equipment_id = $_POST['equipment_id'];
    $task_description = $_POST['task_description'];
    $threshold_hour = $_POST['threshold_hour'];
    $subequipment = !empty($_POST['subequipment']) ? $_POST['subequipment'] : NULL;

    $equipQuery = "SELECT equipment_type FROM rh_equipments WHERE equipment_id = ?";
    $equipStmt = $conn->prepare($equipQuery);
    $equipStmt->bind_param("i", $equipment_id);
    $equipStmt->execute();
    $equipResult = $equipStmt->get_result();
    $row = $equipResult->fetch_assoc();
    $equipment_type = $row['equipment_type'];

    if (!empty($subequipment)) {
        $checkQuery = "SELECT * FROM tasks WHERE equipment_id = ? AND task_description = ? AND threshold_hour = ? AND subequipment = ?";
        $checkStmt = $conn->prepare($checkQuery);
        $checkStmt->bind_param("isis", $equipment_id, $task_description, $threshold_hour, $subequipment);
    } else {
        $checkQuery = "SELECT * FROM tasks WHERE equipment_id = ? AND task_description = ? AND threshold_hour = ? AND subequipment IS NULL";
        $checkStmt = $conn->prepare($checkQuery);
    
            if ($checkStmt === false) {
                die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
            }

        $checkStmt->bind_param("isi", $equipment_id, $task_description, $threshold_hour);
    }
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();
    
    if ($checkResult->num_rows > 0) {
        $_SESSION['task_exists'] = true;
        header("Location: rh_tasks.php");
        exit;
    }
    
    

    $insertQuery = "INSERT INTO tasks (equipment_id, task_description, threshold_hour, equipment_type, subequipment) VALUES (?, ?, ?, ?, ?)";
    $insertStmt = $conn->prepare($insertQuery);
    $insertStmt->bind_param("isiss", $equipment_id, $task_description, $threshold_hour, $equipment_type, $subequipment);
    $insertStmt->execute();
    $insertStmt->close();
    
    
    

    // $stmt->close();

    // Set a session variable for success
    $_SESSION['task_added'] = true;

    // Redirect back to the form page
    header("Location: rh_tasks.php?equipment_id=" . $_SESSION['last_equipment_id']);
    exit;
}

?>
