<?php
// Database connection
include "db_connect.php";

// Fetch unique vessel IDs from vessel_rh_equipment table
$query = "SELECT DISTINCT vessel_id FROM vessel_rh_equipment";
$result = mysqli_query($conn, $query);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/general.css">
</head>

<body>
<?php include 'header.php'; ?>
<h5 class="center-content">Vessels with Linked Equipment and Tasks</h5>
    <main class="index-container">
        <div class="grid-x grid-padding-x center-content">
            <div class="medium-6 cell medium-offset-3">
                
            
                <div class="vessel-list-box">
                    <ul class="menu vertical no-bullet">
                        <?php while($row = mysqli_fetch_assoc($result)): ?>
                        <?php
                        // Fetch vessel name using the vessel_id
                        $vessel_id = $row['vessel_id'];
                        $vessel_query = "SELECT vessel_name FROM vessels WHERE id = $vessel_id";
                        $vessel_result = mysqli_query($conn, $vessel_query);
                        $vessel_row = mysqli_fetch_assoc($vessel_result);
                        ?>
                        <li>
                            <a href="view_vessel_rh_details.php?vessel_id=<?php echo $vessel_id; ?>" class="clickable-vessel">
                            <?php echo $vessel_row['vessel_name']; ?>
                            </a>
                        </li>
                        <?php endwhile; ?>
                    </ul>
                </div>

            </div>
        </div>   
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

        
        </script>
</body>

</html>
