<?php
include 'db_connect.php';

$equipment_name = isset($_GET['equipment_name']) ? $_GET['equipment_name'] : null;

if ($equipment_name) {
    $sql = "SELECT DISTINCT tasks.threshold_hour
            FROM vessel_rh_equipment
            JOIN rh_equipments ON vessel_rh_equipment.equipment_id = rh_equipments.equipment_id
            JOIN tasks ON vessel_rh_equipment.task_id = tasks.task_id
            WHERE rh_equipments.equipment_name = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $equipment_name);

    $stmt->execute();
    $result = $stmt->get_result();
    $thresholds = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $thresholds[] = $row['threshold_hour'];
        }
    }

    echo json_encode($thresholds);

    $stmt->close();
}
?>
