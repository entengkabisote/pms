$("#addEquipmentForm").submit(function(e){
    e.preventDefault();
    $.ajax({
      url: "add_equipment.php",
      type: "POST",
      data: {
        equipmentName: $('#equipmentName').val(),
        equipmentCategory: $('#equipmentCategory').val()
      },
      success: function(data) {
        var parsedData = JSON.parse(data);
        if (parsedData.status === 'success') {
          var catId = $('#equipmentCategory').val();
          var catName = categoryMap[catId];
          var newRow = "<tr><td>" + $('#equipmentName').val() + "</td><td>" + catName + "</td><td>Action</td></tr>";
          $("#equipmentList").append(newRow);
          loadExistingData();  // Refresh the entire table including the counter
        } else if (parsedData.status === 'duplicate') {
            alert("Duplicate equipment name.");
          } else {
            alert("Failed to add equipment.");
          }
      },
      complete: function() {
        // Clear the input fields
        $('#equipmentName').val('');
        $('#equipmentCategory').val("");
        $('#equipmentCategory').formSelect(); // Re-initialize the Materialize select
      }
    });
  });

  function loadExistingData() {
    $.ajax({
      url: "get_equipment.php",
      type: "GET",
      success: function(data) {
        var parsedData = JSON.parse(data);

        // Sort by category
        parsedData.sort((a, b) => a.category.localeCompare(b.category));
        
        // Clear existing rows
        $("#equipmentList").empty();

        // Initialize counter for numbering
        let counter = 1;

        console.log(parsedData);

        parsedData.forEach(function(row) {
            console.log('Equipment ID:', row.equipment_id); // I-console log ang equipment ID
            var newRow = `<tr data-equipment-id="${row.equipment_id}">
                            <td>${counter}. ${row.equipment_name}</td>
                            <td>${row.category}</td>
                            <td>
                            <button class="waves-effect waves-light blue darken-2 btn-small edit-btn">
                            <i class="material-icons">edit</i>
                        </button>
                        <button class="waves-effect waves-light red btn-small delete-btn">
                            <i class="material-icons">delete</i>
                        </button>
                            </td>
                        </tr>`;
            $("#equipmentList").append(newRow);
            counter++; // Increment the counter
          });
      }
    });
  }

  var categoryMap = {};

  $(document).ready(function() {
    $('#equipmentCategory option').each(function() {
      var id = $(this).val();
      var name = $(this).data('type-name');
      categoryMap[id] = name;
    });
  
    loadExistingData();
  });


  // ******************************************************************** //
  //                Add event listeners for Edit buttons
  // ******************************************************************** //
    
    $(document).on('click', '.edit-btn', function() {
      var equipmentId = $(this).closest('tr').data('equipment-id');
      window.location.href = `edit_equipment.php?id=${equipmentId}`;
    });

  // ******************************************************************** //
  //              Add event listeners for Delete buttons
  // ******************************************************************** //

  $(document).on('click', '.delete-btn', function() {
    var equipmentId = $(this).closest('tr').data('equipment-id');

    if(confirm('Are you sure you want to delete this equipment?')) {
        $.ajax({
            url: 'delete_equipment.php',
            type: 'POST',
            data: { id: equipmentId },
            success: function(data) {
                var response = JSON.parse(data);

                if(response.status === 'success') {
                    alert('Equipment deleted successfully.');
                    // Optional: Reload the table or remove the row from the DOM
                    loadExistingData();
                } else {
                    alert(response.message);
                }
            },
            error: function(err) {
                console.error("Error:", err);
                alert('An error occurred. Please try again.');
            }
        });
    }
});
