        function fetchInspectionTypes(equipmentId) {
            console.log("Fetching for equipment ID:", equipmentId);
            $.ajax({
                url: 'get_inspection_types.php',
                method: 'POST',
                data: {
                    equipmentId: equipmentId
                },
                success: function(response) {
                    console.log(response)
                    const data = JSON.parse(response);
                    if (data.status === 'success') {
                        displayInspectionTypes(data.data);
                    } else {
                        console.error('Error fetching inspection types:', data.message);
                    }
                }
            });
        }

        function displayInspectionTypes(inspectionTypes) {
            
            const tableBody = $('#inspectionMetaContainer2 table tbody');

            tableBody.empty();

            inspectionTypes.forEach(type => {
                console.log('Adding row with meta_id:', type.meta_id);
                const row = `
                <tr data-meta-id="${type.meta_id}">
                        <td>${type.inspection_type}</td>
                        <td>${type.inspection_interval}</td>
                        <td>${type.person_in_charge}</td>
                        <td>${type.criticality}</td>
                        <td>
                            <button type="button" class="btn waves-effect waves-light blue btn-edit">Edit</button>
                            <button type="button" class="btn waves-effect waves-light red btn-delete">Delete</button>
                        </td>
                    </tr>
                `;
                tableBody.append(row);
                attachEventListeners();
            });
        }


        document.addEventListener('DOMContentLoaded', function() {
        var elems = document.querySelectorAll('select');
        var instances = M.FormSelect.init(elems);
        });


        $("#editEquipmentForm").submit(function(e) {
            e.preventDefault();
        
            var equipmentId = $("#equipmentId").val();
            var equipmentName = $("#equipmentName").val();
            var category = $("#category").val();  // get  category value
        
            var inspectionMeta = [];
            $(".inspectionMeta").each(function() {
                var type = $(this).find(".inspectionType").val();
                // Add other fields like inspection_interval, person_in_charge, etc.
                
                inspectionMeta.push({type: type});
            });
        
            console.log("equipmentId before sending AJAX request: " + equipmentId);
        
            $.ajax({
                url: "update_equipment_and_meta.php",
                type: "POST",
                data: {
                    equipment_id: equipmentId,
                    equipment_name: equipmentName,
                    category: category, // Idagdag sa AJAX data
                    inspection_meta: JSON.stringify(inspectionMeta)
                },
                success: function(response) {
                    alert("Successfully updated!");
                },
                error: function() {
                    alert("Update failed.");
                }
            });
        });
        

        $(document).ready(function() {
            attachEventListeners();

            $("#addRow").click(function() {
                var originalRow = $(".inspectionRow:first");
            
                var newRow = originalRow.clone();
            
                // Clean up the cloned row
                newRow.find("input").val("");
                newRow.find("select").val('');  // Clear the value of the cloned select
                newRow.find(".removeRow").show();
            
                // Remove Materialize elements from the clone
                newRow.find('select').siblings('ul').remove();
                newRow.find('select').siblings('input').remove();
            
                // Append the cleaned row
                $("#inspectionMetaContainer").append(newRow);
            
                // Reinitialize both selects
                M.FormSelect.init(originalRow.find('select'));
                M.FormSelect.init(newRow.find('select'));
            });
            
 
            $(document).on("click", ".removeRow", function() {
                if ($(".inspectionRow").length > 1) {
                    $(this).closest(".inspectionRow").remove();
                }
            });

            $("#saveInspection").click(function() {
                console.log("Save Inspection button clicked.");

                let inspectionData = [];
                let uniqueTypes = new Set();
                let hasDuplicate = false;

                $(".inspectionRow").each(function() {
                    let type = $.trim($(this).find("input[name='inspection_type[]']").val());
                    // let interval = $(this).find("input[name='inspection_interval[]']").val();
                    let interval = $(this).find("select[name='inspection_interval[]']").val();

                    let person = $(this).find("input[name='person_in_charge[]']").val();
                    let criticality = $(this).find("input[name='criticality[]']").val();

                    // I-validate ang mga field bago isama sa inspectionData
                    if (type !== "") {
                        inspectionData.push({type: type, interval, person, criticality});
                    }
                    console.log("Current Type: " + type);

                    if (uniqueTypes.has(type)) {
                        console.log("Has Duplicate: true");
                        alert("Duplicate type of inspection: " + type);
                        hasDuplicate = true;
                        return false;
                    } else {
                        uniqueTypes.add(type);
                    }

                });

                let equipmentId = $("#equipmentId").val();
                console.log(equipmentId)

                // Verify ang Equipment ID
                if (!equipmentId || isNaN(equipmentId)) {
                    alert("Invalid equipment ID.");
                    return; // Hindi itutuloy ang AJAX request kung hindi valid ang Equipment ID
                }

                if (inspectionData.length === 0) {
                    alert("No valid inspection data provided.");
                    return;
                }
                if (!hasDuplicate) {
                    $.ajax({
                        url: "save_inspection_meta.php",
                        type: "POST",
                        data: {
                            equipmentId: equipmentId, // Dito ay tama na ang pangalan ng field
                            inspection_data: JSON.stringify(inspectionData)
                        },
                        success: function(response) {
                            const parsedResponse = JSON.parse(response);
                            
                            // Ito yung idadagdag mo:
                            console.log("Parsed Response:", parsedResponse);
                        
                            if (parsedResponse.status === 'success') {
                                alert("Inspection data successfully saved!");
                        
                                // Update the inspection types table with the returned data
                                displayInspectionTypes(parsedResponse.data);                               
                            } else if (parsedResponse.status === 'duplicate') {
                                alert("Duplicate inspection types detected.");
                            } else {
                                alert("Failed to save inspection data.");
                            }
                            // Clear the input fields
                            $(".inspectionRow input[type='text']").val('');

                            // Clear select values and re-initialize
                            $(".inspectionRow select").val(null).formSelect(); 
                            // newRow.attr('data-meta-id', response.meta_id);

                        },
                        error: function(xhr, status, error) {
                            console.log("AJAX Error:", status, error);
                            alert("Failed to save inspection data.");
                        }
                    });
                }
            });
        });

        function attachEventListeners() {
            // Detach first so the events don't stack
            $(document).off('click', '.btn-edit');
            $(document).off('click', '.btn-delete');

            $(document).on('click', '.btn-edit', function() {
                // get current row
                var row = $(this).closest('tr');
                
                // get the meta_id from the current row
                var metaId = row.data('meta-id');
                
                // get the equipment_id from the hidden input in the form
                var equipmentId = $('#equipmentId').val();
            
                // redirect to the edit_inspection_type.php with meta_id and equipment_id
                window.location.href = 'edit_inspection_type.php?meta_id=' + metaId + '&equipment_id=' + equipmentId;
            });
            
            
            // Attach again
            // $(document).on('click', '.btn-edit', function() {
            //   // get current row
            //     var row = $(this).closest('tr');
                
            //     // get data from the current row
            //     var metaId = row.data('meta-id');
            //     var inspectionType = row.find('.inspectionType').val();
            //     // var inspectionInterval = row.find('.inspectionInterval').val();
            //     var selectedInterval = row.find('.inspectionInterval').val();
            //     var personInCharge = row.find('.personInCharge').val();
            //     var criticality = row.find('.criticality').val();

            //     // Enter the data in the modal form fields
            //     $('#modalMetaId').val(metaId);
            //     $('#modalInspectionType').val(inspectionType);
            //     // $('#modalInspectionInterval').val(inspectionInterval);
            //     $("#modalInspectionInterval option").each(function() {
            //         if($(this).val() == selectedInterval) {
            //             $(this).prop("selected", true);
            //         }
            //     });
            //     $('select').formSelect();  // Reinitialize Materialize select
            //     $('#modalPersonInCharge').val(personInCharge);
            //     $('#modalCriticality').val(criticality);
                
            //     // Update labels in modal for the materialize css
            //     if(inspectionType) $('#modalInspectionType').siblings('label').addClass('active');
            //     // if(inspectionInterval) $('#modalInspectionInterval').siblings('label').addClass('active');
            //     if(selectedInterval) $('#modalInspectionInterval').siblings('label').addClass('active');

            //     if(personInCharge) $('#modalPersonInCharge').siblings('label').addClass('active');
            //     if(criticality) $('#modalCriticality').siblings('label').addClass('active');
                
            //     // open the modal
            //     var modalInstance = M.Modal.getInstance($('#editModal'));
            //     modalInstance.open();

            // });
            
            $(document).on('click', '.btn-delete', function() {
                console.log("Delete button clicked");
                var row = $(this).closest('tr');
                var metaId = row.data('meta-id');
                console.log('Meta ID:', metaId);  // Add this line
    
                // Confirm deletion
                if (confirm("Are you sure you want to delete this record?")) {
                    // Your AJAX call for deletion here
                    $.ajax({
                        url: "delete_meta.php", // Replace it with your actual delete URL
                        type: "POST",
                        data: { meta_id: metaId },
                        dataType: "json",
                        success: function(response) {
                            if(response.status === "success") {
                                alert(response.message);
                                row.remove(); // Remove row from UI
                            } else {
                                alert("Error: " + response.message);
                            }
                        },
                        error: function() {
                            alert("Something went wrong with the request.");
                        }
                    });
                }
            });
          }
          