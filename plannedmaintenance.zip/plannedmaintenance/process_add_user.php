<?php
session_start();
include 'db_connect.php';
// require_once 'C:\wamp64\secure_config\config.php'; // Include the config file to use SMTP credentials
// require_once 'C:\wamp64\www\plannedmaintenance\vendor\phpmailer\phpmailer\src\Exception.php';
// require_once 'C:\wamp64\www\plannedmaintenance\vendor\phpmailer\phpmailer\src\PHPMailer.php';
// require_once 'C:\wamp64\www\plannedmaintenance\vendor\phpmailer\phpmailer\src\SMTP.php';

require_once '/home/smscorp/secure_config/config.php';
require_once '/home/smscorp/public_html/plannedmaintenance/vendor/phpmailer/phpmailer/src/Exception.php';
require_once '/home/smscorp/public_html/plannedmaintenance/vendor/phpmailer/phpmailer/src/PHPMailer.php';
require_once '/home/smscorp/public_html/plannedmaintenance/vendor/phpmailer/phpmailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize user input para maiwasan ang SQL Injection
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $role = mysqli_real_escape_string($conn, $_POST['role']);
    // (int)$_POST['role'];

    // Token generation
    $token = bin2hex(random_bytes(50));

    // This is the verification link
    $verification_link = "http://localhost/plannedmaintenance/verify_email.php?token=$token";
 

    // Insert the user to database without password
    $query = "INSERT INTO users (username, email, role, is_verified, verification_token) VALUES (?, ?, ?, 0, ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 'ssss', $username, $email, $role, $token);
    mysqli_stmt_execute($stmt);

    if (mysqli_stmt_affected_rows($stmt) == 1) {
        // Instantiate PHPMailer object
        $mail = new PHPMailer(true);

        try {
            //Server settings
            // $mail->SMTPDebug = 2;
            $mail->isSMTP();
            $mail->Host       = SMTP_HOST; // Use constants from config.php
            $mail->SMTPAuth   = true;
            $mail->Username   = SMTP_USER; // SMTP username from config.php
            $mail->Password   = SMTP_PASS; // SMTP password from config.php
            $mail->SMTPSecure = SMTP_SEC; // Encryption from config.php
            $mail->Port       = SMTP_PORT; // Port from config.php

            //Recipients
            $mail->setFrom(SMTP_USER, 'Mailer');
            $mail->addAddress($email, $username); // Add a recipient, using variables from form

            // Content
            $mail->isHTML(true); // Set email format to HTML
            $mail->Subject = 'Email Verification';
            $mail->Body    = 'Please click this link to verify your email: <a href="' . $verification_link . '">Verify Email</a>';
            $mail->AltBody = 'Please click on this link to verify your email: ' . $verification_link;

            $mail->send();
            // Set a session variable to display a success message on the next page
            $_SESSION['success_message'] = 'Verification email has been sent.';

            // Redirect to the user management page or add user page
            header('Location: user_management.php');
            exit(); // Make sure to call exit after a redirect to stop script execution
        } catch (Exception $e) {
            // ... Handle error, email sending failed
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        // ... Handle error, user not inserted
    }
}
?>
