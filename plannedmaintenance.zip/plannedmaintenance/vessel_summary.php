<?php
session_start();
include "db_connect.php";

if(isset($_GET['id'])) {
    $vessel_id = $_GET['id'];
} else {
    // Handle the case where the ID isn't set (redirect or show an error)
    die("Vessel ID is not provided.");
}



$current_year = date("Y");
$start_year = $current_year - 5;
$end_year = $current_year + 0;

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/vessel_summary_style.css">
</head>

<body>
<?php include 'header.php'; ?>
<h5>Select Month and Year</h5>
    <main class="vessel-summary-container">
        <div>
            

            <form action="vessel_rh_summary.php" method="post">
            <input type="hidden" name="vessel_id" value="<?php echo $vessel_id; ?>">

                <label for="month">Month:</label>
                <select name="month" required>
                    <option value="" disabled selected>Choose your month</option>
                    <option value="1">January</option>
                    <option value="2">February</option>
                    <option value="3">March</option>
                    <option value="4">April</option>
                    <option value="5">May</option>
                    <option value="6">June</option>
                    <option value="7">July</option>
                    <option value="8">August</option>
                    <option value="9">September</option>
                    <option value="10">October</option>
                    <option value="11">November</option>
                    <option value="12">December</option>
                </select>

                <label for="year">Year:</label>
                <select name="year" required>
                    <option value="" disabled selected>Choose your year</option>
                    <?php for ($year = $start_year; $year <= $end_year; $year++): ?>
                        <option value="<?php echo $year; ?>"><?php echo $year; ?></option>
                    <?php endfor; ?>
                </select>
                <div class="backButton">
                    <input type="submit" value="Show Summary" class="btn-small waves-effect waves-light blue">
    
                    <a class="btn-small waves-effect waves-light" href="vessel_maintenance.php?id=<?php echo $vessel_id; ?>"> <i class="material-icons left">arrow_back</i>Back</a>
                </div>
            </form>
        </div>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);

            var selectElems = document.querySelectorAll('select');
            M.FormSelect.init(selectElems);
        });

        
        </script>
</body>

</html>
