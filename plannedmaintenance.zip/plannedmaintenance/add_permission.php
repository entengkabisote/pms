<?php
session_start();

// Include your db_connect.php
include 'db_connect.php';

// Check if the one accessing is an admin
if ($_SESSION['role'] !== 'admin') {
    die('Unauthorized access.');
}

// First, clear existing permissions for the selected user
$query = "DELETE FROM user_permissions WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $_POST['user_id']);
$stmt->execute();

// Now, add the new permissions for the user
foreach ($_POST['permissions'] as $permission_id) {
    $query = "INSERT INTO user_permissions (user_id, permission_id) VALUES (?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $_POST['user_id'], $permission_id);
    $stmt->execute();
}

// Redirect back with a success message
header('Location: users.php?success=1');
exit;
?>
