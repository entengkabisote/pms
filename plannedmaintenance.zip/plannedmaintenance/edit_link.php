<?php
include "db_connect.php";

$vessel_id = $_GET['vessel_id'];

$equipment_sets = [
    'Propulsion1' => [1, 2, 3],
    'Propulsion2' => [5, 6, 7],
    'Auxiliary1' => [4],
    'auxiliary2' => [8]
];


// Fetch equipment that are already linked
$sql = "SELECT equipment_id FROM vessel_rh_equipment WHERE vessel_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $vessel_id);
$stmt->execute();
$result = $stmt->get_result();
$linkedEquipment = [];
while ($row = $result->fetch_assoc()) {
    $linkedEquipment[] = $row['equipment_id'];
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $selectedEquipmentSets = $_POST['equipment_sets'] ?? [];

    $equipment_ids = [];
    foreach ($selectedEquipmentSets as $set) {
        if (isset($equipment_sets[$set])) {
            $equipment_ids = array_merge($equipment_ids, $equipment_sets[$set]);
        }
    }

    $equipment_ids_to_remove = array_diff($linkedEquipment, $equipment_ids);
    $equipment_ids_to_add = array_diff($equipment_ids, $linkedEquipment);

    // Process Removal
    foreach ($equipment_ids_to_remove as $id_to_remove) {
        $sql = "DELETE FROM vessel_rh_equipment WHERE vessel_id = ? AND equipment_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $vessel_id, $id_to_remove);
        $stmt->execute();
    }

    // Process Addition
    $sql = "INSERT INTO vessel_rh_equipment (vessel_id, equipment_id, task_id, date_added, total_running_hours, date_modified, status, remarks, threshold_hour) VALUES (?, ?, ?, CURDATE(), ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    foreach ($equipment_ids_to_add as $equipment_id) {
        // Fetch all task_ids and threshold_hour for this equipment
        $taskQuery = "SELECT task_id, threshold_hour FROM tasks WHERE equipment_id = ?";
        $taskStmt = $conn->prepare($taskQuery);
        $taskStmt->bind_param("i", $equipment_id);
        $taskStmt->execute();
        $taskResult = $taskStmt->get_result();

        $total_running_hours = 0;
        $date_modified = date("Y-m-d H:i:s");
        $status = "pending";
        $remarks = "Updated Link";

        while ($taskRow = $taskResult->fetch_assoc()) {
            $task_id = $taskRow['task_id'];
            $threshold_hour = $taskRow['threshold_hour'];
            $stmt->bind_param("iiiiissi", $vessel_id, $equipment_id, $task_id, $total_running_hours, $date_modified, $status, $remarks, $threshold_hour);
            $stmt->execute();
        }
    }
    $stmt->close();

    // Set a session variable for success
    $_SESSION['edit_link'] = true;

    // Redirect back to the form page
    header("Location: vessel_link_to_equipment.php?vessel_id=" . $vessel_id);
    exit;
}

// Fetch all available equipment
$sql = "SELECT * FROM rh_equipments";
$result = $conn->query($sql);
$allEquipment = $result->fetch_all(MYSQLI_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/general.css">
</head>

<body>
<?php include 'header.php'; ?>
        
    <main class="index-container">
        <form action="edit_link.php?vessel_id=<?php echo $vessel_id; ?>" method="post" class="col s6 offset-s3">
            <div class="card">
                <div class="card-content">
                    <span class="card-title">Select Equipment Set:</span>
                    <div class="checkbox-group">
                        <?php
                        foreach ($equipment_sets as $set => $ids) {
                            $isLinked = count(array_intersect($ids, $linkedEquipment)) == count($ids);
                            $setName = ucfirst($set) . " Set";
                            echo "<label><input id='{$set}' type='checkbox' name='equipment_sets[]' value='{$set}' " . ($isLinked ? 'checked' : '') . "><span>{$setName}</span></label><br>";
                        }
                        ?>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn-small waves-effect waves-light">
                <i class="material-icons left">update</i> Update
            </button>
            <!-- This is the new Cancel button -->
            <button type="button" class="btn-small waves-effect waves-light red lighten-1" onclick="window.location.href='vessel_link_to_equipment.php?vessel_id=<?php echo $vessel_id; ?>'">
                <i class="material-icons left">cancel</i> Cancel
            </button>

        </form>


    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

        
        </script>
</body>

</html>
