<?php
session_start();


include "db_connect.php";

if (isset($_GET['equipment_id'])) {
    $_SESSION['last_equipment_id'] = $_GET['equipment_id'];
}


$equipment_id = isset($_GET['equipment_id']) ? $_GET['equipment_id'] : 0;

$tasks = [];

// Fetch tasks from the database
$query_tasks = "SELECT rh_equipments.equipment_id, rh_equipments.equipment_name, tasks.task_description, tasks.threshold_hour, tasks.task_id FROM tasks INNER JOIN rh_equipments ON tasks.equipment_id = rh_equipments.equipment_id";

$result_tasks = $conn->query($query_tasks);
if ($result_tasks->num_rows > 0) {
    while($row_task = $result_tasks->fetch_assoc()) {
        $tasks[] = $row_task;
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/rh_tasks_style.css">
</head>

<body>
<?php include 'header.php'; ?>
    <div>
        <h5>Add New Task</h5>
    </div>
    <main class="rh-tasks-container">
        <div class="row">
            <div class="col s12 m6 offset-m3">
                <form action="add_task.php" method="POST">
                    
                    <input type="hidden" name="equipment_id" value="<?php echo $equipment_id; ?>">
                    <!-- <div class="input-field">
                        <select name="equipment_id">
                            <option value="" disabled selected>Select Equipment...</option>
                            <?php foreach ($equipments as $equipment): ?>
                                <option value="<?php echo $equipment['equipment_id']; ?>"><?php echo $equipment['equipment_name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                        <label>Equipment</label>
                    </div> -->
                    

                    <div class="input-field">
                        <input type="text" name="task_description" required>
                        <label for="task_description">Task Description</label>
                    </div>

                    <div class="input-field">
                        <input type="number" name="threshold_hour" required>
                        <label for="threshold_hour">Threshold Hour</label>
                    </div>

                    <div class="input-field">
                        <input type="text" name="subequipment">
                        <label for="subequipment">Sub Equipment</label>
                    </div>

                    <button type="submit" class="btn-small waves-effect waves-light ">Add Task</button>
                    <button type="button" class="btn-small waves-effect waves-light " onclick="location.href='equipment_running_hours.php'"> Back </button>
                </form>
            </div>
            <!-- <div class="medium-12 cell"> -->
            <div class="col s12">
                <div class="medium-12 cellrh custom-width">
                    <h5>Existing Tasks</h5>
                    <?php if(isset($_GET['success'])): ?>
                        <div class="callout success">
                            Task added successfully!
                        </div>
                    <?php endif; ?>
                    <?php if(isset($_GET['error'])): ?>
                        <div class="callout alert">
                            Error adding task!
                        </div>
                    <?php endif; ?>
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 13%;">Equipment Name</th>
                                <th style="width: 60%;">Task Description</th>
                                <th style="width: 9%;">Threshold Hour</th>
                                <th style="width: 18%; text-align: center;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($tasks as $task): ?>
                                <tr>
                                    <td><?php echo $task['equipment_name']; ?></td>
                                    <td><?php echo $task['task_description']; ?></td>
                                    <td style="text-align:center"><?php echo $task['threshold_hour']; ?></td>
                                    <td class="action-buttons" style="text-align: center;">
                                        <a href="edit_task.php?id=<?php echo $task['task_id']; ?>&equipment_id=<?php echo $task['equipment_id']; ?>" class="btn-small waves-effect waves-light blue darken-2">
                                            <i class="material-icons left">edit</i>
                                        </a>
                                        <a href="delete_task.php?id=<?php echo $task['task_id']; ?>" class="btn-small waves-effect waves-light red" onclick="return confirm('Are you sure you want to delete this?');">
                                            <i class="material-icons left">delete</i>
                                        </a>
                                        <a href="spareparts.php?id=<?php echo $task['task_id']; ?>&equipment_id=<?php echo $task['equipment_id']; ?>" class="btn-small waves-effect waves-light blue-grey ">
                                            <i class="material-icons left">build</i>
                                        </a>
                                        
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>

        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);

            var elems = document.querySelectorAll('select');
            var instances = M.FormSelect.init(elems);
            
            // Check kung ang task_exists session variable ay set
            <?php if(isset($_SESSION['task_exists']) && $_SESSION['task_exists']): ?>
                M.toast({html: 'Task description already exist!', classes: 'rounded red lighten-2', displayLength: 2000});
                <?php unset($_SESSION['task_exists']); // Wag kalimutang i-unset ang session variable pagkatapos gamitin ?>
            <?php endif; ?>

            <?php if(isset($_SESSION['task_added']) && $_SESSION['task_added']): ?>
                M.toast({html: 'Task added successfully!', classes: 'rounded red lighten-2', displayLength: 2000});
                <?php unset($_SESSION['task_added']); // Wag kalimutang i-unset ang session variable pagkatapos gamitin ?>
            <?php endif; ?>
        });

        </script>
</body>

</html>
