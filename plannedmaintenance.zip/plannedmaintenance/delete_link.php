<?php
include "db_connect.php";

if (isset($_GET['vessel_id'])) {
    $vessel_id = $_GET['vessel_id'];

    $query = "DELETE FROM vessel_rh_equipment WHERE vessel_id = $vessel_id";
    if ($conn->query($query) === TRUE) {
        // Successfully deleted records, redirect to vessel_link_to_equipment.php
        header("Location: vessel_link_to_equipment.php?vessel_id=$vessel_id");

        exit; // Make sure to exit after redirecting
    } else {
        // If there's an error, you can display it (but this will prevent the redirection)
        echo "Error deleting records: " . $conn->error;
    }
}
?>
