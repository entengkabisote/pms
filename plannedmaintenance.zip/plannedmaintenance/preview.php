<?php
include 'db_connect.php';
include 'fetch_data.php';

$vessel_id = $_GET['vessel_id'];
$equipment_name = $_GET['equipment_name'];
$threshold_hour = $_GET['threshold_hour'];
$selected_month = $_GET['selected_month'];
$monthName = date('F', mktime(0, 0, 0, $selected_month, 10));
$daysInMonth = cal_days_in_month(CAL_GREGORIAN, $selected_month, date("Y"));


$tableData = fetchTableData($vessel_id, $equipment_name, $threshold_hour);
$vessel_name = getVesselName($vessel_id);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/preview_style.css">
</head>

<body>
<?php include 'header.php'; ?>

    <main class="preview-container">
        <table border="1">
            <tr>
                <td class="no-border" colspan="<?php echo $daysInMonth + 8; ?>">
                    Vessel : <?php echo $vessel_name; ?><br>
                    Month : <?php echo $monthName; ?><br>
                    Machinery : <?php echo $equipment_name; ?><br>
                    Threshold Hour : <?php echo $threshold_hour; ?>
                </td>
            </tr>
            <tr>
                <td colspan="5">TASK</td>
                <?php
                for ($i = 1; $i <= $daysInMonth; $i++) {
                    echo '<td class="day-column">' . $i . '</td>';
                }
                ?>
                <td class="rh-column">End of the Month Total RH</td>
                <td class="rh-column">Overall Total RH</td>
                <td class="rh-column">Remarks</td>
            </tr>

            
            <?php
            // Assuming $tableData contains your tasks
            foreach ($tableData as $task) {
                echo '<tr>';
                echo '<td colspan="5">' . $task['task_description'] . '</td>';
                // Insert your day data dynamically here
                for ($i = 1; $i <= $daysInMonth; $i++) {
                    echo '<td></td>';
                }
                echo '<td></td>';
                echo '<td></td>';
                echo '<td></td>';
                echo '</tr>';
            }
            ?>
        </table>

        <div class=print-button >
            <a href="print_rh.php?id=<?php echo $vessel_id; ?>" class="btn-small waves-effect waves-light button"><i class="material-icons left">arrow_back</i>Back to Vessel Details</a>
            <button class="btn-small waves-effect waves-light button" onclick="window.print()">Print</button>
        </div>    
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

        
        </script>
</body>

</html>
