<?php
session_start();
include 'db_connect.php';

$message = "";

if (isset($_GET['subequipment_id'])) {
    $subequipment_id = $_GET['subequipment_id'];

    $stmt = $conn->prepare("SELECT * FROM rh_subequipments WHERE subequipment_id = ?");
    $stmt->bind_param("i", $subequipment_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $subequipment = $result->fetch_assoc();
    } else {
        exit('Subequipment not found');
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_GET['subequipment_id']) && isset($_POST['subequipment_name'])) {
        $subequipment_id = $_GET['subequipment_id'];
        $new_name = $_POST['subequipment_name'];

        // Check if subequipment name already exists
        $check_stmt = $conn->prepare("SELECT * FROM rh_subequipments WHERE subequipment_name = ? AND subequipment_id != ?");
        $check_stmt->bind_param("si", $new_name, $subequipment_id);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();

        if ($check_result->num_rows > 0) {
            // Subequipment name already exists
            $message = "Subequipment name already exists.";
            $check_stmt->close();
        } else {
            $stmt = $conn->prepare("UPDATE rh_subequipments SET subequipment_name = ? WHERE subequipment_id = ?");
            $stmt->bind_param("si", $new_name, $subequipment_id);

            if ($stmt->execute()) {
                header("Location: edit_subequipment.php?subequipment_id=" . $subequipment_id);
                exit;
            } else {
                echo "Error: " . $stmt->error;
            }
        }
    }
}


$stmt = $conn->prepare("SELECT main_equipment_id FROM rh_subequipments WHERE subequipment_id = ?");
$stmt->bind_param("i", $subequipment_id);
$stmt->execute();
$result = $stmt->get_result();
$main_equipment = $result->fetch_assoc();
$equipment_id = $main_equipment['main_equipment_id'];


// $sql = "SELECT * FROM sub_tasks WHERE subequipment_id = ?";
$sql = "SELECT sub_tasks.*, rh_equipments.equipment_name FROM sub_tasks 
        LEFT JOIN rh_equipments ON sub_tasks.equipment_id = rh_equipments.equipment_id 
        WHERE sub_tasks.subequipment_id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $subequipment_id);
$stmt->execute();
$result = $stmt->get_result();
$subtasks = $result->fetch_all(MYSQLI_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/admiral.css">
</head>

<body>
<?php include 'header.php'; ?>

    <main class="table-container">
        <div class="form1">
            <form method="POST" action="edit_subequipment.php?subequipment_id=<?php echo $subequipment_id; ?>">
                <label>Subequipment Name:</label>
                <input type="text" name="subequipment_name" value="<?php echo $subequipment['subequipment_name']; ?>">
                <button class="btn-small waves-effect waves-light" type="submit">Update<i class="material-icons left">update</i></button>
                
                <a href="add_rh_subequipment.php?equipment_id=<?php echo $equipment_id; ?>" class="btn-small waves-effect waves-light">Back
                    <i class="material-icons left">arrow_back</i>
                </a>
            </form>
        </div>
        <div class="form2">
            <h5>Tasks for this Subequipment:</h5>
            <form method="POST" action="add_rhsub_task.php?subequipment_id=<?php echo $subequipment_id; ?>">
                <input type="text" name="sub_task_description" placeholder="New Task" required>
                <input type="text" name="threshold" placeholder="Threshold" required>
                <button class="btn-small waves-effect waves-light" type="submit">Add Task<i class="material-icons left">add</i></button>
                
            </form>
        </div>
        <div class="sub-task-container">
            <table>
                <tr>
                    <th>Equipment Type</th>
                    <th>Equipment Name</th>
                    <th>Task Name</th>
                    <th>Threshold Hours</th>
                    <th>Action</th>
                    
                </tr>
                <?php foreach ($subtasks as $subtask): ?>
                    <tr>
                        <td><?php echo $subtask['equipment_type']; ?></td>
                        <td><?php echo $subtask['equipment_name']; ?></td>
                        <td><?php echo $subtask['sub_task_description']; ?></td>
                        <td><?php echo $subtask['threshold_hour']; ?></td>
                        <td>
                        <a href="edit_sub_task.php?sub_task_id=<?php echo $subtask['sub_task_id']; ?>" class="btn-small waves-effect waves-light">
                            <i class="material-icons left">edit</i>
                        </a>
                        <a href="javascript:void(0);" onclick="confirmDelete(<?php echo $subtask['sub_task_id']; ?>)" class="btn-small waves-effect waves-light red">
                            <i class="material-icons left">delete</i>
                        </a>

                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>

    </main>
        

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);

            // Existing message logic
            var message = <?php echo json_encode($message); ?>;
            if (message !== "") {
                var toastHTML = '<span>' + message + '</span>';
                M.toast({html: toastHTML, displayLength: 4000, classes: 'red'});
            }

            // New session-based message logic
            var sessionMessage = <?php echo json_encode($_SESSION['toastMessage'] ?? ""); ?>;
            if (sessionMessage !== "") {
                M.toast({html: sessionMessage, classes: 'red'});
                <?php unset($_SESSION['toastMessage']); ?>
            }
        });

        function confirmDelete(sub_task_id) {
           var r = confirm("Are you sure you want to delete this task?");
            if (r == true) {
                window.location.href = "delete_sub_task.php?sub_task_id=" + sub_task_id;
            }
        }
    </script>
</body>

</html>
