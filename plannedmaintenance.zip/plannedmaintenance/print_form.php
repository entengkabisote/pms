<?php
session_start();
include 'db_connect.php';  // connection to database

$vessel_id = $_GET['id'];  // get vessel ID from the URL

$sql = "SELECT vessel_name FROM vessels WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $vessel_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$vessel_name = $row['vessel_name'];



$sql = "SELECT DISTINCT category FROM equipment_table";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print Form | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/admiral.css">
    <link rel="stylesheet" href="styles/fetch_equipment_style.css">
</head>

<body>
<?php include 'header.php'; ?>

    <h5>Vessel: <?php echo $vessel_name; ?></h5>
    
    <div class="selector-wrapper">
        <!-- Existing code -->
        <div class="search-selector">
            <select id="equipmentType">
                <option value="" disabled selected>Equipment Type</option>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <option value="<?php echo $row['category']; ?>"><?php echo $row['category']; ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        
        <!-- New month selector -->
        <div class="month-selector">
            <label class="month-class" for="month">Select Month:</label>
            <select id="month">
                <option value="" disabled selected>Month</option>
                <option value="January">January</option>
                <option value="February">February</option>
                <option value="March">March</option>
                <option value="April">April</option>
                <option value="May">May</option>
                <option value="June">June</option>
                <option value="July">July</option>
                <option value="August">August</option>
                <option value="September">September</option>
                <option value="October">October</option>
                <option value="November">November</option>
                <option value="December">December</option>
            </select>
        </div>
    </div>

    <main class="table-container">
        

        <div id="equipmentList">
            <!-- This will be populated dynamically -->
        </div>
        <div class="btn-print">
            <button class="btn-small print-form" onclick="window.print()">Print</button>
            <!-- <button class="btn-small excel-export" id="exportButton">Export to Excel</button> -->
            <!-- <button class="btn-small pdf-generate" id="generatePdf">Generate PDF</button> -->
            <a href="vessel_maintenance.php?id=<?php echo $vessel_id; ?>" class="btn-small waves-effect waves-light btn-back"><i class="material-icons left">arrow_back</i>Back to Vessel Details</a>
        </div>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

        document.getElementById("equipmentType").addEventListener("change", function() {
            // Run PHP code to populate #equipmentList
        });

        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('select');
            var instances = M.FormSelect.init(elems);
        });

        document.getElementById("equipmentType").addEventListener("change", function() {
            var selectedType = this.value;
            // var exportButton = document.getElementById('exportButton');
            // exportButton.setAttribute("onclick", `window.location='export_to_excel.php?vessel_id=${<?php echo json_encode($vessel_id); ?>}&category=${selectedType}'`);
            // Use AJAX to run PHP code to populate #equipmentList
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "fetch_equipment.php?vessel_id=" + <?php echo json_encode($vessel_id); ?> + "&category=" + selectedType, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    document.getElementById("equipmentList").innerHTML = xhr.responseText;
                }
            };
            xhr.send();
        });
        
        // document.getElementById("generatePdf").addEventListener("click", function() {
        //     var selectedType = document.getElementById("equipmentType").value;
        //     var xhr = new XMLHttpRequest();
        //     xhr.open("GET", "generate_pdf.php?vessel_id=" + <?php echo json_encode($vessel_id); ?> + "&category=" + selectedType, true);
        //     xhr.onreadystatechange = function() {
        //         if (xhr.readyState == 4 && xhr.status == 200) {
        //             // Handle PDF generation success (if needed)
        //         }
        //     };
        //     xhr.send();
        // });

        </script>
</body>

</html>
