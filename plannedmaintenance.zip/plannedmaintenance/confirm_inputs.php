<?php
session_start();

if (empty($_SESSION['input_summary']) || empty($_SESSION['vessel_id'])) {
    // Redirect back to the form if there's no input data or vessel_id in the session.
    header('Location: view_vessel_rh_details.php');
    exit();
}

echo "<h2>Confirm Your Inputs</h2>";
foreach ($_SESSION['input_summary'] as $equipment_type => $info) {
    echo "Equipment Type: $equipment_type<br>";
    echo "Date: {$info['date']}<br>";
    echo "Hours: {$info['hours']}<br>";
    echo "Minutes: {$info['minutes']}<br>";
    // Add more details as needed.
}

// Confirm button
echo "<form action='handle_final_submission.php' method='post'>";
echo "<input type='hidden' name='vessel_id' value='{$_SESSION['vessel_id']}'>";
echo "<input type='submit' name='confirm' value='Confirm'>";
echo "</form>";

// Cancel button
echo "<a href='view_vessel_rh_details.php?vessel_id=" . $_SESSION['vessel_id'] . "'>Cancel</a>";
