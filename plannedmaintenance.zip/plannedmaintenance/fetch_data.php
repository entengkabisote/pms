<?php
include 'db_connect.php';

function fetchTableData($vessel_id, $equipment_name, $threshold_hour = null) {
    global $conn;

    $sql = "SELECT rh_equipments.equipment_name, tasks.task_description, tasks.threshold_hour
            FROM vessel_rh_equipment
            JOIN rh_equipments ON vessel_rh_equipment.equipment_id = rh_equipments.equipment_id
            JOIN tasks ON vessel_rh_equipment.task_id = tasks.task_id
            WHERE vessel_rh_equipment.vessel_id = ? AND rh_equipments.equipment_name = ?";

    $params = [$vessel_id, $equipment_name];

    if ($threshold_hour !== null) {
        $sql .= " AND tasks.threshold_hour = ?";
        $params[] = $threshold_hour;
    }

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(str_repeat('s', count($params)), ...$params);
    $stmt->execute();

    $result = $stmt->get_result();
    $tableData = [];
    while ($row = $result->fetch_assoc()) {
        $tableData[] = $row;
    }
    return $tableData;
}

function getVesselName($vessel_id) {
    global $conn;
    $sql = "SELECT vessel_name FROM vessels WHERE id = ?"; // Assuming na meron kang vessels table
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $vessel_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        return $row['vessel_name'];
    }
    return null;
}


?>