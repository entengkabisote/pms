<?php
session_start();


include 'db_connect.php';  // connection in database

$sql_types = "SELECT * FROM equipment_type";
$result_types = $conn->query($sql_types);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Equipment | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/equipment_style.css">
    <link rel="stylesheet" href="styles/buttons.css">
    
</head>

<body>
<?php include 'header.php'; ?>
    <h5 class="center-align">Equipment Management Dashboard</h5> 
<!-- ************************************** -->
    <main class="equipment-container">
<!-- ************************************** -->
    

<form id="addEquipmentForm">
    <div class="input-field">
        <input id="equipmentName" type="text" class="validate" required>
        <label for="equipmentName">Equipment Name</label>
    </div>

    <div class="input-field">
        <select id="equipmentCategory">
            <option value="" disabled selected>Select Type...</option>
            <?php while ($type = $result_types->fetch_assoc()) { ?>
                <option value="<?php echo $type['type']; ?>">
                <?php echo $type['type']; ?>
                </option>
            <?php } ?>
        </select>
        <label>Type</label>
    </div>

    <button class="btn-small waves-effect waves-light blue" type="submit">
        <i class="material-icons left">send</i> Add Equipment 
    </button>
    <div style="float: right;">
        <a href="index.php" class="btn-small waves-effect waves-light"><i class="material-icons left">home</i>Home</a>
    </div>
</form>

<h5 class="center-align">List of Equipment</h5> 

<table class="highlight responsive-table"> 
    <thead>
        <tr>
        <th>Equipment Name</th> 
        <th>Type</th>
        <th>Action</th>
        </tr>
    </thead>
    <tbody id="equipmentList">
        <!-- Equipment will be listed here -->
    </tbody>
</table>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="script/add_equipment.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var dropdownElems = document.querySelectorAll('.dropdown-trigger');
            M.Dropdown.init(dropdownElems);
            
            var selectElems = document.querySelectorAll('select');
            M.FormSelect.init(selectElems);
        });
    </script>
</body>

</html>
