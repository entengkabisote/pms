<?php
include 'db_connect.php' ;

// Assuming your database connection is already setup in $conn

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['vessel_id'])) {
    $vessel_id = $_POST['vessel_id'];

    // Start the transaction
    $conn->begin_transaction();

    try {
        // The inspection_meta_ids checked in the form
        $checkedInspections = $_POST['inspection_to_delete'] ?? [];

        // Convert the values to a simple array of inspection_meta_id
        $checkedInspectionIds = array_map(function($value) {
            return explode(',', $value)[1]; // the second part is the inspection_meta_id
        }, $checkedInspections);

        // Get all current inspection_meta_ids for this vessel_id
        $currentInspectionsStmt = $conn->prepare("SELECT inspection_meta_id FROM vessel_equipment WHERE vessel_id = ?");
        $currentInspectionsStmt->bind_param("i", $vessel_id);
        $currentInspectionsStmt->execute();
        $result = $currentInspectionsStmt->get_result();

        // Delete the unchecked inspection_meta_ids
        while($row = $result->fetch_assoc()) {
            if (!in_array($row['inspection_meta_id'], $checkedInspectionIds)) {
                $deleteStmt = $conn->prepare("DELETE FROM vessel_equipment WHERE vessel_id = ? AND inspection_meta_id = ?");
                $deleteStmt->bind_param("ii", $vessel_id, $row['inspection_meta_id']);
                $deleteStmt->execute();
            }
        }

        // Commit the transaction
        $conn->commit();
    } catch (Exception $e) {
        // If an error occurs, rollback the transaction
        $conn->rollback();
        // Handle error, log it, or show a message to the user
    }

    // Redirect to the vessel maintenance page with the vessel_id
    header("Location: vessel_maintenance.php?id=" . htmlspecialchars($vessel_id));
    exit;
}
?>
