<div class="logo-header">
    <img src="images/smscorp.png" alt="Company Logo" class="logo">
    <h4 class="white-text">Strategic Maritime Solutions Corp.</h4>
</div>
