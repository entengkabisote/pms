<?php
include 'db_connect.php';
// your database connection here
$sqlEquip = "SELECT DISTINCT equipment_type FROM rh_equipments";
$resultEquip = $conn->query($sqlEquip);

$sqlEquipName = "SELECT DISTINCT equipment_name FROM rh_equipments";
$resultEquipName = $conn->query($sqlEquipName);


// Fetch distinct threshold hours
$sqlThreshold = "SELECT DISTINCT threshold_hour FROM tasks";
$resultThreshold = $conn->query($sqlThreshold);

$vessel_id = isset($_GET['id']) ? $_GET['id'] : null;
$equipment_type = isset($_GET['equipment_type']) ? $_GET['equipment_type'] : null; // new line


if($vessel_id) {
    $sql = "SELECT rh_equipments.equipment_type 
            FROM vessel_rh_equipment
            JOIN rh_equipments ON vessel_rh_equipment.equipment_id = rh_equipments.equipment_id
            WHERE vessel_rh_equipment.vessel_id = $vessel_id";
    // Run the query
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $equipment_type = $row['equipment_type'];
            // echo $equipment_type . "<br>";
        }
    }
}



// $equipment_type = $_GET['equipment_type'];

if($vessel_id && $equipment_type) {
    $sql = "SELECT rh_equipments.equipment_type, rh_equipments.equipment_name, tasks.task_description
            FROM vessel_rh_equipment
            JOIN rh_equipments ON vessel_rh_equipment.equipment_id = rh_equipments.equipment_id
            JOIN tasks ON vessel_rh_equipment.task_id = tasks.task_id
            WHERE vessel_rh_equipment.vessel_id = $vessel_id AND rh_equipments.equipment_type = '$equipment_type'";
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/print_rh_style.css">
</head>

<body>
<?php include 'header.php'; ?>
    <div class="selector-wrapper">
        <div class="search-selector">
            <label>Equipment Name:</label>
            <select name="equipment_name">
                <option value="" disabled selected>Select Equipment</option>
                <?php
                while($rowEquipName = $resultEquipName->fetch_assoc()) {
                    echo '<option value="' . $rowEquipName['equipment_name'] . '">' . $rowEquipName['equipment_name'] . '</option>';
                }
                ?>
            </select>
        </div>
        <div class="search-selector">
            <label>Threshold Hour Selector:</label>
            <select name="threshold_hour">
            <option value="" disabled selected>Select Threshold</option>
                <?php
                while($rowThreshold = $resultThreshold->fetch_assoc()) {
                    echo '<option value="' . $rowThreshold['threshold_hour'] . '">' . $rowThreshold['threshold_hour'] . ' hours</option>';
                }
                ?>
            </select>
        </div>
        <div class="search-selector">
            <label>Month Selector:</label>
            <select name="selected_month">
                <option value="" disabled selected>Select Month</option>
                <?php
                for ($i = 1; $i <= 12; $i++) {
                    $monthName = date('F', mktime(0, 0, 0, $i, 10));
                    echo "<option value='$i'>$monthName</option>";
                }
                ?>
            </select>
        </div>
    </div>
    <div class="button-container">
        <a href="vessel_maintenance.php?id=<?php echo $vessel_id; ?>" class="btn-small waves-effect waves-light"><i class="material-icons left">arrow_back</i>Back to Vessel Details</a>
        
        <button class="btn-small waves-effect waves-light" id="previewButton">Preview</button>
    
    </div>
    <main class="print-rh-container">

    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>

        const urlParams = new URLSearchParams(window.location.search);
        const vesselId = urlParams.get('id');


        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);

            var elems = document.querySelectorAll('select');
            var instances = M.FormSelect.init(elems);
        });

        function fetchData() {
            var selectedName = document.querySelector("select[name='equipment_name']").value;
            var selectedThreshold = document.querySelector("select[name='threshold_hour']").value;
            var vesselId = <?php echo json_encode($vessel_id); ?>;
            var xhr = new XMLHttpRequest();

            var url = "fetch_rh_equipment.php?vessel_id=" + vesselId;
            if (selectedName) {
                url += "&equipment_name=" + selectedName;
            }
            if (selectedThreshold) {
                url += "&threshold_hour=" + selectedThreshold;
            }

            xhr.open("GET", url, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    document.querySelector(".print-rh-container").innerHTML = xhr.responseText;
                }
            };
            xhr.send();
        }

        // Bind event listeners
        document.querySelector("select[name='threshold_hour']").addEventListener("change", fetchData);
        document.querySelector("select[name='equipment_name']").addEventListener("change", fetchData);

        document.querySelector("select[name='equipment_name']").addEventListener("change", function() {
            var selectedName = this.value;
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "fetch_thresholds.php?equipment_name=" + selectedName, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var thresholds = JSON.parse(xhr.responseText);
                    var thresholdDropdown = document.querySelector("select[name='threshold_hour']");
                    var newOptionsHtml = '<option value="">Select Threshold</option>';
                    
                    thresholds.forEach(function(threshold) {
                        newOptionsHtml += '<option value="' + threshold + '">' + threshold + ' hours</option>';
                    });

                    thresholdDropdown.innerHTML = newOptionsHtml;
                    M.FormSelect.init(thresholdDropdown);  // Re-initialize materialize select
                }
            };
            xhr.send();
        });

        document.getElementById('previewButton').addEventListener('click', function() {
            var equipmentName = document.querySelector("select[name='equipment_name']").value;
            var thresholdHour = document.querySelector("select[name='threshold_hour']").value;
            var selectedMonth = document.querySelector("select[name='selected_month']").value;

            if(vesselId && equipmentName && thresholdHour && selectedMonth) {
                window.location.href = 'preview.php?vessel_id=' + vesselId + '&equipment_name=' + equipmentName + '&threshold_hour=' + thresholdHour + '&selected_month=' + selectedMonth;
            } else {
                alert('Please select vessel, equipment, threshold, and month first.');
            }
        });




        </script>
</body>

</html>
