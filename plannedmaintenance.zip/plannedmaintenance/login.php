<?php
ini_set('max_execution_time', 300);
session_start();

include 'db_connect.php'; // DataBase Connection
require_once 'config.php'; // Include the config file to use SMTP credentials

// Relative paths para sa PHPMailer assuming na ang 'vendor' folder ay nasa loob ng 'plannedmaintenance' na ngayon ay root ng 'pms.smscorp.ph'
require_once 'vendor/phpmailer/phpmailer/src/Exception.php';
require_once 'vendor/phpmailer/phpmailer/src/PHPMailer.php';
require_once 'vendor/phpmailer/phpmailer/src/SMTP.php';


// Local Connection -----
// include 'db_connect.php';  // DataBase Connection
// require_once 'config.php'; // Include the config file to use SMTP credentials
// require_once 'C:\wamp64\www\plannedmaintenance\vendor\phpmailer\phpmailer\src\Exception.php';
// require_once 'C:\wamp64\www\plannedmaintenance\vendor\phpmailer\phpmailer\src\PHPMailer.php';
// require_once 'C:\wamp64\www\plannedmaintenance\vendor\phpmailer\phpmailer\src\SMTP.php';

// require_once '/home/smscorp/secure_config/config.php';
// require_once '/home/smscorp/public_html/plannedmaintenance/vendor/phpmailer/phpmailer/src/Exception.php';
// require_once '/home/smscorp/public_html/plannedmaintenance/vendor/phpmailer/phpmailer/src/PHPMailer.php';
// require_once '/home/smscorp/public_html/plannedmaintenance/vendor/phpmailer/phpmailer/src/SMTP.php';


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = ''; // Initialize error message

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query to check if the user exists
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    // Verify the password
    if ($user && password_verify($password, $user['password'])) {
        // Generate OTP
        $otp = rand(100000, 999999);

        // Store user's full name in session after successful login
        $_SESSION['fullname'] = $user['fullname']; // Make sure 'fullname' is the correct column name in your database

        // Store OTP in session
        $_SESSION['otp'] = $otp;
        $_SESSION['otp_time'] = time(); // to check OTP validity
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $user['username'];
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['role'] = $user['role'];

        // Since we have a valid user, we can now get the email address from the $user array
        $email = $user['email']; // Make sure the column name in your database is 'email'

        // Send OTP to user's email
        $mail = new PHPMailer(true);
        try {
            //Server settings
            $mail->SMTPDebug = 0;
            $mail->isSMTP();                                           
            $mail->Host       = SMTP_HOST;  // Use constants from config.php
            $mail->SMTPAuth   = true;                                  
            $mail->Username   = SMTP_USER; // Use constants from config.php
            $mail->Password   = SMTP_PASS;   // Use constants from config.php
            // $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->SMTPSecure = SMTP_SEC; // Encryption from config.php        
            $mail->Port       = SMTP_PORT;                                   

            //Recipients
            $mail->setFrom(SMTP_USER, 'Mailer');
            $mail->addAddress($email, $user['username']); // Use the $email variable here

            // Content
            $mail->isHTML(true);                                  
            $mail->Subject = 'Your OTP';
            $mail->Body    = 'Your OTP for login is: ' . $otp;

            $mail->send();

            $_SESSION['message'] = 'An OTP has been sent to your email. Please check your inbox to proceed.';
            // Redirect to OTP verification page
            header('Location: verify_otp.php');
            exit;
        } catch (Exception $e) {
            $error = "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        // Set error message for invalid login
        $error = 'Invalid username or password.';
    }
}

if (isset($_SESSION['error_message'])) {
    $errorMessage = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
} else {
    $errorMessage = '';
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <style>
        #toast-container {
            top: 50% !important;
            right: 50% !important;
            transform: translateX(50%) translateY(-50%);
        }
        .red-toast {
            background-color: red;
        }
    </style>
</head>

<body>

    <div class="container">
        <div class="row">
            <div class="col s12 m6 offset-m3">
                <div class="card">
                    <div class="card-content">
                    <?php 
    if(isset($error)) {
        echo "<p class='red-text center-align'>$error</p>";
    }
?>
                        <span class="card-title center">Login</span>
                        <form action="" method="post">
                            <div class="input-field">
                                <input id="username" type="text" name="username" required>
                                <label for="username">Username</label>
                            </div>
                            <div class="input-field">
                                <input id="password" type="password" name="password" required>
                                <label for="password">Password</label>
                            </div>
                            <div class="center">
                                <button type="submit" class="btn blue">Login</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);

            var elems = document.querySelectorAll('select');
            var instances = M.FormSelect.init(elems);

            // Check if there is an error message and display it with M.toast
            var errorMessage = <?php echo json_encode($errorMessage); ?>;
            if (errorMessage) {
                M.toast({html: errorMessage, classes: 'red-toast'});
            }
        });
        
        // ... iba pang existing JavaScript code ...
</script>
</body>

</html>
