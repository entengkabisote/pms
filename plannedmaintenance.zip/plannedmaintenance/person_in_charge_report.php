<?php
include 'db_connect.php';

if (isset($_GET['id'])) {
    $vessel_id = $_GET['id'];
} else {
    // Handle the error here
}

$sql_initial = "SELECT ve.vessel_id, ve.equipment_id, im.person_in_charge
                FROM vessel_equipment ve
                JOIN inspection_meta_table im ON ve.equipment_id = im.equipment_id
                WHERE ve.vessel_id = $vessel_id";
$result_initial = $conn->query($sql_initial);

$pic_report = [];
if ($result_initial->num_rows > 0) {
    while($row = $result_initial->fetch_assoc()) {
        $pic = $row['person_in_charge'];
        $equipment = $row['equipment_id'];
        $pic_report[$pic][$equipment] = [];
    }
}

$sql = "SELECT DISTINCT person_in_charge FROM inspection_meta_table";
$result = $conn->query($sql);
$persons = [];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $persons[] = $row;
    }
}


$sql = "SELECT 
            ve.vessel_id,
            ve.equipment_id,
            im.inspection_type,
            im.person_in_charge,
            v.id as vessel_name,
            e.equipment_name,
            id.inspection_date,
            id.remarks
        FROM 
            vessel_equipment ve
        JOIN 
            inspection_meta_table im ON ve.equipment_id = im.equipment_id AND ve.inspection_meta_id = im.meta_id
        JOIN 
            vessels v ON ve.vessel_id = v.id
        JOIN 
            equipment_table e ON ve.equipment_id = e.equipment_id
        LEFT JOIN 
            inspection_date id ON id.equipment_id = ve.equipment_id AND id.inspection_meta_id = im.meta_id
        WHERE 
            ve.vessel_id = $vessel_id";



$result = $conn->query($sql);

if ($result === false) {
    die("SQL Error: " . $conn->error);
}

// $result = $conn->query($sql);
// if (!$result) {
//     die("SQL Error: " . $conn->error);
// }


// $pic_report = [];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $pic = $row['person_in_charge'];
        $equipment = $row['equipment_name'];
        $inspection_type = $row['inspection_type'];
        $inspection_date = $row['inspection_date'];
        $remarks = $row['remarks'];

        $pic_report[$pic][$equipment][$inspection_type][] = ['date' => $inspection_date, 'remarks' => $remarks];
    }
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/person_incharge_style.css">
</head>

<body>
<?php include 'header.php'; ?>
<h5>Person-in-Charge Report</h5>
    <div class="btn-back">
        <a href="vessel_maintenance.php?id=<?php echo $vessel_id; ?>" class="btn waves-effect waves-light custom-btn" >
            <i class="material-icons left">arrow_back</i>Back
        </a>
    </div>

    
    <main class="person-incharge-container">
        <label for="person_in_charge">Person-in-Charge:</label>
        <select name="person_in_charge" id="person_in_charge">
            <option value="all">All</option>
            <?php
            // $persons would come from your SQL query
            foreach($persons as $person) {
                echo "<option value='" . $person['person_in_charge'] . "'>" . $person['person_in_charge'] . "</option>";
            }
            ?>
        </select>

        
    <table class="highlight">
    <thead>
        <tr>
            <th class="no" >#</th>
            <th class="pic" >Person-in-Charge</th>
            <th class="equip" >Equipment</th>
            <th class="instype">Inspection Type</th>
            <th class="insdate">Inspection Date</th>
            <th class="rem">Remarks</th>
        </tr>
    </thead>
    <tbody>
    <?php 
$row_number = 1;  // For numbering the rows
foreach ($pic_report as $pic => $equipments): ?>
    <?php foreach ($equipments as $equipment => $types): ?>
        <?php foreach ($types as $type => $details): ?>
            <?php foreach ($details as $detail): ?>
                <tr class="table-row" data-person-in-charge="<?php echo $pic; ?>">
                    <td><?php echo $row_number++; ?></td> <!-- This is for numbering -->
                    <td><?php echo $pic; ?></td>
                    <td><?php echo $equipment; ?></td>
                    <td><?php echo $type; ?></td>
                    <td><?php echo $detail['date']; ?></td>
                    <td><?php echo $detail['remarks']; ?></td>
                </tr>
            <?php endforeach; ?>
        <?php endforeach; ?>
    <?php endforeach; ?>
<?php endforeach; ?>

    </tbody>
</table>

    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

        var selectElems = document.querySelectorAll('select');
        var selectInstances = M.FormSelect.init(selectElems);


        document.getElementById('person_in_charge').addEventListener('change', function() {
            var selectedValue = this.value;
            var row_number = 1;  // Reset row numbering to 1 on every change

            // Hide all rows first
            document.querySelectorAll('.table-row').forEach(function(row) {
                row.style.display = 'none';
            });

            if (selectedValue === 'all') {
                // Show all rows and update their numbering
                document.querySelectorAll('.table-row').forEach(function(row) {
                    row.style.display = 'table-row';
                    row.cells[0].innerText = row_number++;  // Update the row number
                });
            } else {
                // Show rows that match the selected value and update their numbering
                document.querySelectorAll('.table-row[data-person-in-charge="' + selectedValue + '"]').forEach(function(row) {
                    row.style.display = 'table-row';
                    row.cells[0].innerText = row_number++;  // Update the row number
                });
            }
        });

        // document.getElementById('person_in_charge').addEventListener('change', function() {
        //     var selectedValue = this.value;
            
        //     // Hide all rows first
        //     document.querySelectorAll('.table-row').forEach(function(row) {
        //         row.style.display = 'none';
        //     });
            
        //     if (selectedValue === 'all') {
        //         // Show all rows
        //         document.querySelectorAll('.table-row').forEach(function(row) {
        //             row.style.display = 'table-row';
        //         });
        //     } else {
        //         // Show rows that match the selected value
        //         document.querySelectorAll('.table-row[data-person-in-charge="' + selectedValue + '"]').forEach(function(row) {
        //             row.style.display = 'table-row';
        //         });
        //     }
        // });

        // JavaScript
        // document.getElementById('person_in_charge').addEventListener('change', function() {
        //     var selectedValue = this.value;
            
        //     // Hide all rows first
        //     document.querySelectorAll('.table-row').forEach(function(row) {
        //         row.style.display = 'none';
        //     });
            
        //     // Show rows that match the selected value
        //     document.querySelectorAll('.table-row[data-person-in-charge="' + selectedValue + '"]').forEach(function(row) {
        //         row.style.display = 'table-row';
        //     });
        // });

            
    </script>
</body>

</html>
