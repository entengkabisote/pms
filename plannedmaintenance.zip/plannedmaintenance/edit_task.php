<?php
include "db_connect.php";

// Handling GET request for task ID
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    $query = "SELECT * FROM tasks WHERE task_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $task = $result->fetch_assoc();
    } else {
        die("Task not found with ID: $id");
    }
    $stmt->close();
} else {
    die("ID is required to edit the task.");
}

// Checking if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $task_description = htmlspecialchars(trim($_POST['task_description']));
    if (empty($task_description)) {
        echo "Task description is required!";
        exit;
    }
    
    $threshold_hour = intval($_POST['threshold_hour']);
    if (!filter_var($threshold_hour, FILTER_VALIDATE_INT)) {
        echo "Threshold hour should be a valid number!";
        exit;
    }

    $task_id = intval($_POST['task_id']);
    $equipment_id = intval($_POST['equipment_id']);

    $subequipment = htmlspecialchars(trim($_POST['subequipment']));
    if (empty($subequipment)) {
        $subequipment = NULL;
    }

    $checkQuery = "SELECT * FROM tasks WHERE equipment_id = ? AND task_description = ? AND threshold_hour = ? AND (subequipment = ? OR (subequipment IS NULL AND ? IS NULL)) AND task_id != ?";
    $checkStmt = $conn->prepare($checkQuery);
    $checkStmt->bind_param("isissi", $equipment_id, $task_description, $threshold_hour, $subequipment, $subequipment, $task_id);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    if ($checkResult->num_rows > 0) {
        echo "An entry with the same details already exists.";
        $checkStmt->close();
        exit;
    }

    $stmt = $conn->prepare("UPDATE tasks SET task_description=?, threshold_hour=?, subequipment=? WHERE task_id=?");
    $stmt->bind_param("sisi", $task_description, $threshold_hour, $subequipment, $task_id);
    
    if ($stmt->execute()) {
        header("Location: rh_tasks.php?success=1"); 
        exit;
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/edit_task_style.css">
    <!-- <link rel="stylesheet" href="styles/buttons.css"> -->
</head>

<body>
<?php include 'header.php'; ?>
    <div>
        <h5>Edit Task</h5>
    </div>
    <main class="edit-task-container">
        
        <form action="" method="POST" class="form-style">
            <input type="hidden" name="equipment_id" value="<?php echo $task['equipment_id']; ?>">

            <input type="hidden" name="task_id" value="<?php echo $task['task_id']; ?>">
            
            <div class="form-group">
                <label for="task_name">Task Description:</label>
                <input type="text" name="task_description" value="<?php echo $task['task_description']; ?>" required>
            </div>

            <div class="form-group">
                <label for="task_type">Threshold Hour:</label>
                <input type="text" name="threshold_hour" value="<?php echo $task['threshold_hour']; ?>">
            </div>
            <div class="form-group">
                <label for="subequipment">Subequipment:</label>
                <input type="text" name="subequipment" value="<?php echo $task['subequipment']; ?>">
            </div>

            <div style="display: flex; justify-content: space-between; margin-top: 10px;">
                <button class="btn-small waves-effect waves-light" type="submit"> <i class="material-icons left">refresh</i> Update Equipment </button>
                <button class="btn-small waves-effect waves-light" type="button" onclick="location.href='rh_tasks.php?equipment_id=<?php echo $task['equipment_id']; ?>'"> <i class="material-icons left">arrow_back</i> Back </button>

            </div>
        </form>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

        
        </script>
</body>

</html>
