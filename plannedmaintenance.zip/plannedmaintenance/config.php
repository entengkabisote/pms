<?php
// Database Credentials
// if (!defined('DB_HOST')) {
//   define('DB_HOST', 'localhost');
// }
// if (!defined('DB_USER')) {
//   define('DB_USER', 'smscorp_pms_sms');
// }
// if (!defined('DB_PASS')) {
//   define('DB_PASS', 'Enteng1972');
// }
// if (!defined('DB_NAME')) {
//   define('DB_NAME', 'smscorp_plannedmaintenance');
// }


// Local Database Credentials
if (!defined('DB_HOST')) {
    define('DB_HOST', 'localhost');
  }
  if (!defined('DB_USER')) {
    define('DB_USER', 'pms_sms');
  }
  if (!defined('DB_PASS')) {
    define('DB_PASS', 'Enteng1972');
  }
  if (!defined('DB_NAME')) {
    define('DB_NAME', 'plannedmaintenance');
  }


// Company SMTP Credentials
// if (!defined('SMTP_HOST')) {
//   define('SMTP_HOST', 'mail.smscorp.ph'); 
// }
// if (!defined('SMTP_USER')) {
//   define('SMTP_USER', 'eric.ramos@smscorp.ph'); 
// }
// if (!defined('SMTP_PASS')) {
//   define('SMTP_PASS', 'Jorgeedi2016'); 
// }
// if (!defined('SMTP_PORT')) {
//   define('SMTP_PORT', 465); 
// }
// if (!defined('SMTP_SEC')) {
//   define('SMTP_SEC', 'ssl'); 
// }

// Yahoo Mail SMTP Credentials
if (!defined('SMTP_HOST')) {
  define('SMTP_HOST', 'smtp.mail.yahoo.com'); 
}
if (!defined('SMTP_USER')) {
  define('SMTP_USER', 'info.smscorp@yahoo.com'); 
}
if (!defined('SMTP_PASS')) {
  define('SMTP_PASS', 'V3ryStr0ngPassw0rd'); 
}
if (!defined('SMTP_PORT')) {
  define('SMTP_PORT', 465); 
}
if (!defined('SMTP_SEC')) {
  define('SMTP_SEC', 'ssl'); 
}

?>
