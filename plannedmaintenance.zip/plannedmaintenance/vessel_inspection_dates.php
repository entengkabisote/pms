<?php
session_start();

include 'db_connect.php';  // Database connection
$vessel_id = filter_input(INPUT_GET, 'id');
$month = filter_input(INPUT_GET, 'month', FILTER_VALIDATE_INT);
$year = filter_input(INPUT_GET, 'year', FILTER_VALIDATE_INT);
$numOfDays = cal_days_in_month(CAL_GREGORIAN, $month, $year);



$queryVesselName = "SELECT vessel_name FROM vessels WHERE id = ?";
$stmtVesselName = $conn->prepare($queryVesselName);

if ($stmtVesselName === false) {
    die("Error: " . $conn->error);
}

$stmtVesselName->bind_param("i", $vessel_id);
$stmtVesselName->execute();

$resultVesselName = $stmtVesselName->get_result();
$vessel_name_data = $resultVesselName->fetch_assoc();
$vessel_name = $vessel_name_data['vessel_name'];


if (!$vessel_id || !$month || !$year) {
    die('Missing or invalid parameters.');
}

$query = "
    SELECT 
        v.id as vessel_id,
        v.vessel_name, 
        e.category, 
        e.equipment_name, 
        e.equipment_id,
        im.inspection_type,
        id.inspection_date,
        id.remarks
    FROM vessel_equipment ve
    JOIN vessels v ON v.id = ve.vessel_id
    JOIN equipment_table e ON ve.equipment_id = e.equipment_id
    JOIN inspection_meta_table im ON ve.inspection_meta_id = im.meta_id
    LEFT JOIN inspection_date id ON id.equipment_id = e.equipment_id AND id.vessel_id = v.id AND id.inspection_meta_id = im.meta_id
    WHERE v.id = ? AND MONTH(id.inspection_date) = ? AND YEAR(id.inspection_date) = ?
    ORDER BY v.vessel_name, e.category, e.equipment_name, im.inspection_type, id.inspection_date
";

$stmt = $conn->prepare($query);
if ($stmt === false) {
    die("Error: " . $conn->error);
}

$stmt->bind_param("iii", $vessel_id, $month, $year);
$stmt->execute();

$result = $stmt->get_result();
$data = [];

while ($row = $result->fetch_assoc()) {
    $categoryKey = $row['category'];
    $equipmentKey = $row['equipment_name'];
    $inspectionKey = $row['inspection_type'];

    if (!isset($data[$categoryKey])) {
        $data[$categoryKey] = [];
    }

    if (!isset($data[$categoryKey][$equipmentKey])) {
        $data[$categoryKey][$equipmentKey] = [];
    }

    if (!isset($data[$categoryKey][$equipmentKey][$inspectionKey])) {
        $data[$categoryKey][$equipmentKey][$inspectionKey] = [
            'inspection_dates' => [],
            'remarks' => []
        ];
    }
    
    if ($row['inspection_date']) {
        $dayOfMonth = (int)date('j', strtotime($row['inspection_date']));
        $data[$categoryKey][$equipmentKey][$inspectionKey]['inspection_dates'][$dayOfMonth] = $dayOfMonth;
        $data[$categoryKey][$equipmentKey][$inspectionKey]['remarks'][$dayOfMonth] = $row['remarks'] ? $row['remarks'] : '-';
    }
}



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://unpkg.com/@popperjs/core@2"></script>
    <script src="https://unpkg.com/tippy.js@6"></script>
    <link href="https://unpkg.com/tippy.js@6/dist/tippy.css" rel="stylesheet"/>
    <link href="https://unpkg.com/tippy.js@6/dist/tippy.css" rel="stylesheet"/>
    <link href="https://unpkg.com/tippy.js@6/dist/backdrop.css" rel="stylesheet"/>
    <link href="https://unpkg.com/tippy.js@6/dist/border.css" rel="stylesheet"/>
    <link href="https://unpkg.com/tippy.js@6/animations/shift-toward-extreme.css" rel="stylesheet"/>
    <link href="https://unpkg.com/tippy.js@6/themes/light-border.css" rel="stylesheet"/>
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/vsl_inspct_dates_style.css">
    
</head>

<body>
<?php include 'header.php'; ?>

    <main class="vessel-inspct-dates-container">
        <div class="backButton">
            <a class="btn-small waves-effect waves-light" href="vessel_maint_details.php?id=<?php echo $vessel_id; ?>"> <i class="material-icons left">arrow_back</i>Back</a>
        </div>
        <h5>Inspection Dates for Vessel: <?php echo htmlspecialchars($vessel_name, ENT_QUOTES, 'UTF-8'); ?></h5>


        <h5><?php echo date("F", mktime(0, 0, 0, $month, 10)) . " $year"; ?></h5>
        <table class="striped responsive-table">
            <thead>
                <tr>
                    <th>Category</th>
                    <!-- <th>Equipment Name</th>
                    <th>Inspection Type</th> -->
                    <!-- Add a TH for each day of the month -->
                    <?php for ($i = 1; $i <= $numOfDays; $i++): ?>
                        <th><?php echo $i; ?></th>
                        <!-- <th>Remarks</th>  This is new -->
                    <?php endfor; ?>
                </tr>
            </thead>
            
            <tbody>
    <?php foreach ($data as $category => $equipments): ?>
        <tr>
        <td class="category"><?= $category ?></td>
            <?php for ($i = 1; $i <= $numOfDays; $i++): ?>
                <td></td>
            <?php endfor; ?>
        </tr>
        <?php foreach ($equipments as $equipment => $inspectionTypes): ?>
            <tr>
            <td class="equipment"><?= $equipment ?></td>
                <?php for ($i = 1; $i <= $numOfDays; $i++): ?>
                    <td></td>
                <?php endfor; ?>
            </tr>
            <?php foreach ($inspectionTypes as $inspectionType => $details): ?>
                <tr>
                <td class="inspection"><?= $inspectionType ?></td>
                    <?php for ($i = 1; $i <= $numOfDays; $i++): ?>
                        <td>
    <?php if (isset($details['inspection_dates'][$i])): ?>
        <span class="x-mark" data-tippy-content="<?= $details['remarks'][$i] ?>">X</span>
    <?php else: ?>
        -
    <?php endif; ?>
</td>
                    <?php endfor; ?>
                </tr>
            <?php endforeach; ?>
        <?php endforeach; ?>
    <?php endforeach; ?>
</tbody>


        </table>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

        // Here is the code for Tippy
        tippy('[data-tippy-content]');
    </script>
</body>

</html>
