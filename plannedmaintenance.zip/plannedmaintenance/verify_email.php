<?php
session_start(); // Add session_start() to the beginning of the file
include 'db_connect.php'; // Make sure the path in your database connection script is correct

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    // I-verify ang token
    $query = "SELECT * FROM users WHERE verification_token = ? AND is_verified = 0";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 's', $token);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($result);

    if ($user) {
        // The token is valid and the user has not been verified
        // Instead of verifying immediately, redirect to the set password page
        $_SESSION['temp_user_id'] = $user['user_id']; // Temporarily store the user_id in the session
        header('Location: set_password.php'); // Redirect to the set password page
        exit();
    } else {
        // Invalid token or already verified
        echo "This link is invalid or you have already verified your email.";
    }
} else {
    echo "No token provided.";
}
?>
