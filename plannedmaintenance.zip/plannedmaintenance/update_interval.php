<?php
include 'db_connect.php';
session_start();

if($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $name = $_POST['name'];

    $stmt = $conn->prepare("UPDATE interval_table SET name = ? WHERE id = ?");
    $stmt->bind_param("si", $name, $id);

    if ($stmt->execute()) {
        $_SESSION['flash_message'] = "Record updated successfully";
    } else {
        $_SESSION['flash_message'] = "Error updating record: " . $stmt->error;
    }
    $stmt->close();
    $conn->close();
    
    header('Location: add_interval.php');
    exit;
}
?>


