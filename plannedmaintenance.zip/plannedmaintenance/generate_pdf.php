<?php

include 'db_connect.php';
require 'vendor/autoload.php';
use Knp\Snappy\Pdf;

$wkhtmltopdfPath = '"C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe"';
$snappy = new Pdf($wkhtmltopdfPath);

$vessel_id = $_GET['vessel_id'];
$category = $_GET['category'];

$sql = "SELECT * FROM vessel_equipment 
        INNER JOIN equipment_table ON vessel_equipment.equipment_id = equipment_table.equipment_id
        INNER JOIN inspection_meta_table ON vessel_equipment.inspection_meta_id = inspection_meta_table.meta_id
        WHERE vessel_id = ? AND category = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $vessel_id, $category);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_all(MYSQLI_ASSOC);

$html .= '<h1>Vessel Equipment Inspection Report</h1>';
$html .= '<style>
            table {
                border-collapse: collapse;
                font-size: 14px;
            }
            th, td {
                padding: 8px 12px;
                border: 1px solid #ddd;
            }
            th {
                background-color: #f2f2f2;
            }
        </style>';

$html .= "<table border='1'>
            <tr>
                <th style='width:45%; text-align:center; background-color: lightgray'>Deck Machinery Equipment</th>
                <th style='width:15%; text-align:center; background-color: lightgray'>Interval of Checks/Testing</th>
                <th style='width:15%; text-align:center; background-color: lightgray'>Person in Charge</th>
                <th style='width:15%; text-align:center; background-color: lightgray'>Criticality</th>
                <th colspan='5' style='width:32%; text-align:center; background-color: lightgray'>Inspection Date</th>
            </tr>";

$lastEquipmentName = "";
foreach ($data as $row) {
    $currentEquipmentName = $row['equipment_name'];

    if ($currentEquipmentName != $lastEquipmentName) {
        $html .= "<tr>
                    <th style='width:45%; text-align:center; background-color: lightgray'>{$currentEquipmentName}</th>
                    <th style='width:15%; text-align:center; background-color: lightgray'></th>
                    <th style='width:15%; text-align:center; background-color: lightgray'></th>
                    <th style='width:15%; text-align:center; background-color: lightgray'></th>
                    <th style='width:5%; text-align:center; background-color: lightgray'>1st</th>
                    <th style='width:5%; text-align:center; background-color: lightgray'>2nd</th>
                    <th style='width:5%; text-align:center; background-color: lightgray'>3rd</th>
                    <th style='width:5%; text-align:center; background-color: lightgray'>4th</th>
                    <th style='width:12%; text-align:center; background-color: lightgray'>Remarks</th>
                </tr>";
        $lastEquipmentName = $currentEquipmentName;
    }
    
    $html .= "<tr>
                <td>{$row['inspection_type']}</td>
                <td style='text-align:center'>{$row['inspection_interval']}</td>
                <td style='text-align:center'>{$row['person_in_charge']}</td>
                <td style='text-align:center'>{$row['criticality']}</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>";
}

$html .= "</table>";  // Close the last table



$outputPath = 'C:\\wamp64\\www\\plannedmaintenance\\pdf\\equipment_inspection.pdf';

$snappy->generateFromHtml($html, $outputPath, array(), true);

echo "PDF generated and saved to " . $outputPath;

?>
