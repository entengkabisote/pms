<?php
include 'db_connect.php';

// Initialize the response array
$response = [
    "status" => "",
    "message" => ""
];

// Set Content-Type
header('Content-Type: application/json');

// Get the posted data
$data = json_decode(file_get_contents("php://input"));

// Validate and sanitize inputs
if (!isset($data->vessel_id, $data->equipment_id, $data->inspection_meta_id, $data->date, $data->remarks)) {
    $response["status"] = "error";
    $response["message"] = "Incomplete data provided.";
    echo json_encode($response);
    exit();
}

$vessel_id = (int) $data->vessel_id;
$equipment_id = (int) $data->equipment_id;
$inspection_meta_id = (int) $data->inspection_meta_id;
$date = filter_var($data->date, FILTER_SANITIZE_STRING); 
$remarks = filter_var($data->remarks, FILTER_SANITIZE_STRING); 

// Check if any required input is empty after sanitization
// if (empty($date) || empty($remarks)) {
//     $response["status"] = "error";
//     $response["message"] = "Date or remarks is empty.";
//     echo json_encode($response);
//     exit();
// }

if (empty($date)) {
    $response["status"] = "error";
    $response["message"] = "Date is empty.";
    echo json_encode($response);
    exit();
}

// First check if there is an existing entry with the same vessel_id, equipment_id, inspection_meta_id, and date
$checkQuery = "SELECT COUNT(*) FROM inspection_date WHERE vessel_id = ? AND equipment_id = ? AND inspection_meta_id = ? AND inspection_date = ?";
$checkStmt = $conn->prepare($checkQuery);
if (!$checkStmt) {
    $response["status"] = "error";
    $response["message"] = "Database error: Cannot prepare statement for checking duplicates.";
    echo json_encode($response);
    exit();
}

$checkStmt->bind_param("iiis", $vessel_id, $equipment_id, $inspection_meta_id, $date);
$checkStmt->execute();
$checkStmt->bind_result($count);
$checkStmt->fetch();
$checkStmt->close();

if ($count > 0) {
    // There is an existing record with the same vessel_id, equipment_id, inspection_meta_id, and date
    $response["status"] = "error";
    $response["message"] = "An inspection record for the given date and equipment already exists.";
    echo json_encode($response);
    exit();
}



$query = "INSERT INTO inspection_date (vessel_id, equipment_id, inspection_meta_id, inspection_date, remarks) VALUES (?, ?, ?, ?, ?)";

$stmt = $conn->prepare($query);

if (!$stmt) {
    $response["status"] = "error";
    $response["message"] = "Database error: Cannot prepare statement.";
    echo json_encode($response);
    exit();
}

$stmt->bind_param("iiiss", $vessel_id, $equipment_id, $inspection_meta_id, $date, $remarks);

$result = $stmt->execute();

if ($result) {
    $response["status"] = "success";
    $response["message"] = "Successfully saved the data.";
} else {
    $response["status"] = "error";
    $response["message"] = "There was a problem saving the data.";
}

$stmt->close();
$conn->close();

echo json_encode($response);
?>
