<?php
include 'db_connect.php';

// Input validation
if(!isset($_POST['vessel_name']) || !isset($_POST['official_number']) || empty(trim($_POST['vessel_name'])) || empty(trim($_POST['official_number']))) {
    $_SESSION['vessel_error'] = "Please provide both vessel name and official number.";
    header("Location: vessel.php");
    exit;
}

$vessel_name = $_POST['vessel_name'];
$official_number = $_POST['official_number'];

// Single Query for checking both vessel name and official number
$sql = "SELECT * FROM vessels WHERE vessel_name = ? OR official_number = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $vessel_name, $official_number);
$stmt->execute();
$result = $stmt->get_result();

session_start();

if ($result->num_rows > 0) {
    $existingVessel = $result->fetch_assoc();
    if ($existingVessel['vessel_name'] === $vessel_name) {
        $_SESSION['vessel_error'] = "A vessel with the same name already exists.";
    }
    if ($existingVessel['official_number'] === $official_number) {
        $_SESSION['vessel_error'] = "A vessel with the same official number already exists.";
    }
} else {
    $_SESSION['vessel_name'] = $vessel_name;
    $_SESSION['official_number'] = $official_number;
    header("Location: enter_vessel_details.php");
    exit;
}

$stmt->close();
$conn->close();
header("Location: vessel.php");
exit;
?>
