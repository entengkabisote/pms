<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit;
}

include 'db_connect.php';  // Connection of database
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/general.css">
</head>

<body>
<?php include 'header.php'; ?>

    <main class="index-container">
        <!-- <h5 class="center-align">Ships</h5> -->

        <!-- List of Ships -->
        <div class="row">
            <?php
            $query = "SELECT * FROM vessels"; 
            $result = mysqli_query($conn, $query);

            if (mysqli_num_rows($result) > 0) {
                while ($ship = mysqli_fetch_assoc($result)) {
                    ?>
                    <div>
                        <div class="card">
                            <div class="card-image">
                                <!-- <a href="vessel_details.php?vessel_id=<?php echo $ship['id']; ?>"> -->
                                <a href="#modal1" class="modal-trigger" data-image="<?php echo $ship['imahe']; ?>">
                                    <img src="<?php echo $ship['imahe']; ?>" alt="<?php echo $ship['vessel_name']; ?>">
                                    <span class="vessel-name"><?php echo $ship['vessel_name']; ?></span>
                                </a>
                            </div>
                            <div class="card-content">
                                 <p><strong>Name:</strong> <?php echo $ship['vessel_name']; ?></p>
                                <p><strong>Type:</strong> <?php echo $ship['ship_type']; ?></p>
                                <p><strong>Home Port:</strong> <?php echo $ship['home_port']; ?></p>
                                <p><strong>Year Built:</strong> <?php echo $ship['year_built']; ?></p>
                                <p><strong>Country:</strong> <?php echo $ship['flag']; ?></p>
                                <p><strong>Owner:</strong> <?php echo $ship['owner']; ?></p>
                            </div>
                            <div class="card-action">
                            
                                <a href="vessel_maintenance.php?id=<?php echo $ship['id']; ?>">View More</a>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            } else {
                echo '<p>No ships found.</p>';
            }
            ?>
        </div>
    </main>

    <div id="modal1" class="modal">
        <div class="modal-content">
            <img id="modal-image" src="" alt="">
            <div id="modal-vessel-details">
                <h5 id="modal-vessel-name"></h5>
            </div>
        </div>
    </div>



    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.modal');
            var instances = M.Modal.init(elems);

            // Listen to the click event for all 'modal-triggers'
            var modalTriggers = document.querySelectorAll('.modal-trigger');
            modalTriggers.forEach(function(trigger) {
                trigger.addEventListener('click', function(e) {
                    const imageSrc = e.currentTarget.getAttribute('data-image');
                    const vesselName = e.currentTarget.querySelector('.vessel-name').innerText;

                    document.getElementById('modal-image').src = imageSrc;
                    document.getElementById('modal-vessel-name').innerText = vesselName;
                });
            });
        });


        document.querySelector('.modal-trigger').addEventListener('click', function(e) {
            const imageSrc = e.currentTarget.getAttribute('data-image');
            const vesselName = e.currentTarget.querySelector('.vessel-name').innerText;

            document.getElementById('modal-image').src = imageSrc;
            document.getElementById('modal-vessel-name').innerText = vesselName;
        });



        </script>
</body>

</html>
