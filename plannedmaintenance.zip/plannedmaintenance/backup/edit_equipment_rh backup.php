<?php
include "db_connect.php";

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $equipment_name = $_POST['equipment_name'];
    $equipment_type = $_POST['equipment_type'];
    $equipment_id = $_POST['equipment_id'];

    $stmt = $conn->prepare("UPDATE rh_equipments SET equipment_name=?, equipment_type=? WHERE equipment_id=?");
    $stmt->bind_param("ssi", $equipment_name, $equipment_type, $equipment_id);
    
    if ($stmt->execute()) {
        header("Location: equipment_running_hours.php?success=1"); // Redirect to your list page or wherever you want after editing
        exit;
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $stmt->close();
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM rh_equipments WHERE equipment_id = $id";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $equipment = $result->fetch_assoc();
    } else {
        die("Equipment not found with ID: $id");
    }
} else {
    die("ID is required to edit the equipment.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Equipment</title>
    <link rel="stylesheet" href="styles/rh_general_style.css">
</head>
<body>
<div class="container">
    <h1>Edit Equipment</h1>
    <form action="" method="POST" class="form-style">
        <input type="hidden" name="equipment_id" value="<?php echo $equipment['equipment_id']; ?>">
        
        <div class="form-group">
            <label for="equipment_name">Equipment Name:</label>
            <input type="text" name="equipment_name" value="<?php echo $equipment['equipment_name']; ?>" required>
        </div>

        <div class="form-group">
            <label for="equipment_type">Equipment Type:</label>
            <input type="text" name="equipment_type" value="<?php echo $equipment['equipment_type']; ?>">
        </div>

        <div style="display: flex; justify-content: space-between; margin-top: 10px;">
            <input type="submit" class="submit-button" value="Update Equipment" style="margin: 10px;">
            <a href="equipment_running_hours.php" class="cancel-button" style="text-align: center; text-decoration: none; margin: 10px; display: inline-block; background-color: red; padding: 10px;">Cancel</a>
        </div>

    </form>
</div>
</body>
</html>

