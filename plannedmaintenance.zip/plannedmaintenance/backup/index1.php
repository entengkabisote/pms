<?php
session_start();
// if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
//     header('Location: login.php');
//     exit;
// }

include 'db_connect.php';  // Koneksyon sa database
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/styles.css">   
</head>

<body>
    <div class="logo-header">
        <img src="images/smscorp.png" alt="Company Logo" class="logo">
        <h4>Strategic Maritime Solutions Corp.</h4>
    </div>

    <nav>
        <div class="nav-wrapper">
            <ul>
                <li><a href="dashboard.html">Dashboard</a></li>
                <li><a href="ships.html">Ships</a></li>
                <li><a href="equipment.html">Equipments</a></li>
                <li><a href="vessel_maintenance.html">Ship/Vessel Inspection Date</a></li>
                <li><a href="#">Running Hours of Equipment</a></li>
                <li><a href="#">Reports</a></li>
                <li><a href="#">Settings</a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="row">
            <?php
            $query = "SELECT * FROM vessels"; 
            $result = mysqli_query($conn, $query);

            if (mysqli_num_rows($result) > 0) {
                while ($ship = mysqli_fetch_assoc($result)) {
                    ?>
                    <div>
                        <div class="card">
                            <div class="card-image">
                                <a href="vessel_details.php?vessel_id=<?php echo $ship['id']; ?>">
                                    <img src="<?php echo $ship['image']; ?>" alt="<?php echo $ship['vessel_name']; ?>">
                                    <span><?php echo $ship['vessel_name']; ?></span>
                                </a>
                            </div>
                            <div class="card-content">
                            </div>
                            <div class="card-action">
                                <a href="#">View More</a>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            } else {
                echo '<p>No ships found.</p>';
            }
            ?>
        </div>
    </div>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#">About</a>
                <a href="#">Contact</a>
                <a href="#">Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

</body>

</html>
