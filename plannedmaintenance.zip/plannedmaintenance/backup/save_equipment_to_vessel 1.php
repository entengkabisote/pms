<?php
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $vessel_id = $_POST['vessel_id'];
    $selectedEquipments = $_POST['equipment'];

    // We can prepare this statement once since it'll be the same for all equipment and meta ids
    $insert_query = "INSERT IGNORE INTO vessel_equipment (vessel_id, equipment_id, inspection_meta_id, date_added) VALUES (?, ?, ?, CURDATE())";

    $insert_stmt = $conn->prepare($insert_query);
    if (!$insert_stmt) {
        die("Insert Prepare failed: " . $conn->error);
    }

    $meta_query = $conn->prepare("SELECT meta_id FROM inspection_meta_table WHERE equipment_id = ?");
    if (!$meta_query) {
        die("Meta Query Prepare failed: " . $conn->error);
    }

    $success = true; // Flag to track if data is successfully saved
    $error_messages = array(); // Array to store error messages
    error_log("Selected Equipments: " . implode(", ", $selectedEquipments));

    $itemsInserted = false;

    // Instead of using this prepared statement, we need to check each selected inspection type
    //$meta_query = $conn->prepare("SELECT meta_id FROM inspection_meta_table WHERE equipment_id = ?");

    foreach ($selectedEquipments as $equipment_id) {
        // I-check kung may mga napiling specific inspection types para sa equipment na ito.
        // Mahalaga na dito tayo mag-check ng isset dahil maaaring hindi mag-post ng field kung walang napiling inspection type.
        if (isset($_POST['inspection_types'][$equipment_id])) {
            $selectedInspectionTypes = $_POST['inspection_types'][$equipment_id];
    
            foreach ($selectedInspectionTypes as $meta_id) {
                $insert_stmt->bind_param("iii", $vessel_id, $equipment_id, $meta_id);
                if ($insert_stmt->execute()) {
                    if ($conn->affected_rows > 0) {
                        $itemsInserted = true;
                    }
                } else {
                    $success = false;
                    $error_messages[] = "Error during insert: " . $insert_stmt->error;
                }
            }
        } else {
            // Kung walang specific inspection types na napili, skip the insertion for this equipment.
            continue; // This is crucial, it means no inspection types were selected for this equipment.
        }
    }
    
    // Close prepared statements
    $insert_stmt->close();
    $meta_query->close();  // This should now work as $meta_query was not overwritten

    if ($success && $itemsInserted) {
        echo "<script>alert('Data successfully saved!');window.location.href = 'vessel_maintenance.php?id=$vessel_id';</script>"; 
    } elseif ($success && !$itemsInserted) {
        echo "<script>alert('No new data to save. Everything is already up to date.');window.location.href = 'vessel_maintenance.php?id=$vessel_id';</script>"; 
    } else {
        $error_message = implode('\n', $error_messages);
        echo "<script>alert('Data not saved due to errors.\\n$error_message'); window.location.href = 'vessel_maintenance.php?id=$vessel_id';</script>";
    }
} else {
    echo "Invalid request method.";
}

?>
