<?php
include 'db_connect.php';
$equipment_id = $_GET['id'];

// Fetch equipment data
$sql_equipment = "SELECT * FROM equipment_table WHERE equipment_id = $equipment_id";
$result_equipment = $conn->query($sql_equipment);
$row_equipment = $result_equipment->fetch_assoc();

// Fetch inspection_meta_table data
$sql_meta = "SELECT * FROM inspection_meta_table WHERE equipment_id = $equipment_id";
$result_meta = $conn->query($sql_meta);
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Edit Equipment</title>
        
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
        
        <style>
            .btn-space {
                margin-right: 10px;
                margin-top: 10px;
                margin-bottom: 10px;
            }
            .input-field, .button-group, #inspectionMetaContainer2 {
                margin-bottom: 15px;
            }
            
        </style>
    </head>
<body>

    <div class="container">
        <form id="editEquipmentForm">
            <div class="row"> <!-- Bagong row para sa input fields -->
                <div class="input-field col s12 m6"> <!-- Half ng width para sa medium-sized screens -->
                    <input type="hidden" id="equipmentId" name="equipmentId" value="<?php echo $equipment_id; ?>">
                    <label for="equipmentName">Equipment Name:</label>
                    <input type="text" id="equipmentName" value="<?php echo isset($row_equipment['equipment_name']) ? $row_equipment['equipment_name'] : ''; ?>" required>
                </div>  
            </div>
            <div class="row"> <!-- Bagong row para sa buttons -->
                <div class="button-group col s12">
                    <button class="btn waves-effect waves-light btn-space" id="saveEquipment" type="submit">Save</button>
                    <a href="equipment.php" class="btn waves-effect waves-light btn-space">Back</a>
                </div>
            </div>

            <div id="inspectionMetaContainer">
                <div class="inspectionRow">
                    <input type="text" name="inspection_type[]" placeholder="Type of Inspection">
                    <!-- Replace this line -->
                    <select id="inspection_interval" name="inspection_interval[]">
                        <option value="" disabled selected>Select Interval...</option>
                        <?php
                            $sql = "SELECT * FROM interval_table";
                            $result = $conn->query($sql);
                            while ($row = $result->fetch_assoc()) {
                                echo "<option value='" . $row['name'] . "'>" . $row['name'] . "</option>";
                            }
                        ?>
                    </select>
                    <!-- <input type="text" name="inspection_interval[]" placeholder="Interval"> -->
                    <input type="text" name="person_in_charge[]" placeholder="Person in Charge">
                    <input type="text" name="criticality[]" placeholder="Criticality">
                    <button type="button" class="btn waves-effect waves-light red removeRow btn-space" style="display:none;">Remove</button>
                    <!-- <button type="button" class="btn waves-effect waves-light red removeRow btn-space">Remove</button> -->
                </div>
            </div>
            <div>
                <button class="btn waves-effect waves-light btn-space" type="button" id="addRow">Add Another Row</button>
                <button class="btn waves-effect waves-light btn-space" id="saveInspection" type="button">Save Inspect</button>
            </div>
            <div id="inspectionMetaContainer2">
                <table>
                    <thead>
                        <tr>
                            <th>Inspection Type</th>
                            <th>Inspection Interval</th>
                            <th>Person In Charge</th>
                            <th>Criticality</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row_meta = $result_meta->fetch_assoc()): ?>
                        <tr class="inspectionMeta">
                            <td><input type="text" class="inspectionType" value="<?php echo $row_meta['inspection_type']; ?>"></td>
                            <td><input type="text" class="inspectionInterval" value="<?php echo $row_meta['inspection_interval']; ?>"></td>
                            <td><input type="text" class="personInCharge" value="<?php echo $row_meta['person_in_charge']; ?>"></td>
                            <td><input type="text" class="criticality" value="<?php echo $row_meta['criticality']; ?>"></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </form>
    </div>
    <script src="script/edit_equipment_script.js"></script>
    <script>
        const equipmentId = $('#equipmentId').val();
    </script>

</body>
</html>
