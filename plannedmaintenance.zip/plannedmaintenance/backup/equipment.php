<?php
include 'db_connect.php';

$sql_types = "SELECT * FROM equipment_type";
$result_types = $conn->query($sql_types);

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Equipment Inspection</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <!-- <link rel="stylesheet" href="style/equipmentStyle.css"> -->
        <style>
            h3, h2 {
                font-size: 24px;
                margin-bottom: 20px;
            }
        
            .container {
                padding: 20px; 
            }


            input, select, label {
                font-size: 14px;
            }

            table.highlight tbody tr {
                height: 40px; 
            }

            table.highlight tbody td, table.highlight thead th {
                padding: 5px 15px;  
            }

            .input-field {
                margin-bottom: 10px !important;  
            }

            table.highlight tbody tr {
                height: 40px; 
            }


        </style>
    </head>
    <body>

        <div class="container">
            <h2 class="center-align">EQUIPMENT</h2> 

            <form id="addEquipmentForm">
                <div class="input-field">
                    <input id="equipmentName" type="text" class="validate" required>
                    <label for="equipmentName">Equipment Name</label>
                </div>

                <div class="input-field">
                    <select id="equipmentCategory">
                        <option value="" disabled selected>Select Category...</option>
                        <?php while ($type = $result_types->fetch_assoc()) { ?>
                            <option value="<?php echo $type['type']; ?>">
                            <?php echo $type['type']; ?>
                            </option>
                        <?php } ?>
                    </select>
                    <label>Category</label>
                </div>

                <button class="btn-small waves-effect waves-light" type="submit">
                    <i class="material-icons left">send</i> Add Equipment 
                </button>
            </form>

            <h3 class="center-align">List of Equipment</h3> 

            <table class="highlight responsive-table"> 
                <thead>
                    <tr>
                    <th>Equipment Name</th> 
                    <th>Category</th>
                    <th>Action</th>
                    </tr>
                </thead>
                <tbody id="equipmentList">
                    <!-- Equipment will be listed here -->
                </tbody>
            </table>
        </div>

        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="script/add_equipment.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('select');
            var instances = M.FormSelect.init(elems);
            });
        </script>
    </body>
</html>
