<?php
include "db_connect.php";

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $task_description = $_POST['task_description'];
    $threshold_hour = $_POST['threshold_hour'];
    $task_id = $_POST['task_id'];

    $stmt = $conn->prepare("UPDATE tasks SET task_description=?, threshold_hour=? WHERE task_id=?");
    $stmt->bind_param("sii", $task_description, $threshold_hour, $task_id);
    
    if ($stmt->execute()) {
        header("Location: rh_tasks.php?success=1"); // Redirect to your list page or wherever you want after editing
        exit;
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $stmt->close();
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM tasks WHERE task_id = $id";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $task = $result->fetch_assoc();
    } else {
        die("Task not found with ID: $id");
    }
} else {
    die("ID is required to edit the task.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Task</title>
    <link rel="stylesheet" href="styles/rh_general_style.css">
</head>
<body>
<div class="container">
    <h1>Edit Task</h1>
    <form action="" method="POST" class="form-style">
        <input type="hidden" name="task_id" value="<?php echo $task['task_id']; ?>">
        
        <div class="form-group">
            <label for="task_name">Task Description:</label>
            <input type="text" name="task_description" value="<?php echo $task['task_description']; ?>" required>
        </div>

        <div class="form-group">
            <label for="task_type">Threshold Hour:</label>
            <input type="text" name="threshold_hour" value="<?php echo $task['threshold_hour']; ?>">
        </div>
        <div style="display: flex; justify-content: space-between; margin-top: 10px;">
            <input type="submit" class="submit-button" value="Update Equipment" style="margin: 10px;">
            <a href="rh_tasks.php" class="cancel-button" style="text-align: center; text-decoration: none; margin: 10px; display: inline-block; background-color: red; padding: 10px;">Cancel</a>
        </div>

        <!-- <input type="submit" class="submit-button" value="Update Equipment">
        <a href="rh_tasks.php" class="submit-button" style="text-align: center; display: inline-block; background-color: red;">Cancel</a> -->
    </form>
</div>
</body>
</html>
