<?php
session_start();

include 'db_connect.php' ;

$vessel_id = isset($_GET['vessel_id']) ? $_GET['vessel_id'] : null;
if ($vessel_id === null) {
    // Handle the case where vessel_id is not set
    // Maybe redirect back or show an error message
}

if (!isset($_SESSION['user_id'])) {
    die("You need to login.");
}
$userId = $_SESSION['user_id'];

function userHasPermission($desiredPermission, $userId, $conn) {
    $query = "SELECT permission_name FROM user_permissions INNER JOIN permissions ON user_permissions.permission_id = permissions.permission_id WHERE user_permissions.user_id = ?";
    
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $userId);
    mysqli_stmt_execute($stmt);
    
    $result = mysqli_stmt_get_result($stmt);
    $permissions = []; 
    while ($row = mysqli_fetch_assoc($result)) {
        if (strcasecmp($row['permission_name'], $desiredPermission) == 0) {
            return true; // found the permission, return true
        }
    }
    
    error_log("User ID: $userId, Permissions: " . implode(', ', $permissions)); // I-log ang permissions
    return false; // not found permission, return false
}

if (!userHasPermission("Add Equipment", $userId, $conn)) {
    // Check if the vessel_id is present and is not empty
    if (isset($_GET['vessel_id']) && !empty($_GET['vessel_id'])) {
        $vessel_id = $_GET['vessel_id'];
        echo "<script>alert('Sorry, you don\'t have permission for this.'); window.location.href='vessel_maintenance.php?id=$vessel_id';</script>";
    } else {
        // If there's no vessel_id, redirect to a page where the user can choose a vessel
        echo "<script>alert('Vessel ID is missing or you do not have permission.'); window.location.href='vessel_maintenance.php';</script>";
    }
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Equipment | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/add_equipment_vessel_style.css">
</head>

<body>
<?php include 'header.php'; ?>
    <div>
        <h5>Select Equipment to Add</h5>
    </div>
<!-- ************************************** -->
    <main class="add-equipment-container">
<!-- ************************************** -->
    
        
        <form action="confirm_selections.php" method="post">
            <ul class="collapsible">
                <?php
                $sql = "SELECT DISTINCT category FROM equipment_table ORDER BY category";
                $categories = $conn->query($sql);
                
                foreach($categories as $category) {
                    echo '<li>';
                    echo '<div class="collapsible-header">' . $category['category'] . '</div>';
                    echo '<div class="collapsible-body"><span>';

                    $equipments = $conn->query("SELECT * FROM equipment_table WHERE category = '" . $category['category'] . "' ORDER BY equipment_name");
                    foreach($equipments as $equipment) {
                        echo '<p>';
                        echo '<label>';
                        echo '<input type="checkbox" name="equipment[]" value="' . $equipment['equipment_id'] . '">';
                        echo '<span>' . $equipment['equipment_name'] . '</span>';
                        echo '</label>';
                        echo '</p>';
                    }

                    echo '</span></div>';
                    echo '</li>';
                }
                ?>
            </ul>

            <input type="hidden" name="vessel_id" value="<?php echo htmlspecialchars($vessel_id); ?>">
            <button type="submit" class="btn-small waves-effect waves-light"><i class="material-icons left">add</i>Add Equipment to Vessel</button>
            <a href="vessel_maintenance.php?id=<?php echo htmlspecialchars($vessel_id); ?>" class="btn-small waves-effect waves-light"><i class="material-icons left">arrow_back</i>Back to Vessel Details</a>
        </form>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.collapsible');
            var instances = M.Collapsible.init(elems);
        });

    </script>
</body>

</html>
