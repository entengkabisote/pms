<?php
include 'db_connect.php';
include 'fetch_data.php';

$vessel_id = $_GET['vessel_id'];
$equipment_name = $_GET['equipment_name'];
$threshold_hour = $_GET['threshold_hour'];
$selected_month = $_GET['selected_month'];
$monthName = date('F', mktime(0, 0, 0, $selected_month, 10));
$daysInMonth = cal_days_in_month(CAL_GREGORIAN, $selected_month, date("Y"));


$tableData = fetchTableData($vessel_id, $equipment_name, $threshold_hour);
$vessel_name = getVesselName($vessel_id);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Planned Maintenance</title>
    <link rel="stylesheet" href="styles/preview_style.css">
</head>
<body>
    <table border="1">
        <tr>
            <td class="no-border">
                Vessel : <?php echo $vessel_name; ?><br>
                Month : <?php echo $monthName; ?><br>
                Machinery : <?php echo $equipment_name; ?><br>
                Threshold Hour : <?php echo $threshold_hour; ?>
            </td>
        </tr>
        <tr>
            <td colspan="5">TASK</td>
            <?php
            for ($i = 1; $i <= $daysInMonth; $i++) {
                echo '<td class="day-column">' . $i . '</td>';
            }
            ?>
            <td class="rh-column">End of the Month Total RH</td>
            <td class="rh-column">Overall Total RH</td>
            <td class="rh-column">Remarks</td>
        </tr>

        
        <?php
        // Assuming $tableData contains your tasks
        foreach ($tableData as $task) {
            echo '<tr>';
            echo '<td colspan="5">' . $task['task_description'] . '</td>';
            // Insert your day data dynamically here
            for ($i = 1; $i <= $daysInMonth; $i++) {
                echo '<td></td>';
            }
            echo '<td></td>';
            echo '<td></td>';
            echo '<td></td>';
            echo '</tr>';
        }
        ?>
    </table>

    <div class=print-button >
        <a href="print_rh.php?id=<?php echo $vessel_id; ?>" class="btn-small waves-effect waves-light"><i class="material-icons left">arrow_back</i>Back to Vessel Details</a>
        <button class="btn-small waves-effect waves-light" onclick="window.print()">Print</button>
    </div>
</body>
</html>

