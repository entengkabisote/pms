<?php

include 'db_connect.php';
require 'vendor/autoload.php';
use Knp\Snappy\Pdf;

// Define the path to wkhtmltopdf
$wkhtmltopdfPath = '"C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe"';


$snappy = new Pdf($wkhtmltopdfPath);

$vessel_id = $_GET['vessel_id'];
$category = $_GET['category'];

// Run SQL query here and get data
$sql = "SELECT * FROM vessel_equipment 
        INNER JOIN equipment_table ON vessel_equipment.equipment_id = equipment_table.equipment_id
        INNER JOIN inspection_meta_table ON vessel_equipment.inspection_meta_id = inspection_meta_table.meta_id
        WHERE vessel_id = ? AND category = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $vessel_id, $category);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_all(MYSQLI_ASSOC);

// Generate HTML content for PDF
$html = '<h1>Vessel Equipment Inspection Report</h1>';

$html = '<style>
            table {
                border-collapse: collapse;
                font-size: 14px;
            }
            th, td {
                padding: 8px 12px;
                border: 1px solid #ddd;
            }
            th {
                background-color: #f2f2f2;
            }
        </style>' . $html;

$currentEquipment = null;

foreach ($data as $entry) {
    if ($currentEquipment !== $entry['equipment_name']) {
        $html .= "<h2>Equipment Name: {$entry['equipment_name']}</h2>";
        $html .= '<table border="1" cellpadding="5" cellspacing="0" style="width:100%;">';
        $html .= '<thead>
                    <tr>
                      <th>Interval of Checks/Testing</th>
                      <th>Person in Charge</th>
                      <th>Criticality</th>
                      <th>1st</th>
                      <th>2nd</th>
                      <th>3rd</th>
                      <th>4th</th>
                      <th>Remarks</th>
                    </tr>
                  </thead>
                  <tbody>';
        $currentEquipment = $entry['equipment_name'];
    }

    $html .= '<tr>';
    $html .= "<td>{$entry['inspection_type']}</td>";
    $html .= "<td>{$entry['inspection_interval']}</td>";
    $html .= "<td>{$entry['person_in_charge']}</td>";
    $html .= "<td>{$entry['criticality']}</td>";
    $html .= '<td></td>'; // 1st Inspection Date
    $html .= '<td></td>'; // 2nd Inspection Date
    $html .= '<td></td>'; // 3rd Inspection Date
    $html .= '<td></td>'; // 4th Inspection Date
    $html .= '<td></td>'; // Remarks
    $html .= '</tr>';
}

$html .= '</tbody></table>'; // Close the table structure

// // Generate HTML content for PDF
// $html = '<h1>Vessel Equipment Inspection Report</h1>';

// $currentEquipment = null;

// foreach ($data as $entry) {
//     if ($currentEquipment !== $entry['equipment_name']) {
//         $html .= "<h2>Equipment Name: {$entry['equipment_name']}</h2>";
//         $currentEquipment = $entry['equipment_name'];
//     }

//     $html .= "<p>Inspection Type: {$entry['inspection_type']}</p>";
//     $html .= "<p>Inspection Interval: {$entry['inspection_interval']}</p>";
//     $html .= "<p>Person in Charge: {$entry['person_in_charge']}</p>";
//     $html .= "<p>Criticality: {$entry['criticality']}</p>";
// }



// Define the path where you want to save the PDF
$outputPath = 'C:\\wamp64\\www\\plannedmaintenance\\pdf\\equipment_inspection.pdf';

// Generate and save the PDF to the specified path
$snappy->generateFromHtml($html, $outputPath);

// You can add a message or log to confirm the PDF was saved
echo "PDF generated and saved to " . $outputPath;

// /// Set HTTP headers for PDF
// header('Content-Type: application/pdf');
// header('Content-Disposition: inline; filename="equipment_inspection.pdf"');


// Generate and output the PDF
echo $snappy->getOutputFromHtml($html);
