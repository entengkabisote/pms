<?php
include "connection.php";
session_start();


$vessel_id = $_GET['vessel_id'];  // Gets the vessel_id from URL

// Fetch vessel name
$sql = "SELECT vessel_name FROM vessels WHERE id = $vessel_id";
$vesselResult = $conn->query($sql);
$vesselName = $vesselResult->fetch_assoc()['vessel_name'];


// bagong query
$query = "SELECT ve.equipment_id, ve.task_id, re.equipment_type, re.equipment_name, t.task_description, t.threshold_hour
          FROM vessel_rh_equipment ve
          JOIN rh_equipments re ON ve.equipment_id = re.equipment_id
          LEFT JOIN tasks t ON ve.task_id = t.task_id
          WHERE ve.vessel_id = $vessel_id
          ORDER BY re.equipment_type, re.equipment_name, t.threshold_hour";


$result = $conn->query($query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Equipment and Tasks for <?php echo $vesselName; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/foundation/6.7.3/css/foundation.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/foundation-sites@6.6.3/dist/js/foundation.min.js"></script>

    <link rel="stylesheet" href="styles/rh_vessel.css">
    <style>
        tr.primary td {
        padding-top: 20px;
        }
    </style>
</head>
<body>
    <div class="grid-container">
        <div class="grid-x grid-padding-x">
            <div class="medium-12 cell">
                <h1 class="text-center">Vessel Name: <?php echo $vesselName; ?></h1>
                <div style="float: left;">
                    <a href="running_hours_vessel.php" class="button">Back to Vessel List</a>
                </div>
                <div style="float: right;">
                    <button id="saveInputs" class="button" form="myForm">Save Inputs</button>
                </div>

                <?php

                    $equipmentDataArray = [];  

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $equipmentDataArray[$row['equipment_type']][$row['equipment_name']][] = $row;
                        }
                    }

                                        
                    if(empty($equipmentDataArray)) {
                      echo "<p>No linked equipment or tasks found.</p>";
                    } else {
                        function sortEquipment($a, $b) {
                            $order = ['engine', 'gearbox', 'z-peller', 'auxiliary'];
                            $nameA = preg_replace('/\d/', '', strtolower($a));
                            $nameB = preg_replace('/\d/', '', strtolower($b));
                        
                            $posA = array_search($nameA, $order);
                            $posB = array_search($nameB, $order);
                        
                            if ($posA === $posB) {
                                return preg_replace('/\D/', '', $a) <=> preg_replace('/\D/', '', $b);
                            }
                        
                            return $posA <=> $posB;
                        }
                    }
                    // Sort the keys bases in custom function
                    uksort($equipmentDataArray, 'sortEquipment');
                ?>
                <!-- <form id="myForm" action="" method="post"> -->
                <form id="myForm" action="handle_form_submission.php" method="post">
                <input type="hidden" name="vessel_id" value="<?php echo $vessel_id; ?>">
                    <table class="hover">
                        <thead>
                            <tr>
                                <th>Equipment Type</th>
                                <th>Equipment Name</th>
                                <th>Task</th>
                                <th>Threshold Hour</th>
                                <th>Date</th>
                                <th>Running Hours</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                // Custom sorting function
                                function sortEquipmentType($equipmentDataArray) {
                                    $order = ['Primary', 'Secondary', 'Generator 1', 'Generator 2', 'Others'];
                                    $sortedData = [];

                                    foreach ($order as $type) {
                                        foreach ($equipmentDataArray as $equipment_name => $data) {
                                            $equipment_type = determineEquipmentType($equipment_name);
                                            if ($equipment_type === $type) {
                                                $sortedData[$equipment_name] = $data;
                                            }
                                        }
                                    }
                                    return $sortedData;
                                }

                                // Function to determine equipment_type
                                function determineEquipmentType($equipment_name) {
                                    if (preg_match('/(engine 1|gearbox 1|z-peller 1)/i', $equipment_name)) {
                                        return "Primary";
                                    } elseif (preg_match('/(engine 2|gearbox 2|z-peller 2)/i', $equipment_name)) {
                                        return "Secondary";
                                    } elseif (preg_match('/auxiliary A/i', $equipment_name)) {
                                        return "Generator 1";
                                    } elseif (preg_match('/auxiliary B/i', $equipment_name)) {
                                        return "Generator 2";
                                    } else {
                                        return "Others";
                                    }
                                }

                                $equipmentDataArray = sortEquipmentType($equipmentDataArray);
                                $addedTypes = [];

                                foreach ($equipmentDataArray as $equipment_type => $equipment_names) {
                                    echo "<tr class='primary'><td colspan='4'><strong>$equipment_type</strong></td>";
                                    echo "<td><input type='date' name='date[$equipment_type]'></td><td><input type='number' name='running_hours[$equipment_type]' step='any'></td></tr>";
                                    foreach ($equipment_names as $equipment_name => $tasks) {
                                        echo "<tr><td>&nbsp;</td><td colspan='2'><strong>$equipment_name</strong></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>";
                                        foreach ($tasks as $task) {
                                            $task_desc = isset($task['task_description']) ? $task['task_description'] : 'N/A';
                                            $threshold_hour = isset($task['threshold_hour']) ? $task['threshold_hour'] : 'N/A';
                                            echo "<tr><td>&nbsp;</td><td>&nbsp;</td><td>$task_desc</td><td>$threshold_hour</td><td>&nbsp;</td><td>&nbsp;</td></tr>";
                                        }
                                    }
                                }
                                
                            ?>
                        </tbody>
                    </table>
                </form>
            </div>
        </div>
    </div>
    
    
    <script>

    <?php if (isset($_SESSION['message'])): ?>
    alert("<?php echo $_SESSION['message']; ?>");

    <?php unset($_SESSION['message']); ?>
    <?php endif; ?>


        $(document).foundation();
    </script>
</body>
</html>
