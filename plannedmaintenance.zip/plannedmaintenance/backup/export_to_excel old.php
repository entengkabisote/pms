<?php
require 'vendor/autoload.php';
include 'db_connect.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
// $sheet->setCellValue('A1', 'Hello World !');
// Set headers for the Excel sheet
$sheet->setCellValue('A1', 'Equipment Name');
$sheet->setCellValue('B1', 'Interval');
$sheet->setCellValue('C1', 'Person in Charge');
$sheet->setCellValue('D1', 'Criticality');
// ... add more headers if needed

$vessel_id = $_GET['vessel_id'];
$category = $_GET['category'];

$sql = "SELECT * FROM vessel_equipment 
        INNER JOIN equipment_table ON vessel_equipment.equipment_id = equipment_table.equipment_id
        INNER JOIN inspection_meta_table ON vessel_equipment.inspection_meta_id = inspection_meta_table.meta_id
        WHERE vessel_id = ? AND category = ?";
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="equipment_inspection.xlsx"');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
?>
