<?php
session_start();

if(isset($_SESSION['equipment_added']) && $_SESSION['equipment_added']) {
    echo "<div class='callout success' style='width: 400px; margin: 20px auto;'>Equipment added successfully!</div>";
    
    // Unset the session variable immediately after displaying the message
    unset($_SESSION['equipment_added']);
}

if (isset($_SESSION['equipment_exists']) && $_SESSION['equipment_exists']) {
    echo "<div class='callout warning' style='width: 400px; margin: 20px auto;'>Equipment name already exists!</div>";
    unset($_SESSION['equipment_exists']);
}
include "db_connect.php";

// $groups = [];

// // Fetch groups from the database
// $query = "SELECT * FROM equipment_groups ORDER BY group_id ASC";
// $result = $conn->query($query);
// if ($result->num_rows > 0) {
//     while($row = $result->fetch_assoc()) {
//         $groups[] = $row;
//     }
// }


$equipments_list = [];
$query = "SELECT * FROM rh_equipments";
$result = $conn->query($query);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $equipments_list[] = $row;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Equipment</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/foundation/6.7.3/css/foundation.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/foundation/6.7.3/js/foundation.min.js"></script>
<link rel="stylesheet" href="styles/rh_general_style.css">

</head>
<body>

<div class="grid-container">


    <div class="grid-x grid-padding-x">
        <div class="medium-6 cell medium-offset-3">
            <h1>Add New Equipment</h1>

            <form action="add_equipment_rh.php" method="POST">
                <label for="equipment_name">Equipment Name:
                    <input type="text" name="equipment_name" required placeholder="Example: Engine 1, Gearbox 1, Z-peller 1, Auxiliary 1">
                </label>

                <label for="equipment_type">Equipment Type:
                    <input type="text" name="equipment_type" required>
                </label>

                <input type="submit" class="button" value="Add Equipment">
            </form>

        </div>
    </div>
    <div class="medium-12 cell">
        <h2>Existing Equipments</h2>
        <table>
            <thead>
                <tr>
                    <th class="col-equip-id">ID</th>
                    <th class="col-equip-name">Equipment Name</th>
                    <th class="col-equip-type">Equipment Type</th>
                    <th class="col-actions">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($equipments_list as $equipment): ?>
                <tr>
                    <td><?php echo $equipment['equipment_id']; ?></td>
                    <td><?php echo $equipment['equipment_name']; ?></td>
                    <td ><?php echo $equipment['equipment_type']; ?></td>
                    <td class="action-buttons">
                        <a href="edit_equipment_rh.php?id=<?php echo $equipment['equipment_id']; ?>" class="button tiny floating-btn ">Edit</a>
                        <a href="delete_equipment.php?id=<?php echo $equipment['equipment_id']; ?>" class="button alert tiny delete-btn floating-btn " onclick="return confirm('Are you sure you want to delete this?');">Delete</a>

                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>



<script>
    $(document).foundation();

    setTimeout(function() {
        $('.callout').fadeOut('slow');
    }, 1500);  // 1500ms or 1.5 seconds

    
</script>


</body>
</html>
