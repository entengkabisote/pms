<?php
session_start();
// if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
//     header('Location: login.php');
//     exit;
// }

include 'db_connect.php';  // Koneksyon sa database
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/styles.css">   
    <!-- <style>
        .ship-card {
            transition: 0.3s;
        }

        .ship-card:hover {
            box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
        }

        .ship-card img {
            width: 80%;
            height: 150px;
            object-fit: cover;
        }

        .search-bar {
            margin-bottom: 30px;
        }
    </style> -->
</head>

<body>
    <div class="logo-header">
        <img src="images/smscorp.png" alt="Company Logo" class="logo">
        <h4 class="white-text">Strategic Maritime Solutions Corp.</h4>
    </div>

    <nav class="blue-grey darken-2">
        <div class="nav-wrapper container">
            <ul class="center-align">
                <li><a href="dashboard.html" class="white-text">Dashboard</a></li>
                <li><a href="ships.html" class="white-text">Ships</a></li>
                <li><a href="equipment.html" class="white-text">Equipments</a></li>
                <!-- <li><a href="spareparts.html" class="white-text">Spare Parts</a></li> -->
                
                <!-- Dropdown Trigger -->
                <li><a class="dropdown-trigger white-text" href="#!" data-target="maintenanceDropdown">Maintenance Tasks<i class="material-icons right">arrow_drop_down</i></a></li>
                
                <li><a href="#" class="white-text">Reports</a></li>
                <li><a href="#" class="white-text">Settings</a></li>
            </ul>
    
            <!-- Dropdown Structure -->
            <ul id="maintenanceDropdown" class="dropdown-content">
                <li><a href="vessel_maintenance.html">Ship / Vessel Inspection Date</a></li>
                <li><a href="#">Running Hours of Equipment</a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
    <div class="row">
        <?php
        // Assuming you have a db connection $conn
        $query = "SELECT * FROM vessels"; 
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            while ($ship = mysqli_fetch_assoc($result)) {
                ?>
                <div class="col s12 m6 l4">
                    <div class="card">
                        <div class="card-image">
                            <img src="<?php echo $ship['image']; ?>" alt="<?php echo $ship['vessel_name']; ?>">
                            <span class="card-title"><?php echo $ship['vessel_name']; ?></span>
                        </div>
                        <div class="card-content">
                            <!-- <p>Detalye o description tungkol sa vessel na ito.</p> -->
                        </div>
                        <div class="card-action">
                            <a href="#">View More</a>
                        </div>
                    </div>
                </div>
                <?php
            }
        } else {
            echo '<p>No ships found.</p>';
        }
        ?>
    </div>
</div>



    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });
        </script>
</body>

</html>
