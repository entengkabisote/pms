<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


include 'db_connect.php';

$vessel_id = $_GET['id'];  // I-assume natin na may id na pinasa from the URL
$sql = "SELECT v.vessel_id, v.equipment_id, v.date_added, m.inspection_type, m.inspection_interval, MAX(d.inspection_date) AS last_inspection
        FROM vessel_equipment v
        JOIN inspection_meta_table m ON v.inspection_meta_id = m.meta_id
        LEFT JOIN inspection_date d ON v.equipment_id = d.equipment_id AND v.inspection_meta_id = d.inspection_meta_id
        WHERE v.vessel_id = $vessel_id
        GROUP BY v.vessel_id, v.equipment_id, m.inspection_type, m.inspection_interval";





$result = $conn->query($sql);

if($result === FALSE) {
  die("SQL Error: " . $conn->error);
}

$compliance_data = [];

function getDaysThreshold($intervalType) {
    switch ($intervalType) {
        case 'daily' : return 1;
        case 'weekly': return 7;
        case 'monthly': return 30;
        case 'bi-monthly': return 60;
        case '3-months': return 90;
        case '6-months': return 180;
        case '5-years': return 1825;
        case 'yearly': return 365;
        case 'As required': return 2000;
        case 'Every 250 hours': return 10.5;
        default: return 0;
    }
}

if($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        if (is_null($row['last_inspection'])) {
            $date_added = new DateTime($row['date_added']);
            $now = new DateTime();
            $days_since_added = $now->diff($date_added)->days;
    
            switch (strtolower($row['inspection_interval'])) {
                case 'daily':
                    $status = ($days_since_added > 1) ? "Non-Compliant" : "Compliant";
                    break;
                case 'weekly':
                    $status = ($days_since_added > 7) ? "Non-Compliant" : "Compliant";
                    break;
                case 'monthly':
                    $status = ($days_since_added > 30) ? "Non-Compliant" : "Compliant";
                    break;
                case 'bi-monthly':
                    $status = ($days_since_added > 60) ? "Non-Compliant" : "Compliant";
                    break;
                case '3-months':
                    $status = ($days_since_added > 90) ? "Non-Compliant" : "Compliant";
                    break;
                case '6-months':
                    $status = ($days_since_added > 180) ? "Non-Compliant" : "Compliant";
                    break;
                case '5-years':
                    $status = ($days_since_added > 1825) ? "Non-Compliant" : "Compliant";
                    break;
                case 'yearly':
                    $status = ($days_since_added > 365) ? "Non-Compliant" : "Compliant";
                    break;
                case 'As required':
                    $status = ($days_since_added > 2000) ? "Non-Compliant" : "Compliant";
                    break;
                case 'Every 250 hours':
                    $status = ($days_since_added > 10.5) ? "Non-Compliant" : "Compliant";
                    break;
                default:
                    $status = "Compliant";
            }
        } else {
            // Existing na logic para sa may mga last_inspection
            $last_inspection_date = new DateTime($row['last_inspection']);
            $now = new DateTime();
            $interval = $last_inspection_date->diff($now)->days;
    
            // Halimbawa, kung weekly ang inspection_interval, 7 days ang threshold.
            $status = ($interval > getDaysThreshold($row['inspection_interval'])) ? "Non-Compliant" : "Compliant";
        }
    
        $compliance_data[] = [
            'equipment_id' => $row['equipment_id'],
            'inspection_type' => $row['inspection_type'],
            'inspection_interval' => $row['inspection_interval'],
            'date_added' => $row['date_added'],
            'last_inspection' => $row['last_inspection'],
            'status' => $status
        ];
    }
    
    
    
}

$conn->close();
?>



<!DOCTYPE html>
<html>
<head>
  <title>Compliance Report</title>
</head>
<body>

<h1>Compliance Report</h1>

<table>
  <thead>
    <tr>
      <th>Equipment ID</th>
      <th>Inspection Type</th>
      <th>Inspection Interval</th>
      <th>Date Added</th>
      <th>Last Inspection</th>
      <th>Status</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach($compliance_data as $data): ?>
        <tr data-equipment-id="<?= $data['equipment_id'] ?>">
        <!-- <td><?= $data['equipment_id'] ?></td> -->
        <td><?= $data['inspection_type'] ?></td>
        <td><?= $data['inspection_interval'] ?></td>
        <td><?= $data['date_added'] ?></td>
        <td><?= $data['last_inspection'] ?></td>
        <td><?= $data['status'] ?></td> <!-- Compliant or Non-Compliant -->
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>

</body>
</html>
