<?php
// Database connection
include "db_connect.php";

// Fetch unique vessel IDs from vessel_rh_equipment table
$query = "SELECT DISTINCT vessel_id FROM vessel_rh_equipment";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
  <title>List of Vessels</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/foundation-sites@6.6.3/dist/css/foundation.min.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <link rel="stylesheet" href="styles/rh_vessel.css">
</head>
<body>

<div class="grid-container">
    <div class="grid-x grid-padding-x center-content">
        <div class="medium-6 cell medium-offset-3">
            <h1 class="center-content">Vessels with Linked Equipment and Tasks</h1>
        
            <div class="vessel-list-box">
                <ul class="menu vertical no-bullet">
                    <?php while($row = mysqli_fetch_assoc($result)): ?>
                    <?php
                    // Fetch vessel name using the vessel_id
                    $vessel_id = $row['vessel_id'];
                    $vessel_query = "SELECT vessel_name FROM vessels WHERE id = $vessel_id";
                    $vessel_result = mysqli_query($conn, $vessel_query);
                    $vessel_row = mysqli_fetch_assoc($vessel_result);
                    ?>
                    <li>
                        <a href="view_vessel_rh_details.php?vessel_id=<?php echo $vessel_id; ?>" class="clickable-vessel">
                        <?php echo $vessel_row['vessel_name']; ?>
                        </a>
                    </li>
                    <?php endwhile; ?>
                </ul>
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/foundation-sites@6.6.3/dist/js/foundation.min.js"></script>
</body>
</html>

