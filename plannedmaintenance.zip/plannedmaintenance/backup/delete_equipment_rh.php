<?php
include "connection.php";

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "DELETE FROM rh_equipments WHERE equipment_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: equipment_running_hours.php?delete_success=1");
    } else {
        echo "Error: " . $conn->error;
    }

    $stmt->close();
}
?>
