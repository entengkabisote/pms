<?php
include "db_connect.php";
session_start();

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['message'] = 'Invalid request method.';
    header('Location: view_vessel_rh_details.php');
    exit();
}

// Retrieve the vessel_id
$vessel_id = $_POST['vessel_id'] ?? null;
$dateArray = $_POST['date'] ?? [];
$running_hoursArray = $_POST['running_hours'] ?? [];

// Validate vessel_id
if (empty($vessel_id)) {
    $_SESSION['message'] = 'Vessel ID is missing.';
    header('Location: view_vessel_rh_details.php');
    exit();
}

// Start transaction
$conn->begin_transaction(MYSQLI_TRANS_START_READ_WRITE);
$errorOccurred = false;
$hasDuplicate = false;
$insertValues = [];

// Loop through each equipment_type and process if there is data
foreach ($running_hoursArray as $equipment_type => $timeArray) {
    if (empty($timeArray['hours']) && empty($timeArray['minutes'])) {
        // Skip this equipment type because it doesn't have hours or minutes input.
        continue;
    }

    $hours = $timeArray['hours'] ?? 0;
    $minutes = $timeArray['minutes'] ?? 0;
    $date = $dateArray[$equipment_type] ?? '';

    // Validate the input.
    if (!is_numeric($hours) || !is_numeric($minutes) || $minutes < 0 || $minutes >= 60 || empty($date)) {
        // Set an error message if validation fails.
        $_SESSION['message'] = "Invalid or missing data for $equipment_type.";
        $errorOccurred = true;
        break;
    }

    // Convert to decimal hours.
    $hours = (int)$hours;
    $minutes = (int)$minutes;
    $decimalHours = $hours + ($minutes / 60);
    
    // Get the related data for the vessel and equipment type.
    $equipmentData = getEquipmentData($conn, $vessel_id, $equipment_type);

    // Assuming processEquipmentType() function signature is as follows:
    // processEquipmentType($conn, $data, $equipment_type, $date, $decimalHours, $vessel_id, $insertValues, $hasDuplicate)
    processEquipmentType($conn, $equipmentData, $equipment_type, $date, $decimalHours, $vessel_id, $insertValues, $hasDuplicate);
}

if (!$errorOccurred && !$hasDuplicate) {
    // Call handleFinalActions if there are no errors and no duplicates
    handleFinalActions($conn, $vessel_id, $insertValues, $hasDuplicate);
    $_SESSION['message'] = 'Data successfully saved.';
    $conn->commit();
} else {
    // Rollback the transaction in case of errors or duplicates
    $conn->rollback();
    if (!$errorOccurred && $hasDuplicate) {
        // Specific message if the error was due to duplicates
        $_SESSION['message'] = 'Some records already exist and were not saved.';
    }
}

// Close the database connection
$conn->close();

header("Location: view_vessel_rh_details.php?vessel_id=$vessel_id");
exit();


// Helper Functions

function getVesselData($conn, $vessel_id) {
    $stmt = $conn->prepare("SELECT ve.equipment_id, ve.task_id, re.equipment_type, re.equipment_name, t.task_description, t.threshold_hour FROM vessel_rh_equipment ve JOIN rh_equipments re ON ve.equipment_id = re.equipment_id LEFT JOIN tasks t ON ve.task_id = t.task_id WHERE ve.vessel_id = ?");
    $stmt->bind_param("i", $vessel_id);
    $stmt->execute();
    $data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $data;
}

function processEquipmentType($conn, $data, $equipment_type, $date, $running_hours, $vessel_id, &$insertValues, &$hasDuplicate) {
    foreach ($data as $row) {
        if ($row['equipment_type'] != $equipment_type) continue;

        if (!isDuplicateEntry($conn, $row, $vessel_id, $date, $equipment_type)) {
            $insertValues[] = buildInsertValue($row, $vessel_id, $date, $running_hours, $equipment_type);
            updateRunningHours($conn, $row, $date, $running_hours, $vessel_id);
            updateStatus($conn, $row, $running_hours, $vessel_id);
        } else {
            $hasDuplicate = true;
        }
    }
}

function isDuplicateEntry($conn, $row, $vessel_id, $date, $equipment_type) {
    $stmt = $conn->prepare("SELECT * FROM running_hours_entries WHERE vessel_id = ? AND date = ? AND equipment_type = ? AND task_id = ? AND threshold_hours = ? AND equipment_name = ?");
    $stmt->bind_param("isssis", $vessel_id, $date, $equipment_type, $row['task_id'], $row['threshold_hour'], $row['equipment_name']);
    $stmt->execute();
    $result = $stmt->get_result()->num_rows > 0;
    $stmt->close();
    return $result;
}

function buildInsertValue($row, $vessel_id, $date, $running_hours, $equipment_type) {
    return "($vessel_id, {$row['equipment_id']}, '$date', $running_hours, '$equipment_type', {$row['task_id']}, {$row['threshold_hour']}, '{$row['equipment_name']}')";
}


function updateRunningHours($conn, $row, $date, $running_hours, $vessel_id) {
    // Kunin ang current total_running_hours, total_life_rh, at remarks
    $stmt = $conn->prepare("SELECT total_running_hours, total_life_rh, remarks FROM vessel_rh_equipment WHERE vessel_id = ? AND equipment_id = ? AND task_id = ?");
    $stmt->bind_param("iii", $vessel_id, $row['equipment_id'], $row['task_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();
    $current_running_hours = isset($data['total_running_hours']) ? $data['total_running_hours'] : 0;
    $current_life_hours = isset($data['total_life_rh']) ? $data['total_life_rh'] : 0; // Kunin ang current total_life_rh
    $current_remarks = isset($data['remarks']) ? $data['remarks'] : 'No remarks';
    $stmt->close();

    // I-calculate ang bagong total_running_hours, total_life_rh, at remaining_hours
    $new_total_running_hours = bcadd($current_running_hours, $running_hours, 3);
    $new_life_hours = bcadd($current_life_hours, $running_hours, 3); // I-update ang total_life_rh
    $remaining_hours = $row['threshold_hour'] - $new_total_running_hours;

    // Set ang remarks
    $remarks = ($current_running_hours == 0 && $new_total_running_hours > 0) ? 'Initial Link' : $current_remarks;

    // I-update ang database
    $stmt = $conn->prepare("UPDATE vessel_rh_equipment SET date_modified = ?, total_running_hours = ?, total_life_rh = ?, remaining_hours = ?, remarks = ? WHERE vessel_id = ? AND equipment_id = ? AND task_id = ?");
    $stmt->bind_param("sdddsiii", $date, $new_total_running_hours, $new_life_hours, $remaining_hours, $remarks, $vessel_id, $row['equipment_id'], $row['task_id']);
    if (!$stmt->execute()) {
        // Handle error here
        echo "Error updating running hours and total life running hours: " . $stmt->error;
    }
    $stmt->close();
}



// function updateRunningHours($conn, $row, $date, $running_hours, $vessel_id) {
//     // Kunin ang current total_running_hours at remarks
//     $stmt = $conn->prepare("SELECT total_running_hours, remarks FROM vessel_rh_equipment WHERE vessel_id = ? AND equipment_id = ? AND task_id = ?");
//     $stmt->bind_param("iii", $vessel_id, $row['equipment_id'], $row['task_id']);
//     $stmt->execute();
//     $result = $stmt->get_result();
//     $data = $result->fetch_assoc();
//     $current_running_hours = isset($data['total_running_hours']) ? $data['total_running_hours'] : 0;
//     // I-set ang default value ng remarks sa current value, kung wala man ito ay 'No remarks'.
//     $current_remarks = isset($data['remarks']) ? $data['remarks'] : 'No remarks';
//     $stmt->close();

//     // I-calculate ang bagong total_running_hours at remaining_hours
//     $new_total_running_hours = bcadd($current_running_hours, $running_hours, 3);  // 2 decimal places
//     $remaining_hours = $row['threshold_hour'] - $new_total_running_hours;

//     // Set ang remarks sa 'Initial Link' kung 0 ang current_running_hours at hindi 0 ang new_total_running_hours
//     $remarks = ($current_running_hours == 0 && $new_total_running_hours > 0) ? 'Initial Link' : $current_remarks;

//     // I-update ang database
//     $stmt = $conn->prepare("UPDATE vessel_rh_equipment SET date_modified = ?, total_running_hours = ?, remaining_hours = ?, remarks = ? WHERE vessel_id = ? AND equipment_id = ? AND task_id = ?");
//     $stmt->bind_param("sddsiii", $date, $new_total_running_hours, $remaining_hours, $remarks, $vessel_id, $row['equipment_id'], $row['task_id']);
//     if (!$stmt->execute()) {
//         // Handle error here
//         echo "Error updating running hours: " . $stmt->error;
//     }
//     $stmt->close();
// }

function updateStatus($conn, $row, $running_hours, $vessel_id) {
    // Calculate new status here based on running hours...
    $status = calculateStatus($conn, $row, $running_hours, $vessel_id);
    $stmt = $conn->prepare("UPDATE vessel_rh_equipment SET status = ? WHERE vessel_id = ? AND equipment_id = ? AND task_id = ?");
    $stmt->bind_param("siii", $status, $vessel_id, $row['equipment_id'], $row['task_id']);
    $stmt->execute();
    $stmt->close();
}

function calculateStatus($conn, $row, $running_hours, $vessel_id) {
    // Your logic to calculate status based on total running hours...
    
    $totalHoursStmt = $conn->prepare("SELECT total_running_hours FROM vessel_rh_equipment WHERE vessel_id = ? AND task_id = ?");
    $totalHoursStmt->bind_param("ii", $vessel_id, $row['task_id']);
    $totalHoursStmt->execute();
    $result = $totalHoursStmt->get_result();
    $existingTotalRunningHours = 0;

    if ($resultRow = $result->fetch_assoc()) {
        $existingTotalRunningHours = $resultRow['total_running_hours'];
    }
    $totalHoursStmt->close();

    $newTotalRunningHours = $existingTotalRunningHours + $running_hours;
    $threshold_hours = $row['threshold_hour'];

    if ($newTotalRunningHours < 0.7 * $threshold_hours) {
        return "On Track";
    } elseif ($newTotalRunningHours >= 0.7 * $threshold_hours && $newTotalRunningHours <= $threshold_hours) {
        return "Due Soon";
    } else {
        return "Over Due";
    }
}


function handleFinalActions($conn, $vessel_id, $insertValues, $hasDuplicate) {
    if (!$hasDuplicate) {
        if (!empty($insertValues)) {
            $insertQuery = "INSERT INTO running_hours_entries (vessel_id, equipment_id, date, running_hours, equipment_type, task_id, threshold_hours, equipment_name) VALUES " . implode(",", $insertValues);
            $conn->query($insertQuery);
        }
        $conn->commit();
        $_SESSION['message'] = 'Records successfully saved.';
    } else {
        $conn->rollback();
        $_SESSION['message'] = 'Some records already exist and were not saved.';
    }
    header('Location: view_vessel_rh_details.php?vessel_id=' . $vessel_id);
}

?>
