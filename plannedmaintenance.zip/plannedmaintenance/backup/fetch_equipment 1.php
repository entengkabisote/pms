<?php
include 'db_connect.php';

$vessel_id = $_GET['vessel_id'];
$category = $_GET['category'];

// Fetch equipment based on vessel_id and category
$sql = "SELECT * FROM vessel_equipment 
        INNER JOIN equipment_table ON vessel_equipment.equipment_id = equipment_table.equipment_id
        WHERE vessel_id = ? AND category = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $vessel_id, $category);
$stmt->execute();
$result = $stmt->get_result();
?>

<!-- HTML for the table -->
<table border="1">
    <tr>
        <th><?php echo $category; ?></th>
        <th>Interval of Checks / Testing</th>
        <th>Person in Charge</th>
        <th>Criticality</th>
    </tr>
    <?php 
        $lastEquipmentName = ""; // variable to hold the last displayed equipment name
        while ($row = $result->fetch_assoc()): 
            $currentEquipmentName = $row['equipment_name'];
    ?>
        <?php if ($currentEquipmentName != $lastEquipmentName): ?>
        <tr>
            <td><?php echo $currentEquipmentName; ?></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
    <?php endif; ?>
    <?php
    // Update the last displayed equipment name
    $lastEquipmentName = $currentEquipmentName;
    
        // Fetch inspections for this equipment
        $sql_inspection = "SELECT * FROM inspection_meta_table WHERE equipment_id = ?";
        $stmt_inspection = $conn->prepare($sql_inspection);
        $stmt_inspection->bind_param("i", $row['equipment_id']);
        $stmt_inspection->execute();
        $result_inspection = $stmt_inspection->get_result();
        while ($row_inspection = $result_inspection->fetch_assoc()):
        ?>
            <tr>
                <td><?php echo $row_inspection['inspection_type']; ?></td>
                <td><?php echo $row_inspection['inspection_interval']; ?></td>
                <td><?php echo $row_inspection['person_in_charge']; ?></td>
                <td><?php echo $row_inspection['criticality']; ?></td>
            </tr>
        <?php endwhile; ?>
    <?php endwhile; ?>
</table>
