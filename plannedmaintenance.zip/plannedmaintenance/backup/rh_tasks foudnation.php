<?php
session_start();

if(isset($_SESSION['task_added']) && $_SESSION['task_added']) {
    echo "<div class='callout success' style='width: 400px; margin: 20px auto;'>Task added successfully!</div>";
    
    // Unset the session variable immediately after displaying the message
    unset($_SESSION['task_added']);
}

if (isset($_SESSION['task_exists']) && $_SESSION['task_exists']) {
    echo "<div class='callout warning' style='width: 400px; margin: 20px auto;'>Task description already exist!</div>";
    unset($_SESSION['task_exists']);
}

include "db_connect.php";

$equipments = [];

// Fetch groups from the database
$query = "SELECT * FROM rh_equipments ORDER BY equipment_id ASC";
$result = $conn->query($query);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $equipments[] = $row;
    }
}

$tasks = [];

// Fetch tasks from the database
$query_tasks = "SELECT rh_equipments.equipment_name, tasks.task_description, tasks.threshold_hour, tasks.task_id FROM tasks INNER JOIN rh_equipments ON tasks.equipment_id = rh_equipments.equipment_id";
$result_tasks = $conn->query($query_tasks);
if ($result_tasks->num_rows > 0) {
    while($row_task = $result_tasks->fetch_assoc()) {
        $tasks[] = $row_task;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Task</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/foundation/6.7.3/css/foundation.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/foundation/6.7.3/js/foundation.min.js"></script>
    <link rel="stylesheet" href="styles/rh_general_style.css">
</head>
<body>

<div class="grid-container">
    <div class="grid-x grid-padding-x">
        <div class="medium-6 cell medium-offset-3">
            <h1>Add New Task</h1>
            <form action="add_task.php" method="POST">
                <label for="equipment_id">Equipment:
                    <select name="equipment_id">
                    <option value="" disabled selected>Select Equipment...</option>
                        <?php foreach ($equipments as $equipment): ?>
                            <option value="<?php echo $equipment['equipment_id']; ?>"><?php echo $equipment['equipment_name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                
                <label for="task_description">Task Description:
                    <input type="text" name="task_description" required>
                </label>

                <label for="threshold_hour">Threshold Hour:
                    <input type="number" name="threshold_hour" required>
                </label>

                <input type="submit" class="button" value="Add Task">
            </form>
        </div>
        <!-- <div class="medium-12 cell"> -->
        <div class="center-container">
            <div class="medium-12 cellrh custom-width">
                <h2>Existing Tasks</h2>
                <?php if(isset($_GET['success'])): ?>
                    <div class="callout success">
                        Task added successfully!
                    </div>
                <?php endif; ?>
                <?php if(isset($_GET['error'])): ?>
                    <div class="callout alert">
                        Error adding task!
                    </div>
                <?php endif; ?>
                <table>
                    <thead>
                        <tr>
                            <th>Equipment Name</th>
                            <th>Task Description</th>
                            <th>Threshold Hour</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($tasks as $task): ?>
                            <tr>
                                <td><?php echo $task['equipment_name']; ?></td>
                                <td><?php echo $task['task_description']; ?></td>
                                <td style="text-align:center"><?php echo $task['threshold_hour']; ?></td>
                                <td class="action-buttons">
                                    <a href="edit_task.php?id=<?php echo $task['task_id']; ?>" class="button tiny">Edit</a>
                                    <a href="delete_task.php?id=<?php echo $task['task_id']; ?>" class="button alert tiny delete-btn" onclick="return confirm('Are you sure you want to delete this?');">Delete</a>
                                    
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/foundation/6.7.3/js/foundation.min.js"></script>
<script>
    $(document).foundation();
    setTimeout(function() {
    $('.callout').fadeOut('slow');
}, 1500);  // 1500ms or 1.5 seconds

</script>
</body>
</html>
