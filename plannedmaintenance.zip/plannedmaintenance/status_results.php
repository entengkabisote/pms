<?php
include "db_connect.php";

if (isset($_GET['vessel_id']) && isset($_GET['status'])) {
    $vessel_id = $_GET['vessel_id'];
    $status = $_GET['status'];

    $tasks = $conn->prepare("
        SELECT 
            ve.vessel_id,
            ve.equipment_id,
            ve.task_id,
            v.vessel_name, 
            re.equipment_type, 
            re.equipment_name,
            t.task_description,
            t.threshold_hour,
            ve.total_running_hours,
            ve.remaining_hours,
            ve.remarks
        FROM vessel_rh_equipment ve 
        JOIN vessels v ON ve.vessel_id = v.id
        JOIN rh_equipments re ON ve.equipment_id = re.equipment_id 
        JOIN tasks t ON ve.task_id = t.task_id 
        WHERE ve.vessel_id = ? AND ve.status = ?
    ");

    $tasks->bind_param("is", $vessel_id, $status);
    $tasks->execute();

    $result = $tasks->get_result();

}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/status_results_style.css">
</head>

<body>
    <?php include 'header.php'; ?>
    <h5><?php echo $status; ?> Status:</h5>
    <main class="status-results-container">
        <div class="grid-container">
            <div class="grid-x grid-margin-x grid-padding-y">
                <div class="cell">
                    
                    <a href="status_page.php?id=<?php echo $vessel_id; ?>" class="btn-small waves-effect waves-light custom-btn">Back to Vessel List</a>
                    

                    <!-- Vessel Name section -->
                    <?php
                    $vesselStmt = $conn->prepare("SELECT vessel_name FROM vessels WHERE id = ?");
                    $vesselStmt->bind_param("i", $vessel_id);
                    $vesselStmt->execute();
                    $vesselResult = $vesselStmt->get_result();
                    if ($vesselRow = $vesselResult->fetch_assoc()) {
                        $vesselName = $vesselRow['vessel_name'];
                        echo "<h5>Vessel Name: {$vesselName}</h5>";
                    }
                    $vesselStmt->close();
                    ?>

                    <!-- Table section -->
                    <table class="hover">
                        <thead>
                            <tr>
                                <th style="width: 8%;">Equipment Type</th>
                                <th style="width: 10%;">Equipment Name</th>
                                <th style="width: auto;">Task Description</th>
                                <th style="width: 5%;">Threshold Hours</th>
                                <th style="width: 7%;">Total Running Hours</th>
                                <th style="width: 7%;">Remaining Hours</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            while ($task = $result->fetch_assoc()) {
                                echo '<tr>';
                                echo "<td>{$task['equipment_type']}</td>";
                                echo "<td>{$task['equipment_name']}</td>";
                                echo "<td>{$task['task_description']}</td>";
                                echo "<td>{$task['threshold_hour']}</td>";
                                echo "<td>{$task['total_running_hours']}</td>";
                                echo "<td>{$task['remaining_hours']}</td>";
                                echo "<td>";
                                echo "<form action='update_task.php' method='post'>";
                                echo "<input type='hidden' name='vessel_id' value='{$task['vessel_id']}'>";
                                echo "<input type='hidden' name='equipment_id' value='{$task['equipment_id']}'>";
                                echo "<input type='hidden' name='task_id' value='{$task['task_id']}'>";
                                echo "<input type='text' name='remarks' placeholder='Enter remarks here'>";
                                echo "<button type='submit' name='update_task' class='btn blue'>Complete Task</button>";
                                echo "</form>";
                                echo "</td>";
                                echo '</tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

        
        </script>
</body>

</html>
