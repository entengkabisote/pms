<?php
include 'db_connect.php';
$sql = "SELECT * FROM vessels";
$result = $conn->query($sql);
?>
<div class="row">
<?php
while($row = $result->fetch_assoc()) {
?>
    <div class="col s12 m6 l4 center-align">
        <div class="card hoverable custom-card">
            <div class="card-image">
                <a href="vessel_details.php?id=<?php echo $row['id']; ?>">
                    <img src="<?php echo $row['imahe']; ?>" alt="Vessel Image">
                </a>
            </div>
            <div class="card-content">
                <a href="vessel_details.php?id=<?php echo $row['id']; ?>">
                    <span class="card-title truncate"><?php echo $row['vessel_name']; ?></span>
                </a>
            </div>
        </div>
    </div>
<?php
}
?>
</div>
