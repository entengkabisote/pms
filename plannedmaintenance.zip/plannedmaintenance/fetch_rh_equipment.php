<?php
include 'fetch_data.php';

$vessel_id = $_GET['vessel_id'] ?? null;
$equipment_name = $_GET['equipment_name'] ?? null;
$threshold_hour = $_GET['threshold_hour'] ?? null;

$data = fetchTableData($vessel_id, $equipment_name, $threshold_hour);

if (count($data) > 0) {
    echo '<table>';
    echo '<tr><th>Equipment Name</th><th>Task</th><th>Threshold Hour</th></tr>';
    foreach ($data as $row) {
        echo '<tr>';
        echo '<td>' . htmlspecialchars($row['equipment_name']) . '</td>';
        echo '<td>' . htmlspecialchars($row['task_description']) . '</td>';
        echo '<td>' . htmlspecialchars($row['threshold_hour']) . '</td>';
        echo '</tr>';
    }
    echo '</table>';
} else {
    echo 'No records found';
}

?>
