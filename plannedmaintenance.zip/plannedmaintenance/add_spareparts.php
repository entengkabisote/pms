<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Connect to database
    include 'db_connect.php';

    // Start a transaction
    $conn->begin_transaction();

    // Prepared statement for insertion of spare parts data
    $stmt = $conn->prepare("INSERT INTO spare_parts (task_id, equipment_id, part_name, location, quantity) VALUES (?, ?, ?, ?, ?)");

    if (false === $stmt) {
        // Handle error - including rollback if there is an error in the prepare
        $conn->rollback();
        die("Prepare failed: " . htmlspecialchars($conn->error));
    }

    // Check if all expected POST variables are set
    if(isset($_POST['task_id'], $_POST['equipment_id'], $_POST['spare_parts'], $_POST['locations'], $_POST['quantities'])) {
        $task_id = $_POST['task_id'];
        $equipment_id = $_POST['equipment_id'];

        // Bind parameters to the prepared statement
        $stmt->bind_param("iissi", $task_id, $equipment_id, $part_name, $location, $quantity);

        // Loop through each spare part and insert it into the database
        foreach ($_POST['spare_parts'] as $i => $part_name) {
            $location = $_POST['locations'][$i];
            $quantity = $_POST['quantities'][$i];

            // Execute each insert statement
            if (!$stmt->execute()) {
                // Handle error - includes rollback if there is an execution error
                $conn->rollback();
                die("Execute failed: " . htmlspecialchars($stmt->error));
            }
        }

        // Commit the transaction
        $conn->commit();

        // Get the ID of the last inserted spare part
        $last_id = $conn->insert_id;

        // Fetch the newly added spare part data
        $stmt = $conn->prepare("SELECT id, part_name, location, quantity FROM spare_parts WHERE id = ?");
        $stmt->bind_param("i", $last_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $new_spare_part = $result->fetch_assoc();

        $stmt->close();
        $conn->close();

        // Return JSON response
        header('Content-Type: application/json');
        echo json_encode($new_spare_part);
        exit();
    } else {
        // Handle errors if there are missing POST variables
        die("Missing POST variables");
    }
} else {
    die("Invalid request method");
}
?>
