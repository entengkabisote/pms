<?php

include 'db_connect.php';

$message = "";

if (isset($_GET['sub_task_id'])) {
    $sub_task_id = $_GET['sub_task_id'];

    $stmt = $conn->prepare("SELECT * FROM sub_tasks WHERE sub_task_id = ?");
    $stmt->bind_param("i", $sub_task_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $sub_task = $result->fetch_assoc();
    } else {
        exit('Task not found');
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_GET['sub_task_id']) && isset($_POST['sub_task_description'])) {
        $new_description = $_POST['sub_task_description'];
        $new_threshold = $_POST['threshold_hour'];
        $stmt = $conn->prepare("UPDATE sub_tasks SET sub_task_description = ?, threshold_hour = ? WHERE sub_task_id = ?");
        $stmt->bind_param("sii", $new_description, $new_threshold, $sub_task_id );

        if ($stmt->execute()) {
            header("Location: edit_subequipment.php?subequipment_id=" . $sub_task['subequipment_id']);
            exit;
        } else {
            $message = "Error: " . $stmt->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/admiral.css">
</head>

<body>
<?php include 'header.php'; ?>

    <main class="table-container">
        <div class="form1">
        <form method="POST" action="edit_sub_task.php?sub_task_id=<?php echo $sub_task_id; ?>">
            <label>Task Name:</label>
            <input type="text" name="sub_task_description" value="<?php echo $sub_task['sub_task_description']; ?>">
            <input type="text" name="threshold_hour" value="<?php echo $sub_task['threshold_hour']; ?>">
                <button class="btn-small waves-effect waves-light" type="submit">Update<i class="material-icons left">update</i></button>
                
            <a href="edit_subequipment.php?subequipment_id=<?php echo $sub_task['subequipment_id']; ?>" class="btn-small waves-effect waves-light">Back
                <i class="material-icons left">arrow_back</i>
            </a>
            </form>
        </div>
    </main>
        

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

        var message = <?php echo json_encode($message); ?>;
            if (message !== "") {
                var toastHTML = '<span>' + message + '</span>';
                M.toast({html: toastHTML, displayLength: 4000, classes: 'red'});
            }

        </script>
</body>

</html>
