<?php
include 'db_connect.php';

$sql = "SELECT * FROM inspection_meta_table";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/display_meta_style.css">
</head>

<body>
<?php include 'header.php'; ?>
<div>
    <h5>Modification for Inspection</h5>
</div>
    <main class="display-meta-container">
    <input type="text" id="searchInput" placeholder="Search for records...">

        <table class="striped">
            <thead>
                <tr>
                    <!-- <th>Meta ID</th>
                    <th>Equipment ID</th> -->
                    <th>Inspection Type</th>
                    <th>Inspection Interval</th>
                    <th>Person In Charge</th>
                    <th>Criticality</th>
                    <!-- <th>Edit</th> -->
                </tr>
            </thead>

            <tbody>
    <?php while($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
        <td data-column-name="inspection_type" data-meta-id="<?php echo $row['meta_id']; ?>">
            <?php echo $row['inspection_type']; ?>
        </td>
        <td data-column-name="inspection_interval" data-meta-id="<?php echo $row['meta_id']; ?>">
            <?php echo $row['inspection_interval']; ?>
        </td>
        <td data-column-name="person_in_charge" data-meta-id="<?php echo $row['meta_id']; ?>">
            <?php echo $row['person_in_charge']; ?>
        </td>
        <td data-column-name="criticality" data-meta-id="<?php echo $row['meta_id']; ?>">
            <?php echo $row['criticality']; ?>
        </td>

        </tr>
    <?php } ?>
</tbody>

        </table>    
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>

        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

        document.addEventListener('DOMContentLoaded', () => {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);

            const rows = document.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const cells = row.querySelectorAll('td:not(:last-child)');
                cells.forEach(cell => {
                    cell.addEventListener('dblclick', function() {
                        const columnName = cell.dataset.columnName; // Move this line here
                        const originalContent = cell.textContent;
                        
                        if(cell.querySelector('input')) {
                            return;  // Skip if input is already active
                        }
                        
                        const input = document.createElement('input');
                        input.value = originalContent;
                        
                        cell.textContent = '';
                        cell.appendChild(input);
                        input.focus();
                        
                        input.addEventListener('keydown', async function(e) {
                            if (e.key === 'Enter') {
                                const newValue = input.value;

                                const response = await fetch('update_meta_cell.php', {
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/json'
                                    },
                                    body: JSON.stringify({
                                        meta_id: cell.dataset.metaId,
                                        column: columnName,
                                        new_value: newValue
                                    })
                                });

                                if (response.ok) {
                                    // Successfully updated the cell in the database.
                                    cell.textContent = newValue;
                                } else {
                                    // Failed to update. Show an error or revert to original content.
                                    cell.textContent = originalContent;
                                }
                            }
                        });

                        input.addEventListener('blur', async function() {
                            const newValue = input.value;

                            const response = await fetch('update_meta_cell.php', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify({
                                    meta_id: row.querySelector('[data-meta-id]').dataset.metaId,
                                    column: columnName,
                                    new_value: newValue
                                })
                            });

                            if (response.ok) {
                                // Successfully updated the cell in the database.
                                cell.textContent = newValue;
                            } else {
                                // Failed to update. Show an error or revert to original content.
                                cell.textContent = originalContent;
                            }
                        });
                    });
                });
            });
        });

        function debounce(func, delay = 300) {
            let timeout;
            return function(...args) {
                clearTimeout(timeout);
                timeout = setTimeout(() => func.apply(this, args), delay);
            };
        }

        document.getElementById('searchInput').addEventListener('input', debounce((e) => {
            let searchQuery = e.target.value.toLowerCase();
            let rows = document.querySelectorAll('tbody tr');

            rows.forEach(row => {
                let columns = row.querySelectorAll('td');
                let rowText = '';

                columns.forEach(column => {
                    rowText += column.textContent.toLowerCase() + ' ';
                });

                if (rowText.indexOf(searchQuery) !== -1) {
                    row.style.display = "";  // Show row
                } else {
                    row.style.display = "none";  // Hide row
                }
            });
        }));






        </script>
</body>

</html>
