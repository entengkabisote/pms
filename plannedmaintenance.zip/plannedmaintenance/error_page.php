<?php


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/general.css">
    <style>
        .error-message {
            text-align: center;
            margin-top: 50px;
        }
    </style>
</head>

<body>
<?php include 'header.php'; ?>

<div class="error-message">
        <h3>We're sorry...</h3>
        <p>We are experiencing technical difficulties. Please try again later.</p>
        <p>If you continue to experience this problem, please contact our support team.</p>
        <a href="index.php" class="btn">Go Home</a>
    </div>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });

        
        </script>
</body>

</html>
