<?php
session_start();
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_GET['subequipment_id']) && isset($_POST['sub_task_description']) && isset($_POST['threshold'])) {
        $subequipment_id = $_GET['subequipment_id'];
        $sub_task_description = $_POST['sub_task_description'];
        $threshold = $_POST['threshold'];
        
        $check_stmt = $conn->prepare("SELECT * FROM sub_tasks WHERE sub_task_description = ? AND subequipment_id = ?");
        $check_stmt->bind_param("si", $sub_task_description, $subequipment_id);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();

        if ($check_result->num_rows > 0) {
            $check_threshold_stmt = $conn->prepare("SELECT * FROM sub_tasks WHERE sub_task_description = ? AND subequipment_id = ? AND threshold_hour = ?");
            $check_threshold_stmt->bind_param("sis", $sub_task_description, $subequipment_id, $threshold);
            $check_threshold_stmt->execute();
            $check_threshold_result = $check_threshold_stmt->get_result();
            
            if ($check_threshold_result->num_rows > 0) {
                $_SESSION['toastMessage'] = "Task with the same name and threshold already exists!";
                header("Location: edit_subequipment.php?subequipment_id=" . $subequipment_id);
                exit;
            }
        }

        // Common code for inserting a new task or a task with different threshold
        $stmt = $conn->prepare("SELECT main_equipment_id FROM rh_subequipments WHERE subequipment_id = ?");
        $stmt->bind_param("i", $subequipment_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $main_equipment = $result->fetch_assoc();
        $equipment_id = $main_equipment['main_equipment_id'];
        
        $stmt = $conn->prepare("SELECT equipment_type FROM rh_equipments WHERE equipment_id = ?");
        $stmt->bind_param("i", $equipment_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $equipment = $result->fetch_assoc();
        $equipment_type = $equipment['equipment_type'];
        
        $stmt = $conn->prepare("INSERT INTO sub_tasks (sub_task_description, subequipment_id, equipment_id, equipment_type, threshold_hour) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("siiss", $sub_task_description, $subequipment_id, $equipment_id, $equipment_type, $threshold);

        if ($stmt->execute()) {
            header("Location: edit_subequipment.php?subequipment_id=" . $subequipment_id);
            exit;
        } else {
            echo "Error: " . $stmt->error;
        }
    }
}
?>
