<?php
include "db_connect.php";

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $equipment_name = $_POST['equipment_name'];
    $equipment_type = $_POST['equipment_type'];
    $equipment_id = $_POST['equipment_id'];

    $stmt = $conn->prepare("UPDATE rh_equipments SET equipment_name=?, equipment_type=? WHERE equipment_id=?");
    $stmt->bind_param("ssi", $equipment_name, $equipment_type, $equipment_id);
    
    if ($stmt->execute()) {
        header("Location: equipment_running_hours.php?success=1"); // Redirect to your list page or wherever you want after editing
        exit;
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $stmt->close();
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM rh_equipments WHERE equipment_id = $id";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $equipment = $result->fetch_assoc();
    } else {
        die("Equipment not found with ID: $id");
    }
} else {
    die("ID is required to edit the equipment.");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PMS | Vessel Details</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/styles.css">
    <link rel="stylesheet" href="styles/equipment_rh_styles.css">   
    <link rel="stylesheet" href="styles/buttons.css">
</head>

<body>
<?php include 'header.php'; ?>
    <div>
        <h5 class="center-align">Edit Equipment</h5> <!-- Add center-align class -->
    </div>
    <div class="col equipment-rh-container">
    <form action="" method="POST" class="form-style">
        <input type="hidden" name="equipment_id" value="<?php echo $equipment['equipment_id']; ?>">
        
        <div class="form-group">
            <label for="equipment_name">Equipment Name:</label>
            <input type="text" name="equipment_name" value="<?php echo $equipment['equipment_name']; ?>" required>
        </div>

        <div class="form-group">
            <label for="equipment_type">Equipment Type:</label>
            <input type="text" name="equipment_type" value="<?php echo $equipment['equipment_type']; ?>">
        </div>

        
        <button class="btn-small waves-effect waves-light" type="submit" name="action">Update Equipment
                <i class="material-icons left">update</i>
        </button>
        <a href="equipment_running_hours.php" class="btn-small waves-effect waves-light"><i class="material-icons left">cancel</i>Cancel</a>
        <button type="button" class="btn-small waves-effect waves-light" onclick="location.href='rh_tasks.php?equipment_id=<?php echo $id; ?>'">Add Task<i class="material-icons left">settings</i></button> 
        <!-- <button type="button" class="btn-small waves-effect waves-light" onclick="location.href='add_rh_subequipment.php?equipment_id=<?php echo $id; ?>'">Add Sub Equipment<i class="material-icons left">add</i></button>  -->


    </form>
    </div>


    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);
        });
        </script>
</body>

</html>
