<?php
include 'db_connect.php';

if (isset($_GET['subequipment_id'])) {
    $subequipment_id = $_GET['subequipment_id'];

    // Prepare SQL statement for deleting the record
    $stmt = $conn->prepare("DELETE FROM rh_subequipments WHERE subequipment_id = ?");
    $stmt->bind_param("i", $subequipment_id);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Success";
    } else {
        echo "Error: " . $stmt->error;
    }
    
    $stmt->close();
} else {
    echo "No subequipment_id provided";
}
?>
