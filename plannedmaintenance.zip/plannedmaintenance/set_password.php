<?php
session_start();

// Make sure there is a temp_user_id in the session
if (!isset($_SESSION['temp_user_id'])) {
    // No temp_user_id, redirect to main page or login page
    header('Location: index.php');
    exit();
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ships | Planned Maintenance System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <link rel="stylesheet" href="styles/styles.css">   
    <link rel="stylesheet" href="styles/footer.css">
    <link rel="stylesheet" href="styles/set_password_style.css">
    <style>
        .error-message {
            font-size: 12px;
            color: red;
        }
    </style>
</head>

<body>
<div class="logo-header">
    <img src="images/smscorp.png" alt="Company Logo" class="logo">
    <h4 class="white-text">Strategic Maritime Solutions Corp.</h4>
</div>
<nav class="blue-grey darken-2">
</nav>

    <main class="set-password-container">
        <form action="save_password.php" method="post">
            <input type="hidden" name="user_id" value="<?php echo $_SESSION['temp_user_id']; ?>">
            <div>
                <label for="password">New Password:</label>
                <input type="password" id="password" name="password" required>
                <button type="button" onclick="togglePasswordVisibility('password')" class="password-toggle-button">
                    <i id="password-toggle-icon" class="fa fa-eye-slash"></i>
                </button>
            </div>
            <div>
                <label for="confirm_password">Confirm Password:</label>
                <input type="password" id="confirm_password" name="confirm_password" required>
                <button type="button" onclick="togglePasswordVisibility('confirm_password')" class="password-toggle-button">
                    <i id="confirm_password-toggle-icon" class="fa fa-eye-slash"></i>
                </button>
            </div>
            <div class=password-btn>
                <button type="submit">Set Password</button>
            </div>

            <?php if (isset($_SESSION['error_message'])): ?>
                <div id="error-message-container" class="error-message">
                    <?php 
                    echo $_SESSION['error_message']; 
                    unset($_SESSION['error_message']);
                    ?>
                </div>
            <?php endif; ?>

        </form>
        
    </main>

    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                SMS
            </div>
            <div class="footer-links">
                <a href="#"><i class="fas fa-info-circle"></i> About</a>
                <a href="#"><i class="fas fa-phone-alt"></i> Contact</a>
                <a href="#"><i class="fas fa-question-circle"></i> Support</a>
            </div>
            <div class="footer-copyright">
                &copy; 2023. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.dropdown-trigger');
            var instances = M.Dropdown.init(elems);

            var elems = document.querySelectorAll('select');
            var instances = M.FormSelect.init(elems);
        });

        // Check if there is an error message container on the page
        var errorMessageContainer = document.getElementById('error-message-container');
        if (errorMessageContainer) {
            // Set a timer to remove the error message after 3-5 seconds (3000-5000 milliseconds)
            setTimeout(function() {
                // Remove the error message container from the page
                errorMessageContainer.remove();
            }, 3000); // You can change 3000 (3 seconds) to the desired length of time
        }
        
        function togglePasswordVisibility(inputId) {
            var passwordInput = document.getElementById(inputId);
            var passwordIcon = document.getElementById(inputId + "-toggle-icon"); // Add "-toggle-icon" to the icon id

            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                passwordIcon.classList.remove("fa-eye-slash"); // Remove the "fa-eye-slash" class
                passwordIcon.classList.add("fa-eye"); // Add the "fa-eye" class
            } else {
                passwordInput.type = "password";
                passwordIcon.classList.remove("fa-eye"); // Remove the "fa-eye" class
                passwordIcon.classList.add("fa-eye-slash"); // Add the "fa-eye-slash" class
            }
        }

        </script>
</body>

</html>
