<?php
foreach ($dateArray as $equipment_type => $date) {
    $hours = isset($running_hoursArray[$equipment_type]['hours']) ? $running_hoursArray[$equipment_type]['hours'] : 0;
    $minutes = isset($running_hoursArray[$equipment_type]['minutes']) ? $running_hoursArray[$equipment_type]['minutes'] : 0;

    // Convert to integers if numeric, otherwise set to zero
    $hours = is_numeric($hours) ? (int)$hours : 0;
    $minutes = is_numeric($minutes) ? (int)$minutes : 0;

    // Validate the minutes
    if ($minutes < 0 || $minutes >= 60) {
        $_SESSION['message'] = "Minutes for $equipment_type should be between 0 and 59.";
        $errorOccurred = true;
        break;
    }

    // If both hours and minutes are zero after the numeric check, continue to the next iteration
    if ($hours === 0 && $minutes === 0) {
        continue;
    }

    $decimalHours = $hours + ($minutes / 60);
    $running_hours = $decimalHours;

    // Process each equipment type
    processEquipmentType($conn, $data, $equipment_type, $date, $running_hours, $vessel_id, $insertValues, $hasDuplicate);
}

?>

foreach ($dateArray as $equipment_type => $date) {
    $hours = isset($running_hoursArray[$equipment_type]['hours']) && is_numeric($running_hoursArray[$equipment_type]['hours']) ? (int)$running_hoursArray[$equipment_type]['hours'] : 0;
    $minutes = isset($running_hoursArray[$equipment_type]['minutes']) && is_numeric($running_hoursArray[$equipment_type]['minutes']) ? (int)$running_hoursArray[$equipment_type]['minutes'] : 0;

    // Validate the minutes
    if ($minutes < 0 || $minutes >= 60) {
        $_SESSION['message'] = "Minutes for $equipment_type should be between 0 and 59.";
        $errorOccurred = true;
        break;
    }

    $decimalHours = $hours + ($minutes / 60);
    $running_hours = $decimalHours;

    // Process each equipment type
    processEquipmentType($conn, $data, $equipment_type, $date, $running_hours, $vessel_id, $insertValues, $hasDuplicate);
}