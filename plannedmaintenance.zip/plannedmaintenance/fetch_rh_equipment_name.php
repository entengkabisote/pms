<?php
include 'db_connect.php';

$vessel_id = isset($_GET['vessel_id']) ? $_GET['vessel_id'] : null;
$equipment_type = isset($_GET['equipment_type']) ? $_GET['equipment_type'] : null;
$threshold_hour = isset($_GET['threshold_hour']) ? $_GET['threshold_hour'] : null;
$equipment_name = isset($_GET['equipment_name']) ? $_GET['equipment_name'] : null;

$sql = "SELECT rh_equipments.equipment_type, rh_equipments.equipment_name, tasks.task_description
        FROM vessel_rh_equipment
        JOIN rh_equipments ON vessel_rh_equipment.equipment_id = rh_equipments.equipment_id
        JOIN tasks ON vessel_rh_equipment.task_id = tasks.task_id
        WHERE vessel_rh_equipment.vessel_id = $vessel_id";

if ($equipment_type) {
    $sql .= " AND rh_equipments.equipment_type = '$equipment_type'";
}

if ($threshold_hour) {
    $sql .= " AND tasks.threshold_hour = $threshold_hour";
}

if ($equipment_name) {
    $sql .= " AND rh_equipments.equipment_name = '$equipment_name'";
}

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo $row['equipment_type'] . " - " . $row['equipment_name'] . " - " . $row['task_description'] . "<br>";
    }
} else {
    echo "No records found.";
}

?>
