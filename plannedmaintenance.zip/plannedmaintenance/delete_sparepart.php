<?php
session_start();
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the part ID and validate it
    $part_id = $_POST['id'] ?? 0;

    if ($part_id > 0) {
        $stmt = $conn->prepare("DELETE FROM spare_parts WHERE id = ?");
        $stmt->bind_param("i", $part_id);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            echo 'success';
        } else {
            echo 'error';
        }

        $stmt->close();
    } else {
        echo 'error';
    }
} else {
    // If the request method is not POST, return an error.
    echo 'error';
}
?>
